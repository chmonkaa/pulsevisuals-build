# Pulse Visuals (Fabric, Minecraft 1.21.11, Java 21) — client-only visual / HUD / QoL mod

## Build
* Linux/macOS: `./build.sh`   * Windows: `build.bat`   (JDK 21 + internet needed once; the script bootstraps Gradle 9.2.1 and runs `./gradlew build`)
* Result: `build/libs/pulsevisuals-1.0.0.jar` -> put into `.minecraft/mods` together with Fabric API (0.141.1+1.21.11 or newer). ModMenu optional.

## Use
* **Right Shift** - open the GUI (left click: switch/expand, right click on a setting: reset, `Ctrl+F` search).
* Sidebar button **HUD Editor** - drag widgets, wheel = scale, right click = reset widget, snapping to grid/centre/edges/other widgets (hold Left Alt to disable snapping).
* Commands: `/pulse gui | friend add|remove|list <name> | toggle <module> | config save|load|list|export|import | theme <name> | timer <sec> <label>`
* Configs: `config/pulsevisuals/profiles/*.json`, themes: `config/pulsevisuals/themes.json`.

## Default binds
Right Shift = GUI, Left Alt (hold) = FreeLook, C (hold) = SmoothZoom (+wheel), Left Shift (hold, in inventories) = ShulkerPreview,
ToggleSneak latches on Left Shift, AutoReconnect cancel = C. Every module has its own `Keybind` + `Bind Mode (Toggle/Hold)` in the GUI.

## Safety / compatibility notes
* `environment: client`. The mod never sends or edits packets except what the vanilla client does for your own key presses
  (CommandBinds sends the chat command you configured; AutoSprint/ToggleSneak press the vanilla keys). Packet mixins are read-only observers.
* World rendering uses only vanilla translucent quad layers (no custom shaders/pipelines) -> Sodium / Iris / Lithium / ImmediatelyFast friendly.
* All mixins use `defaultRequire: 0`: if a target does not exist in your exact game build, only that one feature is skipped.

## Honest status
This source tree was written without access to the Minecraft/Fabric jars (offline sandbox) so it was **syntax-checked but not compiled against the game**.
If `./gradlew build` reports a symbol error it will be one of the version-sensitive spots below - each is a one-line fix:
`WorldRender` (Fabric `WorldRenderContext.matrices()/consumers()`, `RenderLayer.getDebugQuads()`), `ClickGuiScreen`/`HudEditorScreen` input signatures
(`KeyInput`, `CharInput`), `GameRendererMixin` projection method name, `TargetHUD` (`InventoryScreen.drawEntity`, `PlayerSkinDrawer.draw`),
`HitColor` (`NativeImage.setColorArgb`), `AutoReconnect` (`ConnectScreen.connect`), `Camera` accessors/mixins.
