@echo off
rem Builds build\libs\pulsevisuals-1.0.0.jar  (needs JDK 21 + internet for the first run)
setlocal
cd /d "%~dp0"
set GV=9.2.1
where javac >nul 2>nul
if errorlevel 1 (echo JDK 21 ^(javac^) not found. Install Temurin/OpenJDK 21 first. & exit /b 1)
if not exist gradle\wrapper\gradle-wrapper.jar (
  if not exist ".gradle-dist\gradle-%GV%" (
    echo Downloading Gradle %GV% ...
    mkdir .gradle-dist 2>nul
    powershell -NoProfile -Command "Invoke-WebRequest https://services.gradle.org/distributions/gradle-%GV%-bin.zip -OutFile .gradle-dist\gradle.zip; Expand-Archive .gradle-dist\gradle.zip -DestinationPath .gradle-dist -Force"
  )
  call ".gradle-dist\gradle-%GV%\bin\gradle.bat" wrapper --gradle-version %GV%
)
call gradlew.bat build
echo.
echo Done: build\libs\pulsevisuals-1.0.0.jar   (do NOT use the -sources jar)
endlocal
