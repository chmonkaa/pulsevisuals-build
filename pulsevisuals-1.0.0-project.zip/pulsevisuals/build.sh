#!/usr/bin/env bash
# Builds build/libs/pulsevisuals-1.0.0.jar  (needs JDK 21 + internet for the first run)
set -e
cd "$(dirname "$0")"
GV=9.2.1
if ! command -v javac >/dev/null 2>&1; then echo "JDK 21 (javac) not found. Install Temurin/OpenJDK 21 first."; exit 1; fi
if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  if command -v gradle >/dev/null 2>&1 && gradle --version 2>/dev/null | grep -q "Gradle 9"; then
    GRADLE=gradle
  else
    mkdir -p .gradle-dist
    if [ ! -d ".gradle-dist/gradle-$GV" ]; then
      echo "Downloading Gradle $GV ..."
      curl -fL "https://services.gradle.org/distributions/gradle-$GV-bin.zip" -o .gradle-dist/gradle.zip
      unzip -q .gradle-dist/gradle.zip -d .gradle-dist
    fi
    GRADLE=".gradle-dist/gradle-$GV/bin/gradle"
  fi
  "$GRADLE" wrapper --gradle-version "$GV"
fi
chmod +x gradlew
./gradlew build
echo
echo "Done:  build/libs/pulsevisuals-1.0.0.jar   (do NOT use the -sources jar)"
