package dev.pulse;

import dev.pulse.gui.HudEditorScreen;
import dev.pulse.module.HudModule;
import dev.pulse.module.Module;
import dev.pulse.modules.Modules;
import dev.pulse.util.Anim;
import dev.pulse.util.Proj;
import dev.pulse.util.Stats;
import net.minecraft.client.gui.DrawContext;

import java.util.HashSet;
import java.util.Set;

/** Screen-space pass: overlay modules first, then draggable HUD widgets. */
public final class HudRenderer {
    private static final Set<String> FAILED = new HashSet<>();

    public static void render(DrawContext c, float td) {
        var mc = Pulse.mc;
        Anim.frame();
        Stats.pollClicks();
        if (mc.world == null || mc.player == null || mc.options.hudHidden) return;
        Proj.update();
        for (Module m : Modules.ALL) {
            if (!m.enabled || m instanceof HudModule) continue;
            try { m.onOverlay(c, td); } catch (Throwable t) { fail(m, t); }
        }
        if (mc.currentScreen instanceof HudEditorScreen) return;
        for (Module m : Modules.ALL) {
            if (!m.enabled || !(m instanceof HudModule h)) continue;
            try { h.renderHud(c, td, false); } catch (Throwable t) { fail(m, t); }
        }
    }

    private static void fail(Module m, Throwable t) {
        if (FAILED.add(m.name)) { System.err.println("[PulseVisuals] module '" + m.name + "' render error (reported once):"); t.printStackTrace(); }
    }

    private HudRenderer() {}
}
