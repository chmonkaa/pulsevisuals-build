package dev.pulse;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Shared runtime state used by mixins, modules and the GUI. */
public final class Pulse {
    public static MinecraftClient mc;

    /** Last vertical FOV (degrees) used for the world projection (written by GameRendererMixin). */
    public static float fov = 70f;
    /** Forced aspect ratio (0 = vanilla). Written by AspectRatio. */
    public static float aspect = 0f;
    /** Extra FOV multiplier (SmoothZoom). */
    public static float zoomMul = 1f;

    /** FreeLook state. */
    public static boolean freeLook = false;
    public static float freeYaw, freePitch;

    /** Combat tracking. */
    public static LivingEntity target;
    public static long targetTime;
    public static final List<Consumer<Entity>> hitListeners = new ArrayList<>();
    public static final List<Consumer<Entity>> popListeners = new ArrayList<>();

    /** Totem pop request produced by the network mixin. */
    public static long ownPopTime = -1;

    /** Status message shown by modules when the player is not in a world (preview mode in GUI). */
    public static boolean inWorld() { return mc != null && mc.world != null && mc.player != null; }

    public static void onHit(Entity e) {
        if (e instanceof LivingEntity le) { target = le; targetTime = System.currentTimeMillis(); }
        for (Consumer<Entity> c : hitListeners) c.accept(e);
    }

    public static void onPop(Entity e) {
        if (mc.player != null && e == mc.player) ownPopTime = System.currentTimeMillis();
        for (Consumer<Entity> c : popListeners) c.accept(e);
    }

    private Pulse() {}
}
