package dev.pulse;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.pulse.config.Config;
import dev.pulse.gui.ClickGuiScreen;
import dev.pulse.mixin.HandledScreenAccessor;
import dev.pulse.module.Module;
import dev.pulse.modules.Modules;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.Friends;
import dev.pulse.util.Stats;
import dev.pulse.util.WorldRender;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class PulseClient implements ClientModInitializer {
    private static boolean guiKeyWas;

    @Override
    public void onInitializeClient() {
        Pulse.mc = MinecraftClient.getInstance();
        Config.init();
        Modules.init();
        Config.loadCurrent();

        ClientTickEvents.END_CLIENT_TICK.register(PulseClient::tick);

        HudElementRegistry.addLast(Identifier.of("pulsevisuals", "hud"), (ctx, tickCounter) -> HudRenderer.render(ctx, tickCounter.getTickProgress(false)));

        WorldRenderEvents.END_MAIN.register(ctx -> {
            var mc = Pulse.mc;
            if (mc.world == null || mc.player == null) return;
            if (!WorldRender.begin(ctx)) return;
            float td = mc.getRenderTickCounter().getTickProgress(false);
            for (Module m : Modules.ALL) {
                if (!m.enabled) continue;
                try { m.onWorld(td); } catch (Throwable t) { /* never break the frame */ }
            }
            WorldRender.end();
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && player == Pulse.mc.player) Pulse.onHit(entity);
            return ActionResult.PASS;
        });

        ClientReceiveMessageEvents.GAME.register((msg, overlay) -> { if (Modules.EVENT_TIMERS != null) Modules.EVENT_TIMERS.onChat(msg.getString()); });

        ScreenEvents.AFTER_INIT.register((client, screen, sw, sh) -> {
            if (screen instanceof ChatScreen) {
                Modules.CHAT.reset();
                ScreenEvents.beforeRender(screen).register((s, ctx, mx, my, d) -> { if (Modules.CHAT.enabled) Modules.CHAT.before(ctx, true, s.width, s.height); });
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, d) -> { if (Modules.CHAT.enabled) Modules.CHAT.after(ctx, s.width, s.height); });
            }
            if (screen instanceof HandledScreen<?> hs) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, d) -> {
                    if (!Modules.SHULKER.enabled) return;
                    Slot f = ((HandledScreenAccessor) hs).pulse$getFocusedSlot();
                    if (f != null && f.hasStack()) Modules.SHULKER.render(ctx, hs, f.getStack(), mx, my);
                });
            }
            if (screen instanceof DisconnectedScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, d) -> Modules.RECONNECT.render(ctx, s));
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) -> registerCommands(dispatcher));
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> Config.saveCurrent());
    }

    private static void tick(MinecraftClient mc) {
        Stats.tick();
        long w = mc.getWindow().getHandle();
        boolean g = GLFW.glfwGetKey(w, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (g && !guiKeyWas && mc.currentScreen == null) mc.setScreen(new ClickGuiScreen(null));
        guiKeyWas = g;

        for (Module m : Modules.ALL) {
            if (m.bind.isSet() && mc.currentScreen == null) {
                boolean d = GLFW.glfwGetKey(w, m.bind.get()) == GLFW.GLFW_PRESS;
                if (m.bindMode.is("Hold")) m.setEnabled(d, false);
                else if (d && !m.keyWasDown) m.toggle();
                m.keyWasDown = d;
            } else m.keyWasDown = false;
            if (m.enabled) { try { m.onTick(); } catch (Throwable t) { t.printStackTrace(); } }
        }
    }

    private static void say(com.mojang.brigadier.context.CommandContext<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> c, String s) {
        c.getSource().sendFeedback(Text.literal("[Pulse] " + s));
    }

    private static void registerCommands(com.mojang.brigadier.CommandDispatcher<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("pulse")
            .then(ClientCommandManager.literal("gui").executes(c -> { Pulse.mc.send(() -> Pulse.mc.setScreen(new ClickGuiScreen(null))); return 1; }))
            .then(ClientCommandManager.literal("friend")
                .then(ClientCommandManager.literal("add").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                    String n = StringArgumentType.getString(c, "name"); say(c, Friends.add(n) ? "Added " + n : n + " is already a friend"); Config.saveCurrent(); return 1; })))
                .then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                    String n = StringArgumentType.getString(c, "name"); say(c, Friends.remove(n) ? "Removed " + n : n + " is not a friend"); Config.saveCurrent(); return 1; })))
                .then(ClientCommandManager.literal("list").executes(c -> { say(c, Friends.NAMES.isEmpty() ? "No friends yet" : String.join(", ", Friends.NAMES)); return 1; })))
            .then(ClientCommandManager.literal("toggle").then(ClientCommandManager.argument("module", StringArgumentType.greedyString()).executes(c -> {
                Module m = Modules.byName(StringArgumentType.getString(c, "module"));
                if (m == null) say(c, "Unknown module"); else { m.toggle(); say(c, m.name + (m.enabled ? " enabled" : " disabled")); }
                return 1; })))
            .then(ClientCommandManager.literal("config")
                .then(ClientCommandManager.literal("save").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> { Config.save(StringArgumentType.getString(c, "name")); say(c, "Saved"); return 1; })))
                .then(ClientCommandManager.literal("load").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> { say(c, Config.load(StringArgumentType.getString(c, "name")) ? "Loaded" : "Profile not found"); return 1; })))
                .then(ClientCommandManager.literal("list").executes(c -> { say(c, String.join(", ", Config.list()) + "  (active: " + Config.profile + ")"); return 1; }))
                .then(ClientCommandManager.literal("export").executes(c -> { Pulse.mc.keyboard.setClipboard(Config.export()); say(c, "Config copied to clipboard"); return 1; }))
                .then(ClientCommandManager.literal("import").executes(c -> { say(c, Config.importString(Pulse.mc.keyboard.getClipboard()) ? "Imported from clipboard" : "Clipboard does not contain a Pulse config"); return 1; })))
            .then(ClientCommandManager.literal("theme").then(ClientCommandManager.argument("name", StringArgumentType.greedyString()).executes(c -> { ThemeManager.select(StringArgumentType.getString(c, "name")); say(c, "Theme: " + ThemeManager.currentName()); return 1; })))
            .then(ClientCommandManager.literal("timer").then(ClientCommandManager.argument("seconds", DoubleArgumentType.doubleArg(1, 36000)).then(ClientCommandManager.argument("label", StringArgumentType.greedyString()).executes(c -> {
                Modules.EVENT_TIMERS.start(StringArgumentType.getString(c, "label"), DoubleArgumentType.getDouble(c, "seconds"));
                if (!Modules.EVENT_TIMERS.enabled) Modules.EVENT_TIMERS.setEnabled(true, true);
                say(c, "Timer started"); return 1; }))))
            .executes(c -> { say(c, "Commands: gui, friend add|remove|list, toggle <module>, config save|load|list|export|import, theme <name>, timer <sec> <label>"); return 1; }));
    }
}
