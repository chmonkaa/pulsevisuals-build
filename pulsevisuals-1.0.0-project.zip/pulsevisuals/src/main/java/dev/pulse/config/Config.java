package dev.pulse.config;

import com.google.gson.*;
import dev.pulse.gui.HudEditorScreen;
import dev.pulse.module.HudModule;
import dev.pulse.module.Module;
import dev.pulse.modules.Modules;
import dev.pulse.setting.Setting;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.Friends;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

/** JSON profiles in config/pulsevisuals/profiles, clipboard export / import. */
public final class Config {
    public static String profile = "default";
    private static final Gson PRETTY = new GsonBuilder().setPrettyPrinting().create();
    private static final String PREFIX = "PULSE1:";

    public static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("pulsevisuals"); }
    private static Path profiles() { return dir().resolve("profiles"); }
    private static Path file(String name) { return profiles().resolve(safe(name) + ".json"); }
    public static String safe(String n) { String s = n.trim().replaceAll("[^A-Za-z0-9_\\- ]", "_"); return s.isEmpty() ? "profile" : s; }

    public static List<String> list() {
        List<String> l = new ArrayList<>();
        try (var st = Files.list(profiles())) {
            st.filter(p -> p.toString().endsWith(".json")).forEach(p -> { String n = p.getFileName().toString(); l.add(n.substring(0, n.length() - 5)); });
        } catch (Exception ignored) {}
        if (!l.contains("default")) l.add("default");
        Collections.sort(l);
        return l;
    }

    public static JsonObject serialize() {
        JsonObject root = new JsonObject();
        root.addProperty("version", 1);
        root.add("theme", ThemeManager.saveState());
        JsonArray fr = new JsonArray();
        for (String f : Friends.NAMES) fr.add(f);
        root.add("friends", fr);
        JsonObject ed = new JsonObject();
        ed.addProperty("snap", HudEditorScreen.snap);
        ed.addProperty("grid", HudEditorScreen.grid);
        root.add("editor", ed);
        JsonObject mods = new JsonObject();
        for (Module m : Modules.ALL) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.enabled);
            JsonObject st = new JsonObject();
            for (Setting<?> s : m.allSettings()) st.add(s.name, s.save());
            o.add("settings", st);
            if (m instanceof HudModule h) { JsonObject hp = new JsonObject(); hp.addProperty("x", h.nx); hp.addProperty("y", h.ny); o.add("hud", hp); }
            mods.add(m.name, o);
        }
        root.add("modules", mods);
        return root;
    }

    public static void apply(JsonObject root) {
        if (root == null) return;
        try {
            if (root.has("theme")) ThemeManager.loadState(root.getAsJsonObject("theme"));
            if (root.has("friends")) { Friends.NAMES.clear(); for (JsonElement e : root.getAsJsonArray("friends")) Friends.add(e.getAsString()); }
            if (root.has("editor")) { JsonObject ed = root.getAsJsonObject("editor"); if (ed.has("snap")) HudEditorScreen.snap = ed.get("snap").getAsBoolean(); if (ed.has("grid")) HudEditorScreen.grid = ed.get("grid").getAsInt(); }
            JsonObject mods = root.getAsJsonObject("modules");
            if (mods == null) return;
            for (Module m : Modules.ALL) {
                if (!mods.has(m.name)) continue;
                JsonObject o = mods.getAsJsonObject(m.name);
                if (o.has("settings")) { JsonObject st = o.getAsJsonObject("settings"); for (Setting<?> s : m.allSettings()) if (st.has(s.name)) s.load(st.get(s.name)); }
                if (m instanceof HudModule h && o.has("hud")) { JsonObject hp = o.getAsJsonObject("hud"); h.nx = hp.get("x").getAsFloat(); h.ny = hp.get("y").getAsFloat(); }
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean(), true);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void init() {
        try { Files.createDirectories(profiles()); } catch (Exception ignored) {}
        ThemeManager.loadUser();
        try {
            Path cur = dir().resolve("current.txt");
            if (Files.exists(cur)) profile = Files.readString(cur).trim();
        } catch (Exception ignored) {}
        if (profile.isEmpty()) profile = "default";
    }

    public static void loadCurrent() { if (Files.exists(file(profile))) load(profile); }

    public static boolean load(String name) {
        try {
            Path f = file(name);
            if (!Files.exists(f)) return false;
            apply(JsonParser.parseString(Files.readString(f)).getAsJsonObject());
            profile = safe(name);
            Files.writeString(dir().resolve("current.txt"), profile);
            return true;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public static void save(String name) {
        try {
            Files.createDirectories(profiles());
            Files.writeString(file(name), PRETTY.toJson(serialize()), StandardCharsets.UTF_8);
            profile = safe(name);
            Files.writeString(dir().resolve("current.txt"), profile);
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void saveCurrent() { save(profile); }

    public static boolean delete(String name) {
        if (safe(name).equals("default")) return false;
        try { boolean ok = Files.deleteIfExists(file(name)); if (profile.equals(safe(name))) profile = "default"; return ok; } catch (Exception e) { return false; }
    }

    public static String export() {
        return PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(new Gson().toJson(serialize()).getBytes(StandardCharsets.UTF_8));
    }

    public static boolean importString(String s) {
        try {
            s = s.trim();
            if (!s.startsWith(PREFIX)) return false;
            String json = new String(Base64.getUrlDecoder().decode(s.substring(PREFIX.length())), StandardCharsets.UTF_8);
            apply(JsonParser.parseString(json).getAsJsonObject());
            saveCurrent();
            return true;
        } catch (Exception e) { return false; }
    }

    private Config() {}
}
