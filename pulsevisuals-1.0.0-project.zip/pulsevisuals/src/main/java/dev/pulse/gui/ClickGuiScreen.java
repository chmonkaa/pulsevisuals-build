package dev.pulse.gui;

import dev.pulse.Pulse;
import dev.pulse.config.Config;
import dev.pulse.module.Category;
import dev.pulse.module.HudModule;
import dev.pulse.module.Module;
import dev.pulse.modules.Modules;
import dev.pulse.setting.Setting;
import dev.pulse.theme.Theme;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Dark-glass click GUI (immediate mode: every frame lays out, draws and handles input in one pass).
 * Left click: toggle switch / expand card.  Right click on a setting: reset it.
 */
public class ClickGuiScreen extends Screen {
    private static final String[] TABS = {"Visuals", "HUD", "Animations & View", "World", "Utilities", "Themes & Configs"};
    private static final Category[] CATS = {Category.VISUALS, Category.HUD, Category.VIEW, Category.WORLD, Category.UTILITIES};
    private static final Setting.Color TC = new Setting.Color("t", 0x7C9CFF, 0xB48CFF, 255).mode("Theme");
    private static int tab = 0;

    private final Screen parent;
    private float open, tabY = -1, wheel;
    private boolean closing;
    private final float[] scroll = new float[6], scrollT = new float[6], tabHover = new float[6];
    private String search = "";
    private boolean searchFocus;
    private boolean lPrev, rPrev, lPress, rPress, lDown;
    private int mx, my;
    private Setting<?> listening, editing;
    private Object dragObj;
    private int dragId;
    private final IdentityHashMap<Object, Float> anim = new IdentityHashMap<>();
    private final IdentityHashMap<Object, Boolean> openSet = new IdentityHashMap<>();
    private final IdentityHashMap<Setting.Color, float[]> hsb = new IdentityHashMap<>();
    private float wx, wy, ww, wh, cx, cy, cw, ch, ga, totalH;
    private Theme T;
    private String status = "";
    private long statusUntil;
    private final Setting.Text profileName = new Setting.Text("New Profile Name", "", 24);
    private final Setting.Text friendName = new Setting.Text("Friend Name", "", 16);
    private final Setting.Text themeName = new Setting.Text("Theme Name", "", 20);

    public ClickGuiScreen(Screen parent) { super(Text.literal("Pulse Visuals")); this.parent = parent; }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public void close() { requestClose(); }

    private void requestClose() { if (!closing) { closing = true; Config.saveCurrent(); } }

    // ------------------------------------------------------------------------------------------------ input
    @Override public boolean keyPressed(KeyInput in) {
        int key = in.key();
        boolean ctrl = (in.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0;
        if (listening instanceof Setting.Bind b) {
            if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) b.set(-1);
            else if (key != GLFW.GLFW_KEY_ESCAPE) b.set(key);
            listening = null;
            return true;
        }
        if (editing instanceof Setting.Text t) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!t.value.isEmpty()) t.set(t.value.substring(0, t.value.length() - 1)); }
            else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (ctrl && key == GLFW.GLFW_KEY_V) { String cb = Pulse.mc.keyboard.getClipboard(); if (cb != null) t.set((t.value + cb).substring(0, Math.min(t.maxLen, (t.value + cb).length()))); }
            else if (ctrl && key == GLFW.GLFW_KEY_A) t.set("");
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); }
            else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) searchFocus = false;
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { requestClose(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_F) { searchFocus = true; return true; }
        return true;
    }

    @Override public boolean charTyped(CharInput in) {
        int cp = in.codepoint();
        if (cp < 32 || cp == 127) return false;
        String s = new String(Character.toChars(cp));
        if (editing instanceof Setting.Text t) { if (t.value.length() < t.maxLen) t.set(t.value + s); return true; }
        if (searchFocus && search.length() < 32) { search += s; scrollT[tab] = 0; return true; }
        return false;
    }

    @Override public boolean mouseScrolled(double x, double y, double h, double v) { wheel += (float) v; return true; }

    // ------------------------------------------------------------------------------------------------ helpers
    private int A(int col) { return ColorUtil.alphaMul(col, ga); }
    private boolean hitRaw(float x, float y, float w, float h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private boolean hit(float x, float y, float w, float h) { return hitRaw(x, y, w, h) && my >= cy && my < cy + ch; }
    private float an(Object k, float target, float speed) {
        float v = anim.getOrDefault(k, target);
        v = Anim.to(v, target, speed);
        anim.put(k, v);
        return v;
    }
    private void say(String s) { status = s; statusUntil = System.currentTimeMillis() + 3500; }

    private boolean button(DrawContext c, float x, float y, float w, float h, String label, boolean active) {
        boolean hov = hit(x, y, w, h);
        float a = an(label + x + y, hov ? 1f : 0f, 18f);
        Render2D.rrect(c, x, y, w, h, 6, A(active ? ColorUtil.withAlpha(T.accent, 0x80) : ColorUtil.lerp(T.card, ColorUtil.withAlpha(T.accent, 0x50), a * 0.7f)));
        Render2D.outline(c, x, y, w, h, 6, A(active ? T.accent : T.outline));
        Render2D.textC(c, label, x + w / 2f, y + h / 2f - 4, A(T.text), false);
        return hov && lPress;
    }

    // ------------------------------------------------------------------------------------------------ render
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        var mc = Pulse.mc;
        if (mc.world == null || mc.options.hudHidden) Anim.frame();
        open = Anim.to(open, closing ? 0f : 1f, 14f);
        if (closing && open < 0.03f) { mc.setScreen(parent); return; }
        ga = Anim.easeOutCubic(open);
        T = ThemeManager.cur();
        mx = mouseX; my = mouseY;
        long win = mc.getWindow().getHandle();
        lDown = GLFW.glfwGetMouseButton(win, 0) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, 1) == GLFW.GLFW_PRESS;
        lPress = lDown && !lPrev; rPress = r && !rPrev; lPrev = lDown; rPrev = r;
        if (!lDown) dragObj = null;

        c.fill(0, 0, width, height, A(0x70000000));
        c.fillGradient(0, 0, width, height / 2, A(0x30000000), 0);

        ww = Math.min(780, width - 24); wh = Math.min(480, height - 24);
        wx = (width - ww) / 2f; wy = (height - wh) / 2f + (1f - ga) * 16f;
        float SB = 150;
        Render2D.glow(c, wx, wy, ww, wh, 12, A(0xA0000000), 7);
        Render2D.rrect(c, wx, wy, ww, wh, 12, A(T.bg));
        Render2D.rrect(c, wx + 1, wy + 1, SB, wh - 2, 11, A(T.panel));
        Render2D.rect(c, wx + SB - 12, wy + 1, 12, wh - 2, A(T.panel));
        Render2D.rect(c, wx + SB, wy + 12, 1, wh - 24, A(T.outline));
        Render2D.outline(c, wx, wy, ww, wh, 12, A(T.outline));
        Render2D.gradH(c, wx + 14, wy + 1, ww - 28, 1, A(ColorUtil.withAlpha(T.accent, 0x90)), A(ColorUtil.withAlpha(T.accent2, 0x30)));

        sidebar(c, SB);

        cx = wx + SB + 14; cw = ww - SB - 28; cy = wy + 46; ch = wh - 46 - 12;
        header(c);
        c.enableScissor((int) cx - 2, (int) cy, (int) (cx + cw + 2), (int) (cy + ch));
        if (tab == 5) themesTab(c); else modulesTab(c);
        c.disableScissor();

        // scrolling
        if (hitRaw(cx, cy, cw, ch)) scrollT[tab] -= wheel * 30f;
        wheel = 0;
        float max = Math.max(0, totalH - ch);
        scrollT[tab] = Math.max(0, Math.min(max, scrollT[tab]));
        scroll[tab] = Anim.to(scroll[tab], scrollT[tab], 16f);
        if (max > 0) {
            float bh = Math.max(24, ch * ch / (ch + max)), by = cy + (ch - bh) * (scroll[tab] / max);
            Render2D.rrect(c, cx + cw + 4, by, 3, bh, 1, A(ColorUtil.withAlpha(T.accent, 0x70)));
        }
        if (System.currentTimeMillis() < statusUntil) {
            float sw = Render2D.tw(status) + 18;
            Render2D.rrect(c, wx + ww - sw - 16, wy + wh - 32, sw, 20, 7, A(0xE0101420));
            Render2D.outline(c, wx + ww - sw - 16, wy + wh - 32, sw, 20, 7, A(ColorUtil.withAlpha(T.accent, 0x80)));
            Render2D.text(c, status, wx + ww - sw - 7, wy + wh - 26, A(T.text));
        }
    }

    private void sidebar(DrawContext c, float SB) {
        Render2D.rrect(c, wx + 16, wy + 16, 24, 24, 8, A(ColorUtil.withAlpha(T.accent, 0x40)));
        Render2D.rrectGradV(c, wx + 21, wy + 21, 14, 14, 4, A(T.accent), A(T.accent2));
        Render2D.gradText(c, "Pulse", wx + 48, wy + 17, TC, true, ga);
        Render2D.text(c, "Visuals  " + "v1.0", wx + 48, wy + 29, A(T.dim));
        float ty = wy + 62;
        if (tabY < 0) tabY = ty + tab * 32;
        tabY = Anim.to(tabY, ty + tab * 32, 16f);
        Render2D.rrect(c, wx + 10, tabY, SB - 20, 28, 8, A(ColorUtil.withAlpha(T.accent, 0x30)));
        Render2D.rrect(c, wx + 10, tabY + 7, 3, 14, 1, A(T.accent));
        for (int i = 0; i < TABS.length; i++) {
            float y = ty + i * 32;
            boolean hov = hitRaw(wx + 10, y, SB - 20, 28);
            tabHover[i] = Anim.to(tabHover[i], hov || i == tab ? 1f : 0f, 14f);
            if (hov && lPress) { tab = i; searchFocus = false; }
            int col = ColorUtil.lerp(T.dim, T.text, tabHover[i]);
            Render2D.circle(c, wx + 26, y + 14, 2.5f, A(i == tab ? T.accent : ColorUtil.withAlpha(T.dim, 0xA0)));
            Render2D.text(c, TABS[i], wx + 38 + tabHover[i] * 2, y + 10, A(col));
            if (i == 4) { Render2D.rect(c, wx + 18, y + 34, SB - 36, 1, A(T.outline)); }
        }
        // HUD editor shortcut
        float by = wy + wh - 74;
        boolean hov = hitRaw(wx + 14, by, SB - 28, 24);
        Render2D.rrect(c, wx + 14, by, SB - 28, 24, 8, A(hov ? ColorUtil.withAlpha(T.accent, 0x60) : T.card));
        Render2D.outline(c, wx + 14, by, SB - 28, 24, 8, A(T.outline));
        Render2D.textC(c, "HUD Editor", wx + SB / 2f, by + 8, A(T.text), false);
        if (hov && lPress) { Pulse.mc.setScreen(new HudEditorScreen(this)); }
        Render2D.text(c, "Profile: " + Render2D.trim(Config.profile, 90), wx + 16, wy + wh - 40, A(T.dim));
        Render2D.text(c, "RShift - close", wx + 16, wy + wh - 28, A(ColorUtil.withAlpha(T.dim, 0x90)));
    }

    private void header(DrawContext c) {
        Render2D.textScaled(c, search.isEmpty() ? TABS[tab] : "Search results", cx, wy + 14, 1.35f, A(T.text), false);
        if (tab == 5) return;
        float sw = Math.min(210, cw * 0.45f), sx = cx + cw - sw, sy = wy + 12;
        boolean hov = hitRaw(sx, sy, sw, 22);
        if (hov && lPress) searchFocus = true; else if (lPress && !hov) searchFocus = false;
        Render2D.rrect(c, sx, sy, sw, 22, 8, A(T.card));
        Render2D.outline(c, sx, sy, sw, 22, 8, A(searchFocus ? T.accent : T.outline));
        boolean blink = searchFocus && (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = search.isEmpty() && !searchFocus ? "Search modules & settings..." : search + (blink ? "|" : "");
        Render2D.text(c, Render2D.trim(shown, (int) sw - 16), sx + 9, sy + 7, A(search.isEmpty() ? ColorUtil.withAlpha(T.dim, 0xB0) : T.text));
    }

    // ------------------------------------------------------------------------------------------------ module list
    private boolean matches(Module m, String q) {
        if (m.name.toLowerCase().contains(q) || m.desc.toLowerCase().contains(q)) return true;
        for (Setting<?> s : m.settings) if (s.name.toLowerCase().contains(q)) return true;
        return false;
    }

    private void modulesTab(DrawContext c) {
        List<Module> list = new ArrayList<>();
        String q = search.trim().toLowerCase();
        for (Module m : Modules.ALL) {
            if (!q.isEmpty() ? matches(m, q) : m.category == CATS[tab]) list.add(m);
        }
        float y = cy - scroll[tab];
        for (Module m : list) {
            float h = card(c, m, cx, y, cw);
            y += h + 7;
        }
        if (list.isEmpty()) Render2D.textC(c, "Nothing found", cx + cw / 2f, cy + 30, A(T.dim), false);
        totalH = y + scroll[tab] - cy;
    }

    private float card(DrawContext c, Module m, float x, float y, float w) {
        m.expandAnim = Anim.to(m.expandAnim, m.expanded ? 1f : 0f, 14f);
        m.guiAnim = Anim.to(m.guiAnim, m.enabled ? 1f : 0f, 16f);
        float e = Anim.easeInOut(m.expandAnim);
        float sh = m.expandAnim > 0.005f ? settingsHeight(m, x, w) : 0f;
        float H = 34 + sh * e;
        boolean vis = y + H > cy && y < cy + ch;
        if (!vis) return H;
        Render2D.rrect(c, x, y, w, H, 9, A(T.card));
        Render2D.outline(c, x, y, w, H, 9, A(ColorUtil.lerp(T.outline, ColorUtil.withAlpha(T.accent, 0x60), m.guiAnim)));
        if (m.guiAnim > 0.02f) Render2D.rrectGradV(c, x + 1, y + 7, 3, 20, 1, A(ColorUtil.alphaMul(T.accent, m.guiAnim)), A(ColorUtil.alphaMul(T.accent2, m.guiAnim)));
        boolean hdr = hit(x, y, w, 34);
        float hv = an(m, hdr ? 1f : 0f, 16f);
        if (hv > 0.02f) Render2D.rrect(c, x + 1, y + 1, w - 2, 32, 8, A(ColorUtil.withAlpha(0xFFFFFF, (int) (0x0A * hv))));
        Render2D.text(c, m.name, x + 14, y + 7, A(ColorUtil.lerp(ColorUtil.lerp(T.dim, T.text, 0.7f), T.text, m.guiAnim)));
        Render2D.textScaled(c, Render2D.trim(m.desc, (int) ((w - 120) / 0.8f)), x + 14, y + 20, 0.8f, A(T.dim), false);
        if (m.bind.isSet()) Render2D.textR(c, "[" + m.bind.display() + "]", x + w - 56, y + 13, A(T.dim), false);
        // switch
        float sx = x + w - 42, sy = y + 10;
        Render2D.rrect(c, sx, sy, 30, 14, 7, A(ColorUtil.lerp(0x38FFFFFF, T.accent, m.guiAnim)));
        Render2D.circle(c, sx + 7 + 16 * m.guiAnim, sy + 7, 5, A(0xFFFFFFFF));
        boolean sw = hit(sx - 4, sy - 3, 38, 20);
        if (lPress && sw) m.toggle();
        else if (hdr && (lPress || rPress) && !sw) m.expanded = !m.expanded;
        // settings
        if (e > 0.01f) {
            c.enableScissor((int) x, (int) Math.max(y + 34, cy), (int) (x + w), (int) Math.min(y + H - 2, cy + ch));
            float sy2 = y + 36;
            boolean interact = e > 0.97f;
            Render2D.rect(c, x + 10, y + 34, w - 20, 1, A(T.outline));
            for (Setting<?> s : m.allSettings()) {
                if (!s.isVisible()) continue;
                sy2 += setting(c, s, x + 12, sy2, w - 24, true, interact) + 1;
            }
            c.disableScissor();
        }
        return H;
    }

    private float settingsHeight(Module m, float x, float w) {
        float h = 40;
        for (Setting<?> s : m.allSettings()) if (s.isVisible()) h += setting(null, s, x + 12, 0, w - 24, false, false) + 1;
        return h - 4;
    }

    // ------------------------------------------------------------------------------------------------ settings
    /** Measures (draw == false) or draws + handles input for one setting row. Returns the row height. */
    private float setting(DrawContext c, Setting<?> s, float x, float y, float w, boolean draw, boolean act) {
        if (s instanceof Setting.Bool b) {
            if (draw) {
                Render2D.text(c, b.name, x, y + 6, A(T.text));
                boolean on = b.on();
                float a = an(b, on ? 1f : 0f, 18f), sx = x + w - 26;
                Render2D.rrect(c, sx, y + 4, 26, 12, 6, A(ColorUtil.lerp(0x38FFFFFF, T.accent, a)));
                Render2D.circle(c, sx + 6 + 14 * a, y + 10, 4.5f, A(0xFFFFFFFF));
                if (act && hit(x, y, w, 20)) { if (lPress) b.toggle(); if (rPress) b.reset(); }
            }
            return 20;
        }
        if (s instanceof Setting.Num n) {
            if (draw) {
                Render2D.text(c, n.name, x, y + 3, A(T.text));
                Render2D.textR(c, n.display(), x + w, y + 3, A(T.dim), false);
                float ty = y + 16;
                Render2D.rrect(c, x, ty, w, 4, 2, A(0x30FFFFFF));
                float cur = an(n, (float) n.norm(), 20f);
                Render2D.rrect(c, x, ty, Math.max(4, w * cur), 4, 2, A(T.accent));
                Render2D.circle(c, x + w * cur, ty + 2, 5, A(0xFFFFFFFF));
                if (act) {
                    if (hit(x - 4, y + 8, w + 8, 18) && lPress) { dragObj = n; dragId = 0; }
                    if (hit(x - 4, y + 8, w + 8, 18) && rPress) n.reset();
                    if (dragObj == n && lDown) n.set(n.min + Math.max(0, Math.min(1, (mx - x) / w)) * (n.max - n.min));
                }
            }
            return 26;
        }
        if (s instanceof Setting.Mode md) {
            if (draw) {
                Render2D.text(c, md.name, x, y + 6, A(T.text));
                String v = md.get();
                float bw = Render2D.tw(v) + 26, bx = x + w - bw;
                boolean hov = hit(bx, y + 1, bw, 18);
                Render2D.rrect(c, bx, y + 1, bw, 18, 6, A(ColorUtil.lerp(0x20FFFFFF, ColorUtil.withAlpha(T.accent, 0x50), an(md, hov ? 1f : 0f, 16f))));
                Render2D.text(c, "<", bx + 5, y + 6, A(T.dim)); Render2D.text(c, ">", bx + bw - 10, y + 6, A(T.dim));
                Render2D.textC(c, v, bx + bw / 2f, y + 6, A(T.text), false);
                if (act && hov) { if (lPress) md.cycle(1); else if (rPress) md.cycle(-1); }
            }
            return 20;
        }
        if (s instanceof Setting.Multi mu) {
            float cxp = x, cyp = y + 15;
            if (draw) Render2D.text(c, mu.name, x, y + 3, A(T.text));
            for (String o : mu.options) {
                float cwid = Render2D.tw(o) + 12;
                if (cxp + cwid > x + w) { cxp = x; cyp += 17; }
                if (draw) {
                    boolean on = mu.has(o), hov = act && hit(cxp, cyp, cwid, 14);
                    float a = an(mu.name + o, on ? 1f : 0f, 16f);
                    Render2D.rrect(c, cxp, cyp, cwid, 14, 7, A(ColorUtil.lerp(hov ? 0x28FFFFFF : 0x18FFFFFF, ColorUtil.withAlpha(T.accent, 0x70), a)));
                    Render2D.textC(c, o, cxp + cwid / 2f, cyp + 3, A(ColorUtil.lerp(T.dim, T.text, a)), false);
                    if (hov && lPress) mu.toggle(o);
                }
                cxp += cwid + 4;
            }
            return cyp - y + 19;
        }
        if (s instanceof Setting.Color col) return colorRow(c, col, x, y, w, draw, act);
        if (s instanceof Setting.Bind bd) {
            if (draw) {
                Render2D.text(c, bd.name, x, y + 6, A(T.text));
                boolean ls = listening == bd;
                String v = ls ? "Press a key..." : bd.display();
                float bw = Math.max(46, Render2D.tw(v) + 16), bx = x + w - bw;
                boolean hov = act && hit(bx, y + 1, bw, 18);
                Render2D.rrect(c, bx, y + 1, bw, 18, 6, A(ls ? ColorUtil.withAlpha(T.accent, 0x70) : hov ? 0x30FFFFFF : 0x1CFFFFFF));
                if (ls) Render2D.outline(c, bx, y + 1, bw, 18, 6, A(T.accent));
                Render2D.textC(c, v, bx + bw / 2f, y + 6, A(ls ? T.text : T.dim), false);
                if (hov) { if (lPress) listening = bd; else if (rPress) bd.set(-1); }
            }
            return 20;
        }
        if (s instanceof Setting.Text tx) {
            if (draw) {
                Render2D.text(c, tx.name, x, y + 6, A(T.text));
                boolean ed = editing == tx;
                float bw = Math.min(w * 0.55f, w - Render2D.tw(tx.name) - 10), bx = x + w - bw;
                boolean hov = act && hit(bx, y + 1, bw, 18);
                Render2D.rrect(c, bx, y + 1, bw, 18, 6, A(ed ? ColorUtil.withAlpha(T.accent, 0x40) : hov ? 0x30FFFFFF : 0x1CFFFFFF));
                if (ed) Render2D.outline(c, bx, y + 1, bw, 18, 6, A(T.accent));
                String shown = tx.value + (ed && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
                int tw = Render2D.tw(shown);
                if (tw > bw - 12) shown = shown.substring(Math.max(0, shown.length() - (int) ((bw - 12) / 5.5f)));
                Render2D.text(c, shown, bx + 6, y + 6, A(tx.value.isEmpty() && !ed ? ColorUtil.withAlpha(T.dim, 0x80) : T.text));
                if (hov && lPress) editing = tx;
                else if (lPress && ed && !hov) editing = null;
            }
            return 20;
        }
        return 0;
    }

    private float[] hsbOf(Setting.Color col, boolean second) {
        float[] a = hsb.computeIfAbsent(col, k -> new float[8]);
        int off = second ? 4 : 0;
        int rgb = second ? col.second : col.value;
        // store {h,s,b,rgbMarker}
        if (a[off + 3] != (float) (rgb & 0xFFFFFF) || a[off + 3] == 0 && a[off] == 0 && a[off + 1] == 0 && a[off + 2] == 0) {
            float[] v = ColorUtil.toHsb(rgb);
            a[off] = v[0]; a[off + 1] = v[1]; a[off + 2] = v[2]; a[off + 3] = rgb & 0xFFFFFF;
        }
        return a;
    }

    private float colorRow(DrawContext c, Setting.Color col, float x, float y, float w, boolean draw, boolean act) {
        float panel = colorPanelHeight(col);
        float o = anim.getOrDefault(col, 0f);
        boolean isOpen = openSet.containsKey(col);
        o = Anim.to(o, isOpen ? 1f : 0f, 14f);
        anim.put(col, o);
        float h = 22 + panel * Anim.easeInOut(o);
        if (!draw) return 22 + (isOpen ? panel : 0) * 0 + panel * Anim.easeInOut(o);
        Render2D.text(c, col.name, x, y + 7, A(T.text));
        float sx = x + w - 30;
        Render2D.rrect(c, sx - 1, y + 3, 32, 16, 6, A(0x30FFFFFF));
        // checker-ish alpha preview
        Render2D.rrect(c, sx, y + 4, 30, 14, 5, A(0xFF3A3F50));
        Render2D.rrect(c, sx, y + 4, 30, 14, 5, A(col.get()));
        Render2D.textR(c, col.mode, sx - 6, y + 7, A(T.dim), false);
        boolean hov = act && hit(x, y, w, 22);
        if (hov) { if (lPress) { if (isOpen) openSet.remove(col); else openSet.put(col, true); } if (rPress) col.reset(); }
        if (o > 0.01f) {
            c.enableScissor((int) x - 2, (int) Math.max(y + 22, cy), (int) (x + w + 2), (int) Math.min(y + h, cy + ch));
            float py = y + 24;
            boolean ia = act && o > 0.97f;
            // mode chips
            float chx = x;
            for (String m : Setting.Color.MODES) {
                float cwid = Render2D.tw(m) + 12;
                boolean on = col.mode.equals(m), hv = ia && hit(chx, py, cwid, 14);
                Render2D.rrect(c, chx, py, cwid, 14, 7, A(on ? ColorUtil.withAlpha(T.accent, 0x70) : hv ? 0x28FFFFFF : 0x16FFFFFF));
                Render2D.textC(c, m, chx + cwid / 2f, py + 3, A(on ? T.text : T.dim), false);
                if (hv && lPress) col.mode = m;
                chx += cwid + 4;
            }
            py += 20;
            float[] p = hsbOf(col, false);
            py = hsbSliders(c, col, p, false, py, x, w, ia);
            // alpha
            py = miniSlider(c, "Alpha", col, 10, py, x, w, col.alpha / 255f, ColorUtil.withAlpha(col.value, 0), 0xFF000000 | col.value, 0, ia, v -> col.alpha = Math.round(v * 255));
            if (col.mode.equals("Gradient")) {
                Render2D.text(c, "Second colour", x, py + 1, A(T.dim)); py += 12;
                float[] p2 = hsbOf(col, true);
                py = hsbSliders(c, col, p2, true, py, x, w, ia);
            }
            if (col.animated()) {
                py = miniSlider(c, "Speed", col, 11, py, x, w, (col.speed - 0.1f) / 4.9f, 0xFF404860, T.accent, 0, ia, v -> col.speed = 0.1f + v * 4.9f);
            }
            c.disableScissor();
        }
        return h;
    }

    private float colorPanelHeight(Setting.Color col) {
        float h = 20 + 16 * 3 + 16 + 4; // modes + HSB + alpha + pad
        if (col.mode.equals("Gradient")) h += 12 + 16 * 3;
        if (col.animated()) h += 16;
        return h;
    }

    private float hsbSliders(DrawContext c, Setting.Color col, float[] p, boolean second, float py, float x, float w, boolean ia) {
        int off = second ? 4 : 0, id = second ? 4 : 1;
        final float[] pp = p;
        float hue = p[off], sat = p[off + 1], bri = p[off + 2];
        py = miniSlider(c, "Hue", col, id, py, x, w, hue, -1, -1, 1, ia, v -> { pp[off] = v; applyHsb(col, pp, second); });
        py = miniSlider(c, "Sat", col, id + 1, py, x, w, sat, ColorUtil.hsb(hue, 0, bri), ColorUtil.hsb(hue, 1, bri), 0, ia, v -> { pp[off + 1] = v; applyHsb(col, pp, second); });
        py = miniSlider(c, "Bright", col, id + 2, py, x, w, bri, 0xFF000000, ColorUtil.hsb(hue, sat, 1), 0, ia, v -> { pp[off + 2] = v; applyHsb(col, pp, second); });
        return py;
    }

    private void applyHsb(Setting.Color col, float[] p, boolean second) {
        int off = second ? 4 : 0;
        int rgb = ColorUtil.hsb(p[off], p[off + 1], p[off + 2]) & 0xFFFFFF;
        p[off + 3] = rgb;
        if (second) col.second = rgb; else col.value = rgb;
    }

    private float miniSlider(DrawContext c, String label, Object key, int id, float y, float x, float w, float norm, int left, int right, int rainbow, boolean act, java.util.function.Consumer<Float> set) {
        Render2D.text(c, label, x, y + 2, A(T.dim));
        float bx = x + 40, bw = w - 40 - 6;
        if (rainbow == 1) {
            int n = 24;
            for (int i = 0; i < n; i++) c.fill(Math.round(bx + bw * i / n), Math.round(y + 3), Math.round(bx + bw * (i + 1) / n), Math.round(y + 11), A(ColorUtil.hsb(i / (float) n, 0.75f, 1f)));
        } else Render2D.gradH(c, bx, y + 3, bw, 8, A(left), A(right));
        Render2D.outline(c, bx, y + 3, bw, 8, 0, A(0x30FFFFFF));
        Render2D.circle(c, bx + bw * Math.max(0, Math.min(1, norm)), y + 7, 5, A(0xFFFFFFFF));
        if (act) {
            if (hit(bx - 4, y, bw + 8, 14) && lPress) { dragObj = key; dragId = id; }
            if (dragObj == key && dragId == id && lDown) set.accept(Math.max(0f, Math.min(1f, (mx - bx) / bw)));
        }
        return y + 16;
    }

    // ------------------------------------------------------------------------------------------------ themes & configs
    private float section(DrawContext c, String title, float y) {
        Render2D.text(c, title, cx, y + 2, A(T.accent));
        Render2D.rect(c, cx + Render2D.tw(title) + 8, y + 6, cw - Render2D.tw(title) - 8, 1, A(T.outline));
        return y + 18;
    }

    private void themesTab(DrawContext c) {
        float y = cy - scroll[5];
        boolean act = true;
        y = section(c, "Themes", y);
        List<Theme> all = ThemeManager.all();
        int cols = 3;
        float cwid = (cw - 8 * (cols - 1)) / cols, chh = 46;
        int idx = 0;
        List<Object> entries = new ArrayList<>(all);
        entries.add("Custom");
        for (Object en : entries) {
            Theme t = en instanceof Theme th ? th : ThemeManager.cur();
            String name = en instanceof Theme th2 ? th2.name : "Custom";
            if (name.equals("Custom") && !(en instanceof Theme)) t = new Theme("Custom", ThemeManager.cBg.base(), ThemeManager.cPanel.base(), ThemeManager.cCard.base(), ThemeManager.cAccent.base() | 0xFF000000, ThemeManager.cAccent2.base() | 0xFF000000, ThemeManager.cText.base() | 0xFF000000, 0xFF888888, 0x22FFFFFF);
            float x = cx + (idx % cols) * (cwid + 8), yy = y + (idx / cols) * (chh + 8);
            boolean sel = ThemeManager.currentName().equals(name), hov = hit(x, yy, cwid, chh);
            Render2D.rrect(c, x, yy, cwid, chh, 9, A(t.panel | 0xFF000000));
            Render2D.rrect(c, x + 8, yy + 28, cwid - 16, 4, 2, A(0x20FFFFFF));
            Render2D.rrect(c, x + 8, yy + 28, (cwid - 16) * 0.65f, 4, 2, A(t.accent));
            Render2D.circle(c, x + cwid - 14, yy + 13, 4.5f, A(t.accent));
            Render2D.circle(c, x + cwid - 28, yy + 13, 4.5f, A(t.accent2));
            Render2D.text(c, name, x + 10, yy + 9, A(t.text));
            Render2D.outline(c, x, yy, cwid, chh, 9, A(sel ? T.accent : hov ? ColorUtil.withAlpha(T.accent, 0x60) : T.outline));
            if (sel) Render2D.circle(c, x + 10, yy + 38, 0f, 0);
            if (hov && lPress) { ThemeManager.select(name); say("Theme: " + name); }
            if (hov && rPress && en instanceof Theme th3 && ThemeManager.USER.contains(th3)) { ThemeManager.deleteUser(th3.name); say("Deleted theme " + th3.name); }
            idx++;
        }
        y += ((idx + cols - 1) / cols) * (chh + 8) + 4;
        y = section(c, "Custom Theme Builder", y);
        for (Setting<?> s : ThemeManager.CUSTOM) y += setting(c, s, cx, y, cw, true, true) + 1;
        y += 4;
        y += setting(c, themeName, cx, y, cw, true, true) + 2;
        if (button(c, cx, y, 120, 20, "Use Custom", ThemeManager.currentName().equals("Custom"))) { ThemeManager.select("Custom"); say("Custom theme applied"); }
        if (button(c, cx + 128, y, 140, 20, "Save As Theme", false) && !themeName.value.isBlank()) { ThemeManager.saveCustomAs(themeName.value.trim()); ThemeManager.select(themeName.value.trim()); say("Saved theme " + themeName.value.trim()); }
        y += 34;

        y = section(c, "Config Profiles", y);
        float chx = cx;
        for (String p : Config.list()) {
            float wch = Render2D.tw(p) + 20;
            if (chx + wch > cx + cw) { chx = cx; y += 24; }
            boolean on = p.equals(Config.profile), hov = hit(chx, y, wch, 20);
            Render2D.rrect(c, chx, y, wch, 20, 8, A(on ? ColorUtil.withAlpha(T.accent, 0x70) : hov ? 0x30FFFFFF : T.card));
            Render2D.outline(c, chx, y, wch, 20, 8, A(on ? T.accent : T.outline));
            Render2D.textC(c, p, chx + wch / 2f, y + 6, A(T.text), false);
            if (hov && lPress) { say(Config.load(p) ? "Loaded " + p : "Could not load " + p); }
            if (hov && rPress && !p.equals("default")) { Config.delete(p); say("Deleted " + p); }
            chx += wch + 6;
        }
        y += 28;
        Render2D.textScaled(c, "Click: load  |  Right click: delete", cx, y - 4, 0.8f, A(T.dim), false);
        y += 8;
        y += setting(c, profileName, cx, y, cw, true, true) + 2;
        float bx = cx;
        if (button(c, bx, y, 110, 20, "Save Current", false)) { Config.saveCurrent(); say("Saved profile " + Config.profile); }
        bx += 116;
        if (button(c, bx, y, 130, 20, "Save As New", false) && !profileName.value.isBlank()) { Config.save(profileName.value.trim()); say("Created " + Config.profile); profileName.set(""); }
        bx += 136;
        if (button(c, bx, y, 130, 20, "Export (Clipboard)", false)) { Pulse.mc.keyboard.setClipboard(Config.export()); say("Config copied to clipboard"); }
        bx += 136;
        if (button(c, bx, y, 130, 20, "Import (Clipboard)", false)) say(Config.importString(Pulse.mc.keyboard.getClipboard()) ? "Config imported" : "Clipboard has no Pulse config");
        y += 34;

        y = section(c, "Friends", y);
        chx = cx;
        if (Friends.NAMES.isEmpty()) { Render2D.text(c, "No friends yet. Add by name below or aim at a player.", cx, y + 2, A(T.dim)); y += 16; }
        for (String f : new ArrayList<>(Friends.NAMES)) {
            float wch = Render2D.tw(f) + 24;
            if (chx + wch > cx + cw) { chx = cx; y += 24; }
            boolean hov = hit(chx, y, wch, 20);
            int fc = Modules.FRIENDS != null ? Modules.FRIENDS.color.get() : 0xFF6EDC9A;
            Render2D.rrect(c, chx, y, wch, 20, 8, A(hov ? 0x30FFFFFF : ColorUtil.withAlpha(fc, 0x30)));
            Render2D.outline(c, chx, y, wch, 20, 8, A(ColorUtil.withAlpha(fc, 0xA0)));
            Render2D.text(c, f, chx + 9, y + 6, A(T.text));
            Render2D.text(c, "x", chx + wch - 11, y + 6, A(T.dim));
            if (hov && lPress) { Friends.remove(f); say("Removed " + f); }
            chx += wch + 6;
        }
        y += 26;
        y += setting(c, friendName, cx, y, cw, true, true) + 2;
        if (button(c, cx, y, 110, 20, "Add Friend", false) && !friendName.value.isBlank()) { Friends.add(friendName.value.trim()); say("Added " + friendName.value.trim()); friendName.set(""); }
        if (button(c, cx + 116, y, 150, 20, "Add Targeted Player", false)) {
            if (Pulse.mc.targetedEntity instanceof PlayerEntity p) { Friends.add(p.getName().getString()); say("Added " + p.getName().getString()); } else say("Aim at a player first");
        }
        y += 34;
        totalH = y + scroll[5] - cy;
    }
}
