package dev.pulse.gui;

import dev.pulse.Pulse;
import dev.pulse.config.Config;
import dev.pulse.module.HudModule;
import dev.pulse.modules.Modules;
import dev.pulse.theme.Theme;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.Anim;
import dev.pulse.util.ColorUtil;
import dev.pulse.util.Render2D;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Drag & drop HUD editor: grid / edge / centre / widget snapping, scroll-wheel scaling, widget palette. */
public class HudEditorScreen extends Screen {
    public static boolean snap = true;
    public static int grid = 4;

    private final Screen parent;
    private HudModule drag;
    private float dox, doy;
    private boolean lPrev, rPrev;
    private float open;
    private boolean closing;
    private final List<Float> vGuides = new ArrayList<>(), hGuides = new ArrayList<>();

    public HudEditorScreen(Screen parent) { super(Text.literal("HUD Editor")); this.parent = parent; }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public void close() { requestClose(); }

    private void requestClose() { if (!closing) { closing = true; Config.saveCurrent(); } }

    @Override public boolean keyPressed(KeyInput in) {
        if (in.key() == GLFW.GLFW_KEY_ESCAPE || in.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { requestClose(); }
        return true;
    }

    private float[] rect(HudModule h) {
        float s = h.scale.f();
        int sw = width, sh = height;
        return new float[]{h.nx * sw + h.anchorX() * s, h.ny * sh, Math.max(14, h.w * s), Math.max(10, h.h * s)};
    }

    private HudModule hovered(double mx, double my) {
        List<HudModule> l = Modules.hud();
        for (int i = l.size() - 1; i >= 0; i--) {
            HudModule h = l.get(i);
            if (!h.enabled) continue;
            float[] r = rect(h);
            if (mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3]) return h;
        }
        return null;
    }

    @Override public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        HudModule h = hovered(mx, my);
        if (h != null) h.scale.set(h.scale.d() + Math.signum(vAmount) * 0.05);
        return true;
    }

    private boolean button(DrawContext c, float x, float y, float w, float hh, String label, boolean active, int mx, int my, boolean press, float a) {
        Theme t = ThemeManager.cur();
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + hh;
        Render2D.rrect(c, x, y, w, hh, 6, ColorUtil.alphaMul(active ? ColorUtil.withAlpha(t.accent, 0x90) : hov ? 0xCC2A3042 : t.card, a));
        Render2D.outline(c, x, y, w, hh, 6, ColorUtil.alphaMul(active ? t.accent : t.outline, a));
        Render2D.textC(c, label, x + w / 2f, y + hh / 2f - 4, ColorUtil.alphaMul(t.text, a), false);
        return hov && press;
    }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        Theme t = ThemeManager.cur();
        var mc = Pulse.mc;
        Anim.frame();
        open = Anim.to(open, closing ? 0f : 1f, 14f);
        if (closing && open < 0.03f) { mc.setScreen(parent); return; }
        float a = open;
        long w = mc.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(w, 0) == GLFW.GLFW_PRESS, r = GLFW.glfwGetMouseButton(w, 1) == GLFW.GLFW_PRESS;
        boolean lPress = l && !lPrev, rPress = r && !rPrev;
        lPrev = l; rPrev = r;

        c.fill(0, 0, width, height, ColorUtil.alphaMul(0x55000000, a));
        if (snap) {
            int step = Math.max(8, grid * 8);
            for (int x = 0; x < width; x += step) c.fill(x, 0, x + 1, height, ColorUtil.alphaMul(0x10FFFFFF, a));
            for (int y = 0; y < height; y += step) c.fill(0, y, width, y + 1, ColorUtil.alphaMul(0x10FFFFFF, a));
        }
        c.fill(width / 2, 0, width / 2 + 1, height, ColorUtil.alphaMul(ColorUtil.withAlpha(t.accent, 0x26), a));
        c.fill(0, height / 2, width, height / 2 + 1, ColorUtil.alphaMul(ColorUtil.withAlpha(t.accent, 0x26), a));

        List<HudModule> all = Modules.hud();
        for (HudModule h : all) {
            if (!h.enabled) continue;
            try { h.renderHud(c, delta, true); } catch (Throwable ignored) {}
        }

        HudModule hov = drag != null ? drag : hovered(mx, my);
        // toolbar
        float tbw = 330, tbx = (width - tbw) / 2f, tby = 8;
        Render2D.glow(c, tbx, tby, tbw, 26, 8, ColorUtil.alphaMul(0x80000000, a), 4);
        Render2D.rrect(c, tbx, tby, tbw, 26, 8, ColorUtil.alphaMul(t.bg, a));
        boolean over = false;
        if (button(c, tbx + 6, tby + 4, 70, 18, "Snap: " + (snap ? "On" : "Off"), snap, mx, my, lPress, a)) { snap = !snap; over = true; }
        if (button(c, tbx + 80, tby + 4, 60, 18, "Grid " + grid, false, mx, my, lPress, a)) { grid = grid >= 16 ? 2 : grid + 2; over = true; }
        if (button(c, tbx + 144, tby + 4, 90, 18, "Reset Layout", false, mx, my, lPress, a)) { for (HudModule h : all) { h.nx = h.defNx; h.ny = h.defNy; h.scale.reset(); } over = true; }
        if (button(c, tbx + 238, tby + 4, 86, 18, "Save & Close", false, mx, my, lPress, a)) { requestClose(); over = true; }
        Render2D.textC(c, "Drag to move  -  Wheel to scale  -  Right click to reset widget", width / 2f, tby + 32, ColorUtil.alphaMul(t.dim, a), true);

        // palette of disabled widgets
        List<HudModule> off = new ArrayList<>();
        for (HudModule h : all) if (!h.enabled) off.add(h);
        if (!off.isEmpty()) {
            float px = 8, py = height - 22;
            Render2D.text(c, "Add widget:", px, py + 4, ColorUtil.alphaMul(t.dim, a));
            px += Render2D.tw("Add widget:") + 8;
            for (HudModule h : off) {
                float cw = Render2D.tw(h.name) + 14;
                if (px + cw > width - 8) { px = 8; py -= 22; }
                if (button(c, px, py, cw, 18, h.name, false, mx, my, lPress, a)) { h.setEnabled(true, false); h.nx = h.defNx; h.ny = h.defNy; over = true; }
                px += cw + 4;
            }
        }

        // outlines
        for (HudModule h : all) {
            if (!h.enabled) continue;
            float[] rc = rect(h);
            boolean hv = h == hov;
            Render2D.outline(c, rc[0] - 2, rc[1] - 2, rc[2] + 4, rc[3] + 4, 4, ColorUtil.alphaMul(hv ? t.accent : ColorUtil.withAlpha(t.text, 0x40), a));
            if (hv) {
                Render2D.rect(c, rc[0] - 2, rc[1] - 12, Render2D.tw(h.name) + 8, 10, ColorUtil.alphaMul(0xCC000000, a));
                Render2D.text(c, h.name + "  x" + String.format("%.2f", h.scale.d()), rc[0] + 2, rc[1] - 11, ColorUtil.alphaMul(t.text, a));
            }
        }

        // interaction
        if (!over) {
            if (lPress && hov != null && drag == null) {
                drag = hov;
                float[] rc = rect(hov);
                dox = mx - rc[0]; doy = my - rc[1];
            }
            if (rPress && hov != null) { hov.nx = hov.defNx; hov.ny = hov.defNy; hov.scale.reset(); }
        }
        vGuides.clear(); hGuides.clear();
        if (drag != null) {
            if (!l) drag = null;
            else moveDrag(mx, my, all);
        }
        int gc = ColorUtil.alphaMul(t.accent, a);
        for (float gx : vGuides) c.fill(Math.round(gx), 0, Math.round(gx) + 1, height, gc);
        for (float gy : hGuides) c.fill(0, Math.round(gy), width, Math.round(gy) + 1, gc);
    }

    private void moveDrag(int mx, int my, List<HudModule> all) {
        HudModule h = drag;
        float s = h.scale.f();
        float[] rc = rect(h);
        float W = rc[2], H = rc[3];
        float x = mx - dox, y = my - doy;
        if (snap && !(GLFW.glfwGetKey(Pulse.mc.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS)) {
            float g = Math.max(1, grid);
            x = Math.round(x / g) * g; y = Math.round(y / g) * g;
            float th = 6;
            float[] xs = {0, width - W, (width - W) / 2f, 4, width - W - 4};
            float[] ys = {0, height - H, (height - H) / 2f, 4, height - H - 4};
            for (float cand : xs) if (Math.abs(x - cand) < th) { x = cand; vGuides.add(x + (cand == (width - W) / 2f ? W / 2f : (cand <= 4 ? 0 : W))); break; }
            for (float cand : ys) if (Math.abs(y - cand) < th) { y = cand; hGuides.add(y + (cand == (height - H) / 2f ? H / 2f : (cand <= 4 ? 0 : H))); break; }
            for (HudModule o : all) {
                if (o == h || !o.enabled) continue;
                float[] orc = rect(o);
                float[] oxs = {orc[0], orc[0] + orc[2], orc[0] + orc[2] / 2f};
                for (float ox : oxs) {
                    if (Math.abs(x - ox) < th) { x = ox; vGuides.add(ox); }
                    else if (Math.abs(x + W - ox) < th) { x = ox - W; vGuides.add(ox); }
                    else if (Math.abs(x + W / 2f - ox) < th) { x = ox - W / 2f; vGuides.add(ox); }
                }
                float[] oys = {orc[1], orc[1] + orc[3], orc[1] + orc[3] / 2f};
                for (float oy : oys) {
                    if (Math.abs(y - oy) < th) { y = oy; hGuides.add(oy); }
                    else if (Math.abs(y + H - oy) < th) { y = oy - H; hGuides.add(oy); }
                    else if (Math.abs(y + H / 2f - oy) < th) { y = oy - H / 2f; hGuides.add(oy); }
                }
            }
        }
        x = Math.max(0, Math.min(width - W, x));
        y = Math.max(0, Math.min(height - H, y));
        h.nx = (x - h.anchorX() * s) / width;
        h.ny = y / height;
    }
}
