package dev.pulse.mixin;

import dev.pulse.modules.Modules;
import net.minecraft.client.render.block.entity.BeaconBlockEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BeaconBlockEntityRenderer.class)
public abstract class BeaconRendererMixin {
    @Inject(method = {"render", "submit"}, at = @At("HEAD"), cancellable = true)
    private void pulse$beam(CallbackInfo ci) {
        if (Modules.NO_RENDER != null && Modules.NO_RENDER.has("Beacon Beams")) ci.cancel();
    }
}
