package dev.pulse.mixin;

import dev.pulse.modules.Modules;
import net.minecraft.client.gui.hud.BossBarHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BossBarHud.class)
public abstract class BossBarHudMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void pulse$render(CallbackInfo ci) {
        if (Modules.BOSSBAR != null && Modules.BOSSBAR.enabled || Modules.NO_RENDER != null && Modules.NO_RENDER.has("Boss Bars")) ci.cancel();
    }
}
