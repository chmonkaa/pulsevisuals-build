package dev.pulse.mixin;

import dev.pulse.Pulse;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/** FreeLook: swap the camera rotation for the free-look angles (player rotation is untouched). */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", ordinal = 0))
    private void pulse$freeLook(Args args) {
        if (Pulse.freeLook) {
            args.set(0, Pulse.freeYaw);
            args.set(1, Pulse.freePitch);
        }
    }
}
