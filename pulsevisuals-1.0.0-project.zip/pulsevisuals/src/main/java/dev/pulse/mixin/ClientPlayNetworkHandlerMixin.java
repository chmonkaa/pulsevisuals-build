package dev.pulse.mixin;

import dev.pulse.Pulse;
import dev.pulse.util.Stats;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Read-only packet observers (RETURN => runs on the main thread only). Nothing is sent or altered. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityStatus", at = @At("RETURN"))
    private void pulse$status(EntityStatusS2CPacket packet, CallbackInfo ci) {
        if (packet.getStatus() == 35 && Pulse.mc.world != null) {
            Entity e = packet.getEntity(Pulse.mc.world);
            if (e != null) Pulse.onPop(e);
        }
    }

    @Inject(method = "onWorldTimeUpdate", at = @At("RETURN"))
    private void pulse$time(CallbackInfo ci) { Stats.onTimePacket(); }

    @Inject(method = "onGameJoin", at = @At("RETURN"))
    private void pulse$join(CallbackInfo ci) { Stats.resetWorld(); }
}
