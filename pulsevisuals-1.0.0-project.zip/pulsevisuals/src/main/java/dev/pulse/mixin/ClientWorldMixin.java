package dev.pulse.mixin;

import dev.pulse.modules.Modules;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** CustomSky colours. If the target methods do not exist in a given game version the injections are skipped. */
@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void pulse$sky(CallbackInfoReturnable<Integer> cir) {
        if (Modules.SKY != null && Modules.SKY.enabled) cir.setReturnValue(Modules.SKY.skyColor(cir.getReturnValue()));
    }

    @Inject(method = "getCloudsColor", at = @At("RETURN"), cancellable = true)
    private void pulse$clouds(CallbackInfoReturnable<Integer> cir) {
        if (Modules.SKY != null && Modules.SKY.enabled) cir.setReturnValue(Modules.SKY.cloudColor(cir.getReturnValue()));
    }
}
