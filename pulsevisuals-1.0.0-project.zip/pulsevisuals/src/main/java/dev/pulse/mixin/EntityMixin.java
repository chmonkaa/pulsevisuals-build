package dev.pulse.mixin;

import dev.pulse.Pulse;
import dev.pulse.modules.Modules;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void pulse$freeLookInput(double dx, double dy, CallbackInfo ci) {
        if (Pulse.freeLook && Modules.FREELOOK != null && (Object) this == Pulse.mc.player) {
            float m = Modules.FREELOOK.mul();
            Pulse.freeYaw += (float) dx * 0.15f * m;
            Pulse.freePitch = MathHelper.clamp(Pulse.freePitch + (float) dy * 0.15f * m * (Modules.FREELOOK.invert() ? -1f : 1f), -90f, 90f);
            ci.cancel();
        }
    }
}
