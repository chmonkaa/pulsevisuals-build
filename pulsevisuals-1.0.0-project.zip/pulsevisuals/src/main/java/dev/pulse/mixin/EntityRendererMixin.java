package dev.pulse.mixin;

import dev.pulse.modules.Modules;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Hides the vanilla nametag of players while the custom NameTags module is active. */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    private void pulse$hideVanillaTag(Entity entity, double distSq, CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof PlayerEntity && Modules.NAME_TAGS != null && Modules.NAME_TAGS.enabled && Modules.NAME_TAGS.hideVanilla.on()) cir.setReturnValue(false);
    }
}
