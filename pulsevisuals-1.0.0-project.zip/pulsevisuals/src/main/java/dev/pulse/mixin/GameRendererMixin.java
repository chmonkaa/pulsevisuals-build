package dev.pulse.mixin;

import dev.pulse.Pulse;
import dev.pulse.modules.Modules;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    /** FOV: SmoothZoom multiplier + remember the final value for our own projection math. */
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void pulse$fov(CallbackInfoReturnable<Float> cir) {
        float f = cir.getReturnValue();
        if (Modules.ZOOM != null && Modules.ZOOM.enabled) f *= Modules.ZOOM.frame(); else Pulse.zoomMul = 1f;
        Pulse.fov = f;
        cir.setReturnValue(f);
    }

    /** AspectRatio: rescale the horizontal projection. */
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void pulse$aspect(CallbackInfoReturnable<Matrix4f> cir) {
        if (Pulse.aspect > 0f && Pulse.mc != null) {
            float window = (float) Pulse.mc.getWindow().getFramebufferWidth() / Math.max(1, Pulse.mc.getWindow().getFramebufferHeight());
            Matrix4f m = new Matrix4f(cir.getReturnValue());
            m.scale(window / Pulse.aspect, 1f, 1f);
            cir.setReturnValue(m);
        }
    }

    /** TotemPop: suppress the vanilla floating totem when our custom animation is active. */
    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true)
    private void pulse$totem(ItemStack stack, CallbackInfo ci) {
        if (Modules.TOTEM != null && Modules.TOTEM.enabled && Modules.TOTEM.hideVanilla.on() && stack.isOf(Items.TOTEM_OF_UNDYING)) ci.cancel();
    }

    /** Fullbright (night vision mode). */
    @Inject(method = "getNightVisionStrength", at = @At("RETURN"), cancellable = true)
    private static void pulse$nightVision(CallbackInfoReturnable<Float> cir) {
        if (Modules.FULLBRIGHT != null && Modules.FULLBRIGHT.nightVision()) cir.setReturnValue(1.0f);
    }
}
