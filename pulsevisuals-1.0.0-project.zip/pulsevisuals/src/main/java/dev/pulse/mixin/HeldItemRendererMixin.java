package dev.pulse.mixin;

import dev.pulse.Pulse;
import dev.pulse.modules.Modules;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** ViewModel + SwingAnimations: both hook the hand-pivot transforms of the first-person item renderer. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "applyEquipOffset", at = @At("HEAD"))
    private void pulse$viewModel(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
        if (Modules.VIEW_MODEL != null && Modules.VIEW_MODEL.enabled) {
            boolean main = arm == Pulse.mc.options.getMainArm().getValue();
            Modules.VIEW_MODEL.apply(matrices, arm, main);
        }
    }

    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
    private void pulse$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        if (Modules.SWING != null && Modules.SWING.replaces()) {
            Modules.SWING.apply(matrices, arm, swingProgress);
            ci.cancel();
        }
    }
}
