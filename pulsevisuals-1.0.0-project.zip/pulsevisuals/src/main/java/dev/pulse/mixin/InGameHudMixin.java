package dev.pulse.mixin;

import dev.pulse.modules.Modules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void pulse$scoreboard(CallbackInfo ci) {
        if (Modules.SCOREBOARD != null && Modules.SCOREBOARD.enabled) ci.cancel();
    }

    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    private void pulse$hotbar(CallbackInfo ci) {
        if (Modules.HOTBAR != null && Modules.HOTBAR.enabled) ci.cancel();
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void pulse$crosshair(CallbackInfo ci) {
        if (Modules.CROSSHAIR != null && Modules.CROSSHAIR.enabled || Modules.NO_RENDER != null && Modules.NO_RENDER.has("Vanilla Crosshair")) ci.cancel();
    }

    @Inject(method = {"renderOverlay", "renderTextureOverlay"}, at = @At("HEAD"), cancellable = true)
    private void pulse$overlay(DrawContext context, Identifier texture, float opacity, CallbackInfo ci) {
        if (Modules.NO_RENDER != null && Modules.NO_RENDER.has("Pumpkin Overlay") && texture != null && texture.getPath().contains("pumpkinblur")) ci.cancel();
    }
}
