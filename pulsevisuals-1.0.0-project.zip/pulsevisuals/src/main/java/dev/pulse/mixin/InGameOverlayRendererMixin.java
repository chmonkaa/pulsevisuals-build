package dev.pulse.mixin;

import dev.pulse.modules.Modules;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Static handlers with minimal signatures: valid for both static and instance targets across versions. */
@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void pulse$fire(CallbackInfo ci) {
        if (Modules.NO_RENDER != null && Modules.NO_RENDER.has("Fire Overlay")) ci.cancel();
    }

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true)
    private static void pulse$water(CallbackInfo ci) {
        if (Modules.NO_RENDER != null && Modules.NO_RENDER.has("Water Overlay")) ci.cancel();
    }

    @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true)
    private static void pulse$wall(CallbackInfo ci) {
        if (Modules.NO_RENDER != null && Modules.NO_RENDER.has("In-Wall Overlay")) ci.cancel();
    }
}
