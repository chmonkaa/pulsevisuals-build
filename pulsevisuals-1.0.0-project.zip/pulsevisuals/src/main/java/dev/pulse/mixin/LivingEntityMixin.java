package dev.pulse.mixin;

import dev.pulse.Pulse;
import dev.pulse.modules.Modules;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    /** Swing speed (client-side visual duration of the local player's arm swing only). */
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void pulse$swingSpeed(CallbackInfoReturnable<Integer> cir) {
        if (Modules.SWING != null && Modules.SWING.enabled && (Object) this == Pulse.mc.player) cir.setReturnValue(Modules.SWING.duration(cir.getReturnValue()));
    }
}
