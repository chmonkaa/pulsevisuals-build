package dev.pulse.mixin;

import dev.pulse.modules.Modules;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void pulse$scroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (Modules.ZOOM != null && Modules.ZOOM.onScroll(vertical)) ci.cancel();
    }
}
