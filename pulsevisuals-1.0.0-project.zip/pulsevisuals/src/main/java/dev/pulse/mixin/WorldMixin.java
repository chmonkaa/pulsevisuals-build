package dev.pulse.mixin;

import dev.pulse.Pulse;
import dev.pulse.modules.Modules;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** ClientTime / ClientWeather — only ever applied to the client's own world instance. */
@Mixin(World.class)
public abstract class WorldMixin {
    private boolean pulse$isMine() { return Pulse.mc != null && (Object) this == Pulse.mc.world; }

    @Inject(method = "getRainGradient", at = @At("RETURN"), cancellable = true)
    private void pulse$rain(float delta, CallbackInfoReturnable<Float> cir) {
        if (Modules.WEATHER != null && Modules.WEATHER.enabled && pulse$isMine()) cir.setReturnValue(Modules.WEATHER.rain(cir.getReturnValue()));
    }

    @Inject(method = "getThunderGradient", at = @At("RETURN"), cancellable = true)
    private void pulse$thunder(float delta, CallbackInfoReturnable<Float> cir) {
        if (Modules.WEATHER != null && Modules.WEATHER.enabled && pulse$isMine()) cir.setReturnValue(Modules.WEATHER.thunder(cir.getReturnValue()));
    }

    @Inject(method = "getTimeOfDay", at = @At("RETURN"), cancellable = true)
    private void pulse$time(CallbackInfoReturnable<Long> cir) {
        if (Modules.TIME != null && Modules.TIME.enabled && pulse$isMine()) cir.setReturnValue(Modules.TIME.custom());
    }

    @Inject(method = "getSkyAngle", at = @At("RETURN"), cancellable = true)
    private void pulse$skyAngle(float tickDelta, CallbackInfoReturnable<Float> cir) {
        if (Modules.TIME != null && Modules.TIME.enabled && pulse$isMine()) {
            double d = ((Modules.TIME.custom() % 24000L) / 24000.0) - 0.25;
            d = d - Math.floor(d);
            double e = 0.5 - Math.cos(d * Math.PI) / 2.0;
            cir.setReturnValue((float) ((d * 2.0 + e) / 3.0));
        }
    }
}
