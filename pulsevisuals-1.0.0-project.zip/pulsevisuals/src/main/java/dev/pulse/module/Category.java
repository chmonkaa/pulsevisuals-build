package dev.pulse.module;

public enum Category {
    VISUALS("Visuals"), HUD("HUD"), VIEW("Animations & View"), WORLD("World"), UTILITIES("Utilities");

    public final String title;
    Category(String t) { title = t; }
}
