package dev.pulse.module;

import dev.pulse.Pulse;
import dev.pulse.setting.Setting;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.Render2D;
import net.minecraft.client.gui.DrawContext;

/** A module that owns a draggable on-screen widget. Position is stored normalised (0..1) of the screen. */
public abstract class HudModule extends Module {
    public float nx, ny;
    public final float defNx, defNy;
    public float w = 80, h = 20;
    public final Setting.Num scale = new Setting.Num("Scale", 1.0, 0.5, 3.0, 0.05);

    // optional standard style (call stdStyle() in the constructor)
    public Setting.Bool bg, outline, shadow;
    public Setting.Color bgCol, accent;
    public Setting.Num radius;

    protected HudModule(String name, String desc, float nx, float ny) {
        super(name, desc, Category.HUD);
        this.nx = defNx = nx; this.ny = defNy = ny;
        settings.add(scale);
    }

    protected void stdStyle() {
        bg = add(new Setting.Bool("Background", true));
        bgCol = add(new Setting.Color("Background Color", 0x0E1118, 0xA0));
        radius = add(new Setting.Num("Corner Radius", 6, 0, 14, 1));
        outline = add(new Setting.Bool("Outline", true));
        shadow = add(new Setting.Bool("Soft Shadow", true));
        accent = add(new Setting.Color("Accent", 0x7C9CFF, 0xB48CFF, 255).mode("Theme"));
    }

    /** Draw the widget in local coordinates (0,0 = top-left). Must set {@link #w} and {@link #h}. */
    public abstract void draw(DrawContext c, float td, boolean editing);

    public final void renderHud(DrawContext c, float td, boolean editing) {
        var mc = Pulse.mc;
        float s = scale.f();
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(nx * mc.getWindow().getScaledWidth() + anchorX() * s, ny * mc.getWindow().getScaledHeight());
        m.scale(s, s);
        draw(c, td, editing);
        m.popMatrix();
    }

    protected void panel(DrawContext c, float w, float h) {
        this.w = w; this.h = h;
        if (bg == null || !bg.on()) return;
        if (shadow.on()) Render2D.glow(c, 0, 0, w, h, radius.f(), 0x70000000, 4);
        Render2D.rrect(c, 0, 0, w, h, radius.f(), bgCol.get());
        if (outline.on()) Render2D.outline(c, 0, 0, w, h, radius.f(), ThemeManager.cur().outline);
    }

    /** Horizontal anchor offset in local units (e.g. -w for right-aligned widgets, -w/2 for centred ones). */
    public float anchorX() { return 0f; }

    protected int text() { return ThemeManager.cur().text; }
    protected int dim() { return ThemeManager.cur().dim; }
}
