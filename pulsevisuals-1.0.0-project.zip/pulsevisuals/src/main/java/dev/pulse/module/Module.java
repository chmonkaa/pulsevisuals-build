package dev.pulse.module;

import dev.pulse.Pulse;
import dev.pulse.setting.Setting;
import dev.pulse.util.Notifs;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, desc;
    public final Category category;
    public boolean enabled;

    /** Module specific settings (the generic bind / list settings are appended by {@link #allSettings()}). */
    public final List<Setting<?>> settings = new ArrayList<>();
    public final Setting.Bind bind = new Setting.Bind("Keybind", -1);
    public final Setting.Mode bindMode = new Setting.Mode("Bind Mode", "Toggle", "Toggle", "Hold");
    public final Setting.Bool inList = new Setting.Bool("Show In ArrayList", true);

    /** GUI / ArrayList animation state. */
    public float listAnim, guiAnim, expandAnim;
    public boolean expanded;
    public boolean keyWasDown;

    protected Module(String name, String desc, Category category) {
        this.name = name; this.desc = desc; this.category = category;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public List<Setting<?>> allSettings() {
        List<Setting<?>> l = new ArrayList<>(settings);
        l.add(bind); l.add(bindMode); l.add(inList);
        return l;
    }

    // ---- lifecycle hooks -----------------------------------------------------------------------------------
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    /** World-space rendering (called from the Fabric world render event). */
    public void onWorld(float td) {}
    /** Screen-space overlay rendering (called before HUD widgets). */
    public void onOverlay(DrawContext c, float td) {}

    public void toggle() { setEnabled(!enabled, false); }

    public void setEnabled(boolean v, boolean silent) {
        if (v == enabled) return;
        enabled = v;
        try { if (v) onEnable(); else onDisable(); } catch (Throwable t) { t.printStackTrace(); }
        if (!silent && Pulse.mc != null && Pulse.mc.world != null) Notifs.moduleToggled(this);
    }

    public final boolean on() { return enabled; }
}
