package dev.pulse.modules;

import dev.pulse.Pulse;
import dev.pulse.module.HudModule;
import dev.pulse.setting.Setting;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** HUD widgets, part 1: Watermark, TargetHUD, Keystrokes, ArmorHUD, PotionHUD, CooldownsHUD. */
public final class HudModules {
    private HudModules() {}

    static MinecraftClient mc() { return Pulse.mc; }

    static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 1 && n <= 10 ? r[n] : String.valueOf(n);
    }

    public static String mmss(int ticks) {
        int s = Math.max(0, ticks) / 20;
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    static int durPercent(ItemStack st) {
        if (st.isEmpty() || !st.isDamageable()) return 100;
        return Math.round(100f * (st.getMaxDamage() - st.getDamage()) / st.getMaxDamage());
    }

    // =====================================================================================================
    public static final class Watermark extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "Modern", "Modern", "Compact", "Minimal", "Glass Pill", "Underline"));
        final Setting.Text title = add(new Setting.Text("Client Name", "Pulse", 16));
        final Setting.Text suffix = add(new Setting.Text("Suffix", "Visuals", 16));
        final Setting.Multi info = add(new Setting.Multi("Info", new String[]{"Username", "FPS", "Ping", "Server", "Time", "Coords"}, "Username", "FPS", "Ping"));
        final Setting.Color nameCol = add(new Setting.Color("Name Color", 0x7C9CFF, 0xB48CFF, 255).mode("Theme"));
        final Setting.Bool accentBar = add(new Setting.Bool("Accent Line", true));
        final Setting.Bool timeSeconds = add(new Setting.Bool("Time With Seconds", false));
        final Setting.Num padding = add(new Setting.Num("Padding", 6, 2, 14, 1));

        public Watermark() { super("Watermark", "Client tag with live session info (several styles)", 0.012f, 0.02f); stdStyle(); }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var m = mc();
            List<String> parts = new ArrayList<>();
            if (m.player != null) {
                if (info.has("Username")) parts.add(m.getSession().getUsername());
                if (info.has("FPS")) parts.add(m.getCurrentFps() + " fps");
                if (info.has("Ping") && m.getNetworkHandler() != null) {
                    PlayerListEntry e = m.getNetworkHandler().getPlayerListEntry(m.player.getUuid());
                    parts.add((e != null ? e.getLatency() : 0) + " ms");
                }
                if (info.has("Server")) parts.add(m.getCurrentServerEntry() != null ? m.getCurrentServerEntry().address : "singleplayer");
                if (info.has("Coords")) parts.add((int) m.player.getX() + " " + (int) m.player.getY() + " " + (int) m.player.getZ());
            } else {
                parts.add("Player"); parts.add("144 fps"); parts.add("32 ms");
            }
            if (info.has("Time")) parts.add(LocalTime.now().format(DateTimeFormatter.ofPattern(timeSeconds.on() ? "HH:mm:ss" : "HH:mm")));

            String st = style.get();
            boolean compact = st.equals("Compact"), minimal = st.equals("Minimal"), pill = st.equals("Glass Pill"), underline = st.equals("Underline");
            int pad = padding.i() - (compact ? 2 : 0);
            String rest = String.join("  \u2022  ", parts);
            String nm = title.get() + (compact || suffix.get().isEmpty() ? "" : " " + suffix.get());
            int nw = Render2D.tw(nm), rw = rest.isEmpty() ? 0 : Render2D.tw(rest) + 10;
            float W = nw + rw + pad * 2 + (accentBar.on() && st.equals("Modern") ? 4 : 0), H = 9 + pad * 2 - 2;
            float x0 = pad + (accentBar.on() && st.equals("Modern") ? 4 : 0), ty = (H - 8) / 2f;

            if (minimal || underline) { this.w = W; this.h = H; }
            else if (pill) {
                float oldR = radius.f();
                radius.set((double) (H / 2f));
                panel(c, W, H);
                radius.set((double) oldR);
            } else panel(c, W, H);

            if (st.equals("Modern") && accentBar.on() && !minimal) {
                Render2D.rrectGradV(c, 2, 3, 2, H - 6, 1, accent.get(0f), accent.get(0.5f));
            }
            int shadowText = minimal || underline ? 1 : 0;
            int nwDrawn = Render2D.gradText(c, nm, x0, ty, nameCol, shadowText == 1, 1f);
            if (!rest.isEmpty()) Render2D.text(c, rest, x0 + nwDrawn + 10, ty, dim());
            if (underline) Render2D.gradH(c, 0, H - 1, W, 1, accent.get(0f), accent.get(0.5f));
        }
    }

    // =====================================================================================================
    public static final class TargetHUD extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "Modern", "Modern", "Compact", "Minimal", "Glass"));
        final Setting.Mode head = add(new Setting.Mode("Head", "2D Skin", "2D Skin", "3D Model", "Letter", "None"));
        final Setting.Mode source = add(new Setting.Mode("Target Source", "Both", "Last Hit", "Crosshair", "Both"));
        final Setting.Mode hpText = add(new Setting.Mode("Health Text", "Number", "Number", "Hearts", "Percent", "None"));
        final Setting.Bool armor = add(new Setting.Bool("Show Armor", true));
        final Setting.Bool dist = add(new Setting.Bool("Show Distance", true));
        final Setting.Bool effects = add(new Setting.Bool("Show Effects", true));
        final Setting.Bool absorb = add(new Setting.Bool("Show Absorption", true));
        final Setting.Bool trail = add(new Setting.Bool("Damage Trail Bar", true));
        final Setting.Bool friendTag = add(new Setting.Bool("Friend Highlight", true));
        final Setting.Bool popAnim = add(new Setting.Bool("Pop-In Animation", true));
        final Setting.Num hold = add(new Setting.Num("Hold Time (s)", 4.0, 1, 15, 0.5));
        final Setting.Num smooth = add(new Setting.Num("Smooth Speed", 8.0, 1, 20, 0.5));
        final Setting.Color hpCol = add(new Setting.Color("Health Color", 0x5BE585, 0xE5565B, 255));
        final Setting.Bool hpDynamic = add(new Setting.Bool("Color By Health", true));

        private LivingEntity cur;
        private float vis, hp, trailHp;

        public TargetHUD() { super("TargetHUD", "Animated target card: head, smooth HP, armor, distance, effects", 0.5f, 0.62f); stdStyle(); }

        @Override public float anchorX() { return -w / 2f; }

        private LivingEntity pick() {
            var m = mc();
            if (m.player == null) return null;
            LivingEntity t = null;
            if (!source.is("Crosshair") && Pulse.target != null && Pulse.target.isAlive()
                    && System.currentTimeMillis() - Pulse.targetTime < hold.d() * 1000) t = Pulse.target;
            if (t == null && !source.is("Last Hit") && m.targetedEntity instanceof LivingEntity le) t = le;
            return t;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var m = mc();
            LivingEntity t = editing && m.player != null ? m.player : pick();
            vis = Anim.to(vis, t != null ? 1f : 0f, 12f);
            if (t != null && t != cur) { cur = t; hp = t.getHealth(); trailHp = hp; }
            if (cur == null || vis < 0.02f) { if (vis < 0.02f) cur = null; return; }
            LivingEntity e = cur;
            float max = Math.max(1f, e.getMaxHealth());
            hp = Anim.to(hp, e.getHealth(), smooth.f());
            trailHp = Anim.to(trailHp, e.getHealth(), smooth.f() * 0.35f);
            float frac = Anim.clamp01(hp / max);

            String st = style.get();
            boolean compact = st.equals("Compact"), minimal = st.equals("Minimal");
            boolean hasHead = !head.is("None") && !minimal;
            int headSize = compact ? 24 : 32;
            float W = compact ? 118 : minimal ? 110 : 150;
            float H = compact ? 34 : minimal ? 28 : 46;
            boolean showArmor = armor.on() && !compact && !minimal;
            if (showArmor) H += 12;

            var mx = c.getMatrices();
            mx.pushMatrix();
            float k = popAnim.on() ? 0.9f + 0.1f * Anim.easeOutBack(vis) : 1f;
            mx.translate(W / 2f, H / 2f); mx.scale(k, k); mx.translate(-W / 2f, -H / 2f);

            boolean friend = friendTag.on() && Friends.is(e);
            this.w = W; this.h = H;
            if (st.equals("Glass")) {
                Render2D.glow(c, 0, 0, W, H, 8, ColorUtil.alphaMul(0x90000000, vis), 5);
                Render2D.rrect(c, 0, 0, W, H, 8, ColorUtil.alphaMul(0x30FFFFFF, vis));
                Render2D.rrect(c, 1, 1, W - 2, H - 2, 7, ColorUtil.alphaMul(bgCol.get(), vis));
                Render2D.outline(c, 0, 0, W, H, 8, ColorUtil.alphaMul(0x40FFFFFF, vis));
            } else if (bg.on()) {
                if (shadow.on()) Render2D.glow(c, 0, 0, W, H, radius.f(), ColorUtil.alphaMul(0x70000000, vis), 4);
                Render2D.rrect(c, 0, 0, W, H, radius.f(), ColorUtil.alphaMul(bgCol.get(), vis));
                if (outline.on()) Render2D.outline(c, 0, 0, W, H, radius.f(), ColorUtil.alphaMul(friend ? 0xFF5BE585 : ThemeManager.cur().outline, vis));
            }

            float tx = 6;
            if (hasHead) {
                float hy = compact ? 5 : 7;
                if (head.is("3D Model")) {
                    int x1 = 5, y1 = (int) hy - 2, x2 = x1 + headSize + 4, y2 = y1 + headSize + 8;
                    float sway = (float) Math.sin(Anim.time() * 1.4) * 26f;
                    InventoryScreen.drawEntity(c, x1, y1, x2, y2, headSize - 2, 0.0625f, (x1 + x2) / 2f + sway, y1 + 12, e);
                } else if (head.is("2D Skin") && e instanceof PlayerEntity && m.getNetworkHandler() != null) {
                    PlayerListEntry pe = m.getNetworkHandler().getPlayerListEntry(e.getUuid());
                    if (pe != null) PlayerSkinDrawer.draw(c, pe.getSkinTextures(), 6, (int) hy, headSize);
                    else Render2D.rrect(c, 6, hy, headSize, headSize, 5, ColorUtil.alphaMul(0xFF2A3042, vis));
                } else {
                    Render2D.rrect(c, 6, hy, headSize, headSize, 6, ColorUtil.alphaMul(accent.get(0f), vis * 0.35f));
                    Render2D.textC(c, e.getName().getString().substring(0, 1).toUpperCase(), 6 + headSize / 2f, hy + headSize / 2f - 4, ColorUtil.alphaMul(text(), vis), true);
                }
                tx = 6 + headSize + 6;
            }
            float rightEdge = W - 6;
            String name = Render2D.trim(e.getName().getString(), (int) (rightEdge - tx - (dist.on() && !compact ? 34 : 0)));
            int nameCol = friend ? 0xFF7CE8A4 : text();
            Render2D.text(c, name, tx, compact ? 5 : minimal ? 4 : 8, ColorUtil.alphaMul(nameCol, vis));
            if (dist.on() && !compact) Render2D.textR(c, String.format(Locale.ROOT, "%.1fm", m.player.distanceTo(e)), rightEdge, minimal ? 4 : 8, ColorUtil.alphaMul(dim(), vis), false);

            float by = compact ? 18 : minimal ? 16 : 22, bh = compact ? 5 : 7, bw = rightEdge - tx;
            Render2D.rrect(c, tx, by, bw, bh, bh / 2f, ColorUtil.alphaMul(0x55000000, vis));
            if (trail.on()) Render2D.rrect(c, tx, by, Math.max(bh, bw * Anim.clamp01(trailHp / max)), bh, bh / 2f, ColorUtil.alphaMul(0x66FFFFFF, vis * 0.6f));
            int barCol = hpDynamic.on() ? ColorUtil.health(frac) : ColorUtil.lerp(0xFF000000 | hpCol.second, 0xFF000000 | hpCol.value, frac);
            Render2D.rrect(c, tx, by, Math.max(bh, bw * frac), bh, bh / 2f, ColorUtil.alphaMul(barCol, vis));
            float ab = e.getAbsorptionAmount();
            if (absorb.on() && ab > 0) Render2D.rrect(c, tx, by + bh + 1, Math.min(bw, bw * ab / max), 2, 1, ColorUtil.alphaMul(0xFFFFD25A, vis));

            String ht = switch (hpText.get()) {
                case "Hearts" -> String.format(Locale.ROOT, "%.1f \u2764", e.getHealth() / 2f);
                case "Percent" -> Math.round(frac * 100) + "%";
                case "Number" -> String.format(Locale.ROOT, "%.1f", e.getHealth() + (absorb.on() ? ab : 0));
                default -> "";
            };
            if (!ht.isEmpty()) Render2D.textScaled(c, ht, tx, by + bh + (compact ? 4 : 5), 0.8f, ColorUtil.alphaMul(dim(), vis), false);
            if (compact && dist.on()) Render2D.textR(c, String.format(Locale.ROOT, "%.0fm", m.player.distanceTo(e)), rightEdge, by + bh + 4, ColorUtil.alphaMul(dim(), vis), false);

            if (effects.on() && !compact && !minimal) {
                float ex = tx;
                for (StatusEffectInstance inst : e.getStatusEffects()) {
                    if (ex > rightEdge - 8) break;
                    int col = 0xFF000000 | inst.getEffectType().value().getColor();
                    Render2D.rrect(c, ex + 38, by + bh + 4, 6, 6, 2, ColorUtil.alphaMul(col, vis));
                    ex += 8;
                }
            }
            if (showArmor) {
                float ax = 6;
                float ay = H - 13;
                for (EquipmentSlot s : ARMOR) {
                    ItemStack is = e.getEquippedStack(s);
                    if (!is.isEmpty()) {
                        Render2D.item(c, is, ax, ay, 0.62f, false);
                        if (is.isDamageable()) Render2D.rrect(c, ax, ay + 10, 10 * durPercent(is) / 100f, 1, 0, ColorUtil.alphaMul(ColorUtil.health(durPercent(is) / 100f), vis));
                    }
                    ax += 12;
                }
                ItemStack hand = e.getMainHandStack();
                if (!hand.isEmpty()) Render2D.item(c, hand, ax + 4, ay, 0.62f, false);
            }
            mx.popMatrix();
        }
    }

    // =====================================================================================================
    public static final class Keystrokes extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "Rounded", "Rounded", "Square", "Minimal", "Outline"));
        final Setting.Bool mouse = add(new Setting.Bool("Mouse Buttons", true));
        final Setting.Bool cps = add(new Setting.Bool("Show CPS", true));
        final Setting.Bool space = add(new Setting.Bool("Space Bar", true));
        final Setting.Bool sneakSprint = add(new Setting.Bool("Shift / Sprint Keys", false));
        final Setting.Num size = add(new Setting.Num("Key Size", 24, 16, 40, 1));
        final Setting.Num gap = add(new Setting.Num("Gap", 3, 0, 10, 1));
        final Setting.Num animSpeed = add(new Setting.Num("Animation Speed", 16, 4, 40, 1));
        final Setting.Color idle = add(new Setting.Color("Idle Color", 0x0E1118, 0x90));
        final Setting.Color pressed = add(new Setting.Color("Pressed Color", 0x7C9CFF, 0xB48CFF, 0xE0).mode("Theme"));
        final Setting.Color textCol = add(new Setting.Color("Text Color", 0xE8EAF2, 255));
        private final float[] anim = new float[9];

        public Keystrokes() { super("Keystrokes", "WASD / mouse key display with CPS counter", 0.012f, 0.55f); }

        private void key(DrawContext c, int i, String label, float x, float y, float kw, float kh, boolean down, String sub) {
            anim[i] = Anim.to(anim[i], down ? 1f : 0f, animSpeed.f());
            float a = anim[i];
            float r = style.is("Rounded") ? 5 : style.is("Square") ? 0 : style.is("Outline") ? 4 : 3;
            int idleC = idle.get();
            int col = ColorUtil.lerp(idleC, pressed.get(a * 0.3f), a);
            if (!style.is("Minimal") || a > 0.02f) Render2D.rrect(c, x, y, kw, kh, r, style.is("Outline") ? ColorUtil.lerp(0x00000000, pressed.get(), a * 0.5f) : col);
            if (style.is("Outline")) Render2D.outline(c, x, y, kw, kh, r, ColorUtil.lerp(0x55FFFFFF, pressed.get(), a));
            int tc = ColorUtil.lerp(textCol.get(), 0xFF101218, a * 0.55f);
            float s = 1f;
            if (sub != null) {
                Render2D.textC(c, label, x + kw / 2f, y + kh / 2f - 8, tc, false);
                Render2D.textScaled(c, sub, x + kw / 2f - Render2D.tw(sub) * 0.4f, y + kh / 2f + 2, 0.8f, ColorUtil.lerp(dim(), 0xFF202430, a * 0.5f), false);
            } else Render2D.textC(c, label, x + kw / 2f, y + kh / 2f - 4, tc, false);
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var o = mc().options;
            float S = size.f(), G = gap.f();
            float y = 0;
            key(c, 0, "W", S + G, y, S, S, o.forwardKey.isPressed(), null);
            y += S + G;
            key(c, 1, "A", 0, y, S, S, o.leftKey.isPressed(), null);
            key(c, 2, "S", S + G, y, S, S, o.backKey.isPressed(), null);
            key(c, 3, "D", (S + G) * 2, y, S, S, o.rightKey.isPressed(), null);
            y += S + G;
            float fullW = S * 3 + G * 2;
            if (sneakSprint.on()) {
                key(c, 7, "Shift", 0, y, (fullW - G) / 2f, S * 0.75f, o.sneakKey.isPressed(), null);
                key(c, 8, "Sprint", (fullW - G) / 2f + G, y, (fullW - G) / 2f, S * 0.75f, o.sprintKey.isPressed(), null);
                y += S * 0.75f + G;
            }
            if (space.on()) {
                key(c, 4, "\u2014", 0, y, fullW, S * 0.6f, o.jumpKey.isPressed(), null);
                y += S * 0.6f + G;
            }
            if (mouse.on()) {
                float bw = (fullW - G) / 2f;
                key(c, 5, "LMB", 0, y, bw, S, o.attackKey.isPressed(), cps.on() ? Stats.cpsLeft() + " CPS" : null);
                key(c, 6, "RMB", bw + G, y, bw, S, o.useKey.isPressed(), cps.on() ? Stats.cpsRight() + " CPS" : null);
                y += S;
            }
            this.w = fullW; this.h = y;
        }
    }

    // =====================================================================================================
    public static final class ArmorHUD extends HudModule {
        final Setting.Mode orient = add(new Setting.Mode("Orientation", "Horizontal", "Horizontal", "Vertical"));
        final Setting.Mode dur = add(new Setting.Mode("Durability", "Percent", "None", "Bar", "Number", "Percent"));
        final Setting.Bool hands = add(new Setting.Bool("Show Hands", true));
        final Setting.Bool empty = add(new Setting.Bool("Show Empty Slots", false));
        final Setting.Bool colorText = add(new Setting.Bool("Color By Durability", true));
        final Setting.Num spacing = add(new Setting.Num("Spacing", 4, 0, 14, 1));
        final Setting.Num warn = add(new Setting.Num("Warn Below %", 20, 0, 60, 1));

        public ArmorHUD() { super("ArmorHUD", "Armor and hand items with durability readout", 0.35f, 0.9f); stdStyle(); }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var p = mc().player;
            List<ItemStack> items = new ArrayList<>();
            if (p != null) {
                for (EquipmentSlot s : ARMOR) items.add(p.getEquippedStack(s));
                if (hands.on()) { items.add(p.getMainHandStack()); items.add(p.getOffHandStack()); }
            } else { items.add(new ItemStack(Items.DIAMOND_HELMET)); items.add(new ItemStack(Items.DIAMOND_CHESTPLATE)); items.add(new ItemStack(Items.DIAMOND_LEGGINGS)); items.add(new ItemStack(Items.DIAMOND_BOOTS)); }
            if (!empty.on()) items.removeIf(ItemStack::isEmpty);
            boolean hor = orient.is("Horizontal");
            float cell = 16 + spacing.f();
            boolean txt = dur.is("Number") || dur.is("Percent");
            float itemW = hor ? (txt ? Math.max(20, 16 + spacing.f()) : cell) : (txt ? 16 + 4 + 30 : 16);
            float itemH = hor ? (txt || dur.is("Bar") ? 16 + 11 : 16) : 16 + spacing.f();
            int n = Math.max(1, items.size());
            float W = (hor ? itemW * n : itemW) + 8, H = (hor ? itemH : itemH * n) + 8;
            if (items.isEmpty()) { this.w = 40; this.h = 10; return; }
            panel(c, W, H);
            for (int i = 0; i < items.size(); i++) {
                ItemStack st = items.get(i);
                float x = 4 + (hor ? i * itemW : 0), y = 4 + (hor ? 0 : i * itemH);
                Render2D.item(c, st, x + (hor && txt ? (itemW - 16) / 2f : 0), y, 1f, true);
                if (st.isEmpty() || !st.isDamageable()) continue;
                int pct = durPercent(st);
                int col = colorText.on() ? ColorUtil.health(pct / 100f) : text();
                if (pct < warn.i()) col = ColorUtil.lerp(col, 0xFFFF5A5A, 0.5f + 0.5f * (float) Math.sin(Anim.time() * 8));
                String s = dur.is("Percent") ? pct + "%" : dur.is("Number") ? String.valueOf(st.getMaxDamage() - st.getDamage()) : null;
                if (s != null) {
                    if (hor) Render2D.textC(c, s, x + (itemW - spacing.f()) / 2f + (txt ? 0 : 8), y + 18, col, false);
                    else Render2D.text(c, s, x + 20, y + 4, col);
                } else if (dur.is("Bar")) {
                    float bx = hor ? x : x + 18, by = hor ? y + 18 : y + 12;
                    Render2D.rrect(c, bx, by, 16, 2, 1, 0x66000000);
                    Render2D.rrect(c, bx, by, 16 * pct / 100f, 2, 1, col);
                }
            }
        }
    }

    // =====================================================================================================
    public static final class PotionHUD extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "List", "List", "Compact", "Bars"));
        final Setting.Mode sort = add(new Setting.Mode("Sort", "Duration", "Duration", "Name"));
        final Setting.Bool timer = add(new Setting.Bool("Show Timer", true));
        final Setting.Bool level = add(new Setting.Bool("Show Level", true));
        final Setting.Bool tint = add(new Setting.Bool("Effect Color Dot", true));
        final Setting.Bool hideAmbient = add(new Setting.Bool("Hide Beacon Effects", false));
        final Setting.Num maxEntries = add(new Setting.Num("Max Entries", 8, 1, 16, 1));
        final Setting.Num flash = add(new Setting.Num("Flash Below (s)", 10, 0, 30, 1));
        final Setting.Num width = add(new Setting.Num("Width", 112, 80, 200, 2));

        public PotionHUD() { super("PotionHUD", "Active effects with timers and levels", 0.012f, 0.3f); stdStyle(); }

        private record Row(String name, int amp, int dur, int max, int color, boolean inf) {}

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var p = mc().player;
            List<Row> rows = new ArrayList<>();
            if (p != null && !editing || p != null && !p.getStatusEffects().isEmpty()) {
                for (StatusEffectInstance i : p.getStatusEffects()) {
                    if (hideAmbient.on() && i.isAmbient()) continue;
                    rows.add(new Row(i.getEffectType().value().getName().getString(), i.getAmplifier() + 1, i.getDuration(), Math.max(1, i.getDuration()), 0xFF000000 | i.getEffectType().value().getColor(), i.isInfinite()));
                }
            }
            if (rows.isEmpty() && editing) {
                rows.add(new Row("Speed", 2, 1840, 3600, 0xFF7CAFC6, false));
                rows.add(new Row("Strength", 1, 900, 3600, 0xFF932423, false));
                rows.add(new Row("Regeneration", 2, 240, 900, 0xFFCD5CAB, false));
            }
            if (rows.isEmpty()) { this.w = 60; this.h = 10; return; }
            if (sort.is("Duration")) rows.sort((a, b) -> Integer.compare(b.dur, a.dur)); else rows.sort(Comparator.comparing(r -> r.name));
            if (rows.size() > maxEntries.i()) rows = rows.subList(0, maxEntries.i());
            boolean compact = style.is("Compact"), bars = style.is("Bars");
            float rh = compact ? 12 : bars ? 17 : 14, W = width.f(), H = rows.size() * rh + 6;
            panel(c, W, H);
            for (int i = 0; i < rows.size(); i++) {
                Row r = rows.get(i);
                float y = 3 + i * rh;
                boolean low = !r.inf && flash.d() > 0 && r.dur < flash.d() * 20;
                float fl = low ? 0.55f + 0.45f * (float) Math.sin(Anim.time() * 7) : 1f;
                if (tint.on()) Render2D.rrect(c, 5, y + 3, 4, compact ? 5 : 6, 2, r.color);
                String nm = r.name + (level.on() && r.amp > 1 ? " " + roman(r.amp) : "");
                Render2D.text(c, Render2D.trim(nm, (int) W - 50), 13, y + (bars ? 1 : 2), ColorUtil.alphaMul(text(), fl));
                if (timer.on()) Render2D.textR(c, r.inf ? "\u221E" : mmss(r.dur), W - 5, y + (bars ? 1 : 2), ColorUtil.alphaMul(low ? 0xFFFF7A7A : dim(), fl), false);
                if (bars) {
                    float bw = W - 18;
                    Render2D.rrect(c, 13, y + 11, bw, 2, 1, 0x55000000);
                    Render2D.rrect(c, 13, y + 11, r.inf ? bw : bw * Anim.clamp01(r.dur / (float) Math.max(r.max, r.dur)), 2, 1, r.color);
                }
            }
        }
    }

    // =====================================================================================================
    public static final class CooldownsHUD extends HudModule {
        static final String[] NAMES = {"Ender Pearl", "Chorus Fruit", "Golden Apple", "Enchanted Apple", "Shield", "Totem", "Trident", "Goat Horn", "Wind Charge", "Mace"};
        static final Item[] ITEMS = {Items.ENDER_PEARL, Items.CHORUS_FRUIT, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE, Items.SHIELD, Items.TOTEM_OF_UNDYING, Items.TRIDENT, Items.GOAT_HORN, Items.WIND_CHARGE, Items.MACE};
        final Setting.Mode style = add(new Setting.Mode("Style", "List", "List", "Icons"));
        final Setting.Multi items = add(new Setting.Multi("Tracked Items", NAMES, "Ender Pearl", "Chorus Fruit", "Golden Apple", "Enchanted Apple", "Shield", "Totem"));
        final Setting.Bool ready = add(new Setting.Bool("Show Ready Items", true));
        final Setting.Bool counts = add(new Setting.Bool("Show Item Count", true));
        final Setting.Bool seconds = add(new Setting.Bool("Show Seconds", true));
        final Setting.Bool bar = add(new Setting.Bool("Progress Bar", true));
        final Setting.Num width = add(new Setting.Num("Width", 108, 80, 180, 2));
        final Setting.Color busy = add(new Setting.Color("Cooldown Color", 0xE5707A, 0xF0B070, 255));
        final Setting.Color ok = add(new Setting.Color("Ready Color", 0x6EDC9A, 255));
        private final float[] prev = new float[ITEMS.length], total = new float[ITEMS.length], remain = new float[ITEMS.length];
        private final ItemStack[] stacks = new ItemStack[ITEMS.length];

        public CooldownsHUD() { super("CooldownsHUD", "Item cooldown timers (pearls, chorus, apples, shield, totems...)", 0.012f, 0.42f); stdStyle(); }

        @Override public void onTick() {
            var p = mc().player;
            if (p == null) return;
            var cm = p.getItemCooldownManager();
            for (int i = 0; i < ITEMS.length; i++) {
                if (stacks[i] == null) stacks[i] = new ItemStack(ITEMS[i]);
                float pr = cm.getCooldownProgress(stacks[i], 0f);
                if (pr > 0f) {
                    if (prev[i] > pr) { total[i] = 1f / (prev[i] - pr); }
                    remain[i] = total[i] > 0 ? pr * total[i] : 0f;
                } else { total[i] = 0; remain[i] = 0; }
                prev[i] = pr;
            }
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var p = mc().player;
            List<Integer> shown = new ArrayList<>();
            for (int i = 0; i < ITEMS.length; i++) {
                if (!items.has(NAMES[i])) continue;
                boolean cd = prev[i] > 0f, has = p != null && p.getInventory().count(ITEMS[i]) > 0;
                if (cd || (ready.on() && has) || editing) shown.add(i);
            }
            if (shown.isEmpty()) { this.w = 60; this.h = 10; return; }
            if (style.is("Icons")) {
                float cell = 22;
                float W = shown.size() * cell + 6, H = cell + 6;
                panel(c, W, H);
                for (int k = 0; k < shown.size(); k++) {
                    int i = shown.get(k);
                    float x = 4 + k * cell, y = 4;
                    boolean cd = prev[i] > 0f || (editing && i == 0);
                    float pr = editing && i == 0 ? 0.6f : prev[i];
                    Render2D.item(c, stacks[i] == null ? (stacks[i] = new ItemStack(ITEMS[i])) : stacks[i], x, y, 1f, false);
                    if (cd) {
                        Render2D.rect(c, x, y + 16 * (1 - pr), 16, 16 * pr, 0x99000000);
                        if (seconds.on()) Render2D.textC(c, String.format(Locale.ROOT, "%.0f", Math.max(0.1, remain[i] / 20f)), x + 8, y + 4, 0xFFFFFFFF, true);
                    } else Render2D.rect(c, x, y + 17, 16, 1, ok.get());
                }
                return;
            }
            float W = width.f(), rh = 18, H = shown.size() * rh + 6;
            panel(c, W, H);
            for (int k = 0; k < shown.size(); k++) {
                int i = shown.get(k);
                float y = 3 + k * rh;
                boolean cd = prev[i] > 0f || (editing && i == 0);
                float pr = editing && i == 0 ? 0.6f : prev[i];
                if (stacks[i] == null) stacks[i] = new ItemStack(ITEMS[i]);
                Render2D.item(c, stacks[i], 4, y, 1f, false);
                Render2D.text(c, NAMES[i], 24, y + 1, text());
                int cnt = p != null ? p.getInventory().count(ITEMS[i]) : 1;
                String right = cd ? (seconds.on() ? String.format(Locale.ROOT, "%.1fs", Math.max(0.1f, remain[i] / 20f)) : "wait") : (counts.on() ? "x" + cnt : "ready");
                Render2D.textR(c, right, W - 5, y + 1, cd ? busy.get() : ok.get(), false);
                if (bar.on()) {
                    Render2D.rrect(c, 24, y + 11, W - 30, 2, 1, 0x55000000);
                    Render2D.rrect(c, 24, y + 11, (W - 30) * (cd ? 1f - pr : 1f), 2, 1, cd ? busy.get() : ok.get());
                }
            }
        }
    }
}
