package dev.pulse.modules;

import dev.pulse.Pulse;
import dev.pulse.mixin.BossBarHudAccessor;
import dev.pulse.module.Category;
import dev.pulse.module.HudModule;
import dev.pulse.module.Module;
import dev.pulse.setting.Setting;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ClientBossBar;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;

/** HUD widgets, part 2. */
public final class HudModules2 {
    private HudModules2() {}

    // =====================================================================================================
    public static final class InfoHUD extends HudModule {
        final Setting.Multi elements = add(new Setting.Multi("Elements", new String[]{"FPS", "Ping", "TPS", "Speed", "Time", "Memory", "Server"}, "FPS", "Ping", "TPS"));
        final Setting.Mode layout = add(new Setting.Mode("Layout", "Vertical", "Vertical", "Horizontal"));
        final Setting.Mode style = add(new Setting.Mode("Style", "Chips", "Chips", "Plain", "Two Tone"));
        final Setting.Bool colorize = add(new Setting.Bool("Color By Value", true));
        final Setting.Bool seconds = add(new Setting.Bool("Time With Seconds", false));
        final Setting.Num spacing = add(new Setting.Num("Row Spacing", 2, 0, 8, 1));

        public InfoHUD() { super("Info (FPS/Ping/TPS)", "FPS, ping, TPS, speed, time, memory", 0.012f, 0.075f); stdStyle(); }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var m = Pulse.mc;
            List<String[]> rows = new ArrayList<>(); // label, value
            List<Integer> cols = new ArrayList<>();
            if (elements.has("FPS")) { int f = m.getCurrentFps(); rows.add(new String[]{"FPS", String.valueOf(f)}); cols.add(f >= 100 ? 0xFF6EDC9A : f >= 50 ? 0xFFF0D070 : 0xFFE5707A); }
            if (elements.has("Ping")) {
                int ping = 0;
                if (m.player != null && m.getNetworkHandler() != null) { var e = m.getNetworkHandler().getPlayerListEntry(m.player.getUuid()); if (e != null) ping = e.getLatency(); }
                rows.add(new String[]{"Ping", ping + " ms"}); cols.add(ping < 80 ? 0xFF6EDC9A : ping < 160 ? 0xFFF0D070 : 0xFFE5707A);
            }
            if (elements.has("TPS")) { float t = Stats.tps; rows.add(new String[]{"TPS", t < 0 ? "--" : String.format(Locale.ROOT, "%.1f", t)}); cols.add(t < 0 ? dim() : t > 18 ? 0xFF6EDC9A : t > 14 ? 0xFFF0D070 : 0xFFE5707A); }
            if (elements.has("Speed")) { rows.add(new String[]{"Speed", String.format(Locale.ROOT, "%.1f b/s", Stats.speed)}); cols.add(text()); }
            if (elements.has("Time")) { rows.add(new String[]{"Time", LocalTime.now().format(DateTimeFormatter.ofPattern(seconds.on() ? "HH:mm:ss" : "HH:mm"))}); cols.add(text()); }
            if (elements.has("Memory")) { Runtime r = Runtime.getRuntime(); long used = (r.totalMemory() - r.freeMemory()) >> 20; rows.add(new String[]{"RAM", used + "/" + (r.maxMemory() >> 20) + " MB"}); cols.add(text()); }
            if (elements.has("Server")) { rows.add(new String[]{"IP", m.getCurrentServerEntry() != null ? m.getCurrentServerEntry().address : "local"}); cols.add(text()); }
            if (rows.isEmpty()) { w = 40; h = 10; return; }
            boolean hor = layout.is("Horizontal"), chips = style.is("Chips");
            float x = 0, y = 0, maxW = 0, rowH = 14 + spacing.f();
            // measure
            float[] ws = new float[rows.size()];
            for (int i = 0; i < rows.size(); i++) ws[i] = Render2D.tw(rows.get(i)[0]) + 6 + Render2D.tw(rows.get(i)[1]) + 12;
            if (!chips) {
                float W = 0, H = 0;
                if (hor) { for (float v : ws) W += v; H = 14; } else { for (float v : ws) W = Math.max(W, v); H = rows.size() * (rowH) - spacing.f(); }
                panel(c, W, H);
                for (int i = 0; i < rows.size(); i++) {
                    float px = hor ? x : 0, py = hor ? 0 : y;
                    drawRow(c, rows.get(i), cols.get(i), px + 6, py + 3);
                    x += ws[i]; y += rowH;
                }
                return;
            }
            for (int i = 0; i < rows.size(); i++) {
                float px = hor ? x : 0, py = hor ? 0 : y;
                if (bg.on()) {
                    if (shadow.on()) Render2D.glow(c, px, py, ws[i], 14, radius.f(), 0x60000000, 3);
                    Render2D.rrect(c, px, py, ws[i], 14, radius.f(), bgCol.get());
                    if (outline.on()) Render2D.outline(c, px, py, ws[i], 14, radius.f(), ThemeManager.cur().outline);
                }
                drawRow(c, rows.get(i), cols.get(i), px + 6, py + 3);
                x += ws[i] + 3; y += rowH;
                maxW = hor ? x : Math.max(maxW, ws[i]);
            }
            this.w = hor ? x : maxW; this.h = hor ? 14 : y - spacing.f();
        }

        private void drawRow(DrawContext c, String[] r, int col, float x, float y) {
            if (style.is("Two Tone") || true) {
                Render2D.text(c, r[0], x, y, dim());
                Render2D.text(c, r[1], x + Render2D.tw(r[0]) + 6, y, colorize.on() ? col : text());
            }
        }
    }

    // =====================================================================================================
    public static final class Coordinates extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "Stacked", "Stacked", "Single Line", "Compact"));
        final Setting.Bool biome = add(new Setting.Bool("Show Biome", true));
        final Setting.Bool direction = add(new Setting.Bool("Show Direction", true));
        final Setting.Bool nether = add(new Setting.Bool("Show Nether Coords", true));
        final Setting.Bool colored = add(new Setting.Bool("Colored Axes", true));
        final Setting.Num decimals = add(new Setting.Num("Decimals", 0, 0, 3, 1));

        public Coordinates() { super("Coordinates", "XYZ, biome, facing direction and Nether conversion", 0.012f, 0.93f); stdStyle(); }

        private String fmt(double v) { return String.format(Locale.ROOT, "%." + decimals.i() + "f", v); }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var p = Pulse.mc.player;
            double x = p != null ? p.getX() : 128.5, y = p != null ? p.getY() : 64, z = p != null ? p.getZ() : -42.25;
            String dirS = "", biomeS = "";
            if (p != null) {
                dirS = p.getHorizontalFacing().asString().toUpperCase().substring(0, 1) + p.getHorizontalFacing().asString().substring(1) + " (" + Math.round(((p.getYaw() % 360) + 360) % 360) + "\u00B0)";
                if (Pulse.mc.world != null) {
                    var key = Pulse.mc.world.getBiome(BlockPos.ofFloored(x, y, z)).getKey();
                    if (key.isPresent()) { String path = key.get().getValue().getPath().replace('_', ' '); biomeS = path.substring(0, 1).toUpperCase() + path.substring(1); }
                }
            } else { dirS = "South (0\u00B0)"; biomeS = "Plains"; }
            boolean inNether = Pulse.mc.world != null && Pulse.mc.world.getRegistryKey().getValue().getPath().equals("the_nether");
            List<String> lines = new ArrayList<>();
            if (style.is("Single Line")) {
                lines.add(fmt(x) + ", " + fmt(y) + ", " + fmt(z));
            } else if (style.is("Compact")) {
                lines.add("XYZ " + fmt(x) + " " + fmt(y) + " " + fmt(z));
            } else { lines.add("X " + fmt(x)); lines.add("Y " + fmt(y)); lines.add("Z " + fmt(z)); }
            if (nether.on()) lines.add((inNether ? "Overworld " : "Nether ") + fmt(inNether ? x * 8.0 : x / 8.0) + ", " + fmt(inNether ? z * 8.0 : z / 8.0));
            if (direction.on()) lines.add(dirS);
            if (biome.on() && !biomeS.isEmpty()) lines.add(biomeS);
            float W = 0;
            for (String l : lines) W = Math.max(W, Render2D.tw(l));
            W += 14;
            float H = lines.size() * 11 + 6;
            panel(c, W, H);
            int[] axis = {0xFFE5707A, 0xFF6EDC9A, 0xFF7CA8FF};
            for (int i = 0; i < lines.size(); i++) {
                String l = lines.get(i);
                int col = text();
                if (colored.on() && style.is("Stacked") && i < 3) { Render2D.text(c, l.substring(0, 1), 7, 4 + i * 11, axis[i]); Render2D.text(c, l.substring(1), 7 + Render2D.tw("X"), 4 + i * 11, col); }
                else Render2D.text(c, l, 7, 4 + i * 11, i >= (style.is("Stacked") ? 3 : 1) ? dim() : col);
            }
        }
    }

    // =====================================================================================================
    public static final class InventoryViewer extends HudModule {
        final Setting.Bool hotbar = add(new Setting.Bool("Include Hotbar", false));
        final Setting.Bool counts = add(new Setting.Bool("Item Counts", true));
        final Setting.Bool title = add(new Setting.Bool("Title", true));
        final Setting.Bool slotBg = add(new Setting.Bool("Slot Backgrounds", true));
        final Setting.Num slot = add(new Setting.Num("Slot Size", 18, 12, 26, 1));
        final Setting.Num gap = add(new Setting.Num("Slot Gap", 0, 0, 4, 1));
        final Setting.Color slotCol = add(new Setting.Color("Slot Color", 0xFFFFFF, 0x14));

        public InventoryViewer() { super("InventoryViewer", "Inventory grid on screen", 0.8f, 0.58f); stdStyle(); }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var p = Pulse.mc.player;
            int rows = hotbar.on() ? 4 : 3;
            float S = slot.f(), G = gap.f(), top = title.on() ? 14 : 4;
            float W = 9 * (S + G) - G + 8, H = rows * (S + G) - G + top + 4;
            panel(c, W, H);
            if (title.on()) Render2D.text(c, "Inventory", 6, 4, dim());
            for (int r = 0; r < rows; r++) {
                for (int col = 0; col < 9; col++) {
                    int idx = hotbar.on() ? (r == 3 ? col : 9 + r * 9 + col) : 9 + r * 9 + col;
                    float x = 4 + col * (S + G), y = top + r * (S + G);
                    if (slotBg.on()) Render2D.rrect(c, x, y, S, S, 3, slotCol.get());
                    if (p == null) continue;
                    ItemStack st = p.getInventory().getStack(idx);
                    if (!st.isEmpty()) {
                        float k = S / 18f;
                        var mx = c.getMatrices();
                        mx.pushMatrix(); mx.translate(x + (S - 16 * k) / 2f, y + (S - 16 * k) / 2f); mx.scale(k, k);
                        c.drawItem(st, 0, 0);
                        if (counts.on()) c.drawStackOverlay(Render2D.font(), st, 0, 0);
                        mx.popMatrix();
                    }
                }
            }
        }
    }

    // =====================================================================================================
    public static final class ArrayListHud extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "Side Bar", "Side Bar", "Underline", "Rounded Chips", "Plain"));
        final Setting.Mode align = add(new Setting.Mode("Align", "Right", "Left", "Right"));
        final Setting.Mode sort = add(new Setting.Mode("Sort", "Length", "Length", "Alphabetical"));
        final Setting.Bool info = add(new Setting.Bool("Show Mode Info", true));
        final Setting.Bool hideHud = add(new Setting.Bool("Hide HUD Modules", true));
        final Setting.Bool lower = add(new Setting.Bool("Lowercase", false));
        final Setting.Bool textShadow = add(new Setting.Bool("Text Shadow", true));
        final Setting.Num rowH = add(new Setting.Num("Row Height", 12, 9, 18, 1));
        final Setting.Num animSpeed = add(new Setting.Num("Animation Speed", 12, 3, 30, 1));
        final Setting.Color color = add(new Setting.Color("Text Color", 0x7C9CFF, 0xB48CFF, 255).mode("Theme"));

        public ArrayListHud() { super("ArrayList", "Animated list of active modules", 0.995f, 0.02f); stdStyle(); bg.set(true); bgCol.alpha = 0x70; }

        @Override public float anchorX() { return align.is("Right") ? -w : 0; }

        private String label(Module m) {
            String n = lower.on() ? m.name.toLowerCase() : m.name;
            return n;
        }

        private String infoOf(Module m) {
            for (Setting<?> s : m.settings) if (s instanceof Setting.Mode md && !md.name.equals("Bind Mode")) return md.get();
            return null;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            List<Module> list = new ArrayList<>();
            for (Module m : Modules.ALL) {
                boolean want = (m.enabled && m.inList.on() && !(hideHud.on() && m instanceof HudModule)) || (editing && m.enabled);
                m.listAnim = Anim.to(m.listAnim, want ? 1f : 0f, animSpeed.f());
                if (m.listAnim > 0.01f) list.add(m);
            }
            Comparator<Module> cmp = sort.is("Length") ? Comparator.comparingInt((Module m) -> -(Render2D.tw(label(m)) + (info.on() && infoOf(m) != null ? Render2D.tw(infoOf(m)) + 4 : 0))) : Comparator.comparing(m -> m.name);
            list.sort(cmp);
            float rh = rowH.f(), maxW = 40, y = 0;
            for (Module m : list) { String i = info.on() ? infoOf(m) : null; maxW = Math.max(maxW, Render2D.tw(label(m)) + (i != null ? Render2D.tw(i) + 4 : 0) + 10); }
            boolean right = align.is("Right");
            int idx = 0;
            for (Module m : list) {
                float a = Anim.easeOutCubic(m.listAnim);
                String l = label(m), i = info.on() ? infoOf(m) : null;
                float rw = Render2D.tw(l) + (i != null ? Render2D.tw(i) + 4 : 0) + 10;
                float slide = (1f - a) * (rw + 6) * (right ? 1 : -1);
                float x = (right ? maxW - rw : 0) + slide;
                float hh = rh * a;
                int col = color.get(idx * 0.08f);
                String st = style.get();
                if (!st.equals("Plain") && bg.on()) {
                    if (st.equals("Rounded Chips")) Render2D.rrect(c, x, y + 1, rw, hh - 1, 4, ColorUtil.alphaMul(bgCol.get(), a));
                    else Render2D.rect(c, x, y, rw, hh, ColorUtil.alphaMul(bgCol.get(), a));
                }
                if (st.equals("Side Bar")) Render2D.rect(c, right ? x + rw - 2 : x, y, 2, hh, ColorUtil.alphaMul(col, a));
                if (st.equals("Underline")) Render2D.rect(c, x, y + hh - 1, rw, 1, ColorUtil.alphaMul(col, a * 0.8f));
                float tx = x + (right ? 4 : 6);
                int tc = ColorUtil.alphaMul(col, a);
                if ((tc >>> 24) >= 8) {
                    float ty = y + (hh - 8) / 2f;
                    if (textShadow.on()) Render2D.textS(c, l, tx, ty, tc); else Render2D.text(c, l, tx, ty, tc);
                    if (i != null) Render2D.text(c, i, tx + Render2D.tw(l) + 4, ty, ColorUtil.alphaMul(dim(), a));
                }
                y += hh; idx++;
            }
            this.w = maxW; this.h = Math.max(10, y);
        }
    }

    // =====================================================================================================
    public static final class CustomScoreboard extends HudModule {
        final Setting.Bool hideNumbers = add(new Setting.Bool("Hide Red Numbers", true));
        final Setting.Bool centerTitle = add(new Setting.Bool("Center Title", true));
        final Setting.Bool titleBar = add(new Setting.Bool("Title Accent Bar", true));
        final Setting.Bool shadowText = add(new Setting.Bool("Text Shadow", false));
        final Setting.Bool separators = add(new Setting.Bool("Line Separators", false));
        final Setting.Num maxLines = add(new Setting.Num("Max Lines", 15, 3, 15, 1));
        final Setting.Num padding = add(new Setting.Num("Padding", 5, 2, 10, 1));
        final Setting.Num minWidth = add(new Setting.Num("Min Width", 90, 40, 220, 2));

        public CustomScoreboard() { super("CustomScoreboard", "Restyled sidebar scoreboard (hides red numbers, rounded background)", 0.995f, 0.3f); stdStyle(); radius.set(6.0); }

        @Override public float anchorX() { return -w; }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var m = Pulse.mc;
            Text title; List<Text> names = new ArrayList<>(); List<String> scores = new ArrayList<>();
            ScoreboardObjective obj = null;
            if (m.world != null) obj = m.world.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
            if (obj != null) {
                Scoreboard sb = m.world.getScoreboard();
                title = obj.getDisplayName();
                List<ScoreboardEntry> es = new ArrayList<>();
                for (ScoreboardEntry e : sb.getScoreboardEntries(obj)) if (!e.hidden()) es.add(e);
                es.sort(Comparator.comparingInt(ScoreboardEntry::value).reversed().thenComparing(ScoreboardEntry::owner, Comparator.reverseOrder()));
                for (int i = 0; i < Math.min(es.size(), maxLines.i()); i++) {
                    ScoreboardEntry e = es.get(i);
                    names.add(Team.decorateName(sb.getScoreHolderTeam(e.owner()), e.name()));
                    scores.add(String.valueOf(e.value()));
                }
            } else if (editing) {
                title = Text.literal("Scoreboard");
                for (int i = 0; i < 6; i++) { names.add(Text.literal("Line " + (i + 1))); scores.add(String.valueOf(6 - i)); }
            } else { w = 40; h = 10; return; }
            var f = Render2D.font();
            int pad = padding.i();
            float W = f.getWidth(title);
            for (int i = 0; i < names.size(); i++) W = Math.max(W, f.getWidth(names.get(i)) + (hideNumbers.on() ? 0 : 6 + f.getWidth(scores.get(i))));
            W = Math.max(minWidth.f(), W + pad * 2);
            float rowH = 10 + (separators.on() ? 1 : 0);
            float H = 14 + names.size() * rowH + pad;
            panel(c, W, H);
            if (titleBar.on()) Render2D.rrect(c, pad, 12, W - pad * 2, 1, 0, ColorUtil.alphaMul(accent.get(), 0.9f));
            float tx = centerTitle.on() ? (W - f.getWidth(title)) / 2f : pad;
            c.drawText(f, title, Math.round(tx), 3, 0xFFFFFFFF, true);
            for (int i = 0; i < names.size(); i++) {
                float y = 16 + i * rowH;
                c.drawText(f, names.get(i), pad, Math.round(y), 0xFFFFFFFF, shadowText.on());
                if (!hideNumbers.on()) Render2D.textR(c, scores.get(i), W - pad, y, 0xFFFF6B6B, false);
                if (separators.on() && i < names.size() - 1) Render2D.rect(c, pad, y + 9, W - pad * 2, 1, 0x14FFFFFF);
            }
        }
    }

    // =====================================================================================================
    public static final class CustomBossbar extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "Rounded", "Rounded", "Thin", "Segmented"));
        final Setting.Bool percent = add(new Setting.Bool("Show Percent", false));
        final Setting.Bool nameShadow = add(new Setting.Bool("Name Shadow", true));
        final Setting.Bool smooth = add(new Setting.Bool("Smooth Fill", true));
        final Setting.Bool useBossColor = add(new Setting.Bool("Use Boss Colour", true));
        final Setting.Num width = add(new Setting.Num("Width", 180, 80, 320, 2));
        final Setting.Num height = add(new Setting.Num("Bar Height", 7, 3, 14, 1));
        final Setting.Num gap = add(new Setting.Num("Gap", 8, 2, 20, 1));
        final Setting.Color color = add(new Setting.Color("Custom Colour", 0xB48CFF, 0x7C9CFF, 255).mode("Theme"));
        private final Map<UUID, Float> shown = new HashMap<>();

        public CustomBossbar() { super("CustomBossbar", "Restyled boss bars", 0.5f, 0.02f); stdStyle(); bg.set(false); }

        @Override public float anchorX() { return -width.f() / 2f; }

        static int colorOf(BossBar.Color c) {
            return switch (c) {
                case PINK -> 0xFFE88AB4; case BLUE -> 0xFF6C9CFF; case RED -> 0xFFE5707A; case GREEN -> 0xFF6EDC9A;
                case YELLOW -> 0xFFF0D070; case PURPLE -> 0xFFB48CFF; default -> 0xFFE8EAF2;
            };
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            Map<UUID, ClientBossBar> bars = ((BossBarHudAccessor) Pulse.mc.inGameHud.getBossBarHud()).pulse$getBars();
            float W = width.f(), bh = height.f(), y = 0;
            List<Object[]> rows = new ArrayList<>();
            for (var en : bars.entrySet()) rows.add(new Object[]{en.getKey(), en.getValue().getName(), en.getValue().getPercent(), colorOf(en.getValue().getColor())});
            if (rows.isEmpty() && editing) rows.add(new Object[]{UUID.nameUUIDFromBytes(new byte[]{1}), Text.literal("Boss Bar"), 0.65f, 0xFFB48CFF});
            if (rows.isEmpty()) { this.w = W; this.h = 10; return; }
            for (Object[] r : rows) {
                UUID id = (UUID) r[0]; Text name = (Text) r[1]; float pct = (Float) r[2]; int bc = (Integer) r[3];
                float cur = smooth.on() ? Anim.to(shown.getOrDefault(id, pct), pct, 10f) : pct;
                shown.put(id, cur);
                c.drawText(Render2D.font(), name, Math.round((W - Render2D.font().getWidth(name)) / 2f), Math.round(y), 0xFFFFFFFF, nameShadow.on());
                float by = y + 11;
                int col = useBossColor.on() ? bc : color.get(0f);
                if (style.is("Thin")) { Render2D.rect(c, 0, by + bh / 2f - 1, W, 2, 0x66000000); Render2D.rect(c, 0, by + bh / 2f - 1, W * cur, 2, col); }
                else {
                    Render2D.rrect(c, 0, by, W, bh, style.is("Rounded") ? bh / 2f : 1, 0x88000000);
                    Render2D.rrect(c, 0, by, Math.max(bh, W * cur), bh, style.is("Rounded") ? bh / 2f : 1, col);
                    if (style.is("Segmented")) for (int i = 1; i < 10; i++) Render2D.rect(c, W * i / 10f, by, 1, bh, 0x99000000);
                }
                if (percent.on()) Render2D.textScaled(c, Math.round(cur * 100) + "%", W - 22, by - 0.5f, 0.75f, 0xFFFFFFFF, true);
                y += 11 + bh + gap.f();
            }
            shown.keySet().retainAll(bars.keySet().isEmpty() ? shown.keySet() : bars.keySet());
            this.w = W; this.h = y - gap.f();
        }
    }

    // =====================================================================================================
    public static final class SaturationHUD extends HudModule {
        final Setting.Mode style = add(new Setting.Mode("Style", "Bar", "Bar", "Number", "Icons"));
        final Setting.Bool exhaustion = add(new Setting.Bool("Show Exhaustion", false));
        final Setting.Bool label = add(new Setting.Bool("Labels", true));
        final Setting.Num width = add(new Setting.Num("Width", 80, 40, 160, 2));
        final Setting.Color foodCol = add(new Setting.Color("Food Color", 0xE0A060, 255));
        final Setting.Color satCol = add(new Setting.Color("Saturation Color", 0xF0D070, 255));

        public SaturationHUD() { super("SaturationHUD", "Hunger and saturation readout", 0.56f, 0.8f); stdStyle(); }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            var p = Pulse.mc.player;
            float food = p != null ? p.getHungerManager().getFoodLevel() : 18, sat = p != null ? p.getHungerManager().getSaturationLevel() : 6.5f;
            float W = width.f();
            if (style.is("Number")) {
                String s = (label.on() ? "Food " : "") + (int) food + (label.on() ? "  Sat " : " / ") + String.format(Locale.ROOT, "%.1f", sat);
                panel(c, Render2D.tw(s) + 12, 15); Render2D.text(c, s, 6, 4, text()); return;
            }
            if (style.is("Icons")) {
                panel(c, 10 * 9 + 8, 20 + (exhaustion.on() ? 0 : 0));
                for (int i = 0; i < 10; i++) {
                    float v = Anim.clamp01((food - i * 2) / 2f);
                    Render2D.rrect(c, 4 + i * 9, 4, 7, 7, 3, ColorUtil.lerp(0x44000000, foodCol.get(), v));
                    float sv = Anim.clamp01((sat - i * 2) / 2f);
                    if (sv > 0) Render2D.rrect(c, 5.5f + i * 9, 5.5f, 4, 4, 2, ColorUtil.alphaMul(satCol.get(), sv));
                }
                Render2D.rect(c, 4, 14, 82 * Anim.clamp01(sat / 20f), 1, satCol.get());
                return;
            }
            float H = label.on() ? 26 : 18;
            panel(c, W, H);
            float by = label.on() ? 14 : 6;
            if (label.on()) { Render2D.text(c, "Food", 5, 3, dim()); Render2D.textR(c, (int) food + " / " + String.format(Locale.ROOT, "%.1f", sat), W - 5, 3, text(), false); }
            Render2D.rrect(c, 5, by, W - 10, 6, 3, 0x55000000);
            Render2D.rrect(c, 5, by, Math.max(6, (W - 10) * food / 20f), 6, 3, foodCol.get());
            Render2D.rrect(c, 5, by + 2, Math.max(0, (W - 10) * Math.min(sat, food) / 20f), 2, 1, ColorUtil.alphaMul(satCol.get(), 0.95f));
        }
    }

    // =====================================================================================================
    public static final class HotkeysHUD extends HudModule {
        final Setting.Bool onlyActive = add(new Setting.Bool("Only Active", false));
        final Setting.Bool dot = add(new Setting.Bool("State Dot", true));
        final Setting.Bool brackets = add(new Setting.Bool("Key In Brackets", true));
        final Setting.Mode align = add(new Setting.Mode("Key Align", "Right", "Right", "Inline"));
        final Setting.Num maxRows = add(new Setting.Num("Max Rows", 12, 3, 30, 1));

        public HotkeysHUD() { super("Hotkeys", "List of bound modules and their keys", 0.995f, 0.6f); stdStyle(); }

        @Override public float anchorX() { return -w; }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            List<Module> l = new ArrayList<>();
            for (Module m : Modules.ALL) if (m.bind.isSet() && (!onlyActive.on() || m.enabled)) l.add(m);
            if (l.size() > maxRows.i()) l = l.subList(0, maxRows.i());
            if (l.isEmpty()) { if (editing) { w = 90; h = 14; panel(c, 90, 14); Render2D.text(c, "No binds set", 6, 3, dim()); } else { w = 40; h = 10; } return; }
            float W = 60;
            for (Module m : l) W = Math.max(W, Render2D.tw(m.name) + Render2D.tw(keyText(m)) + 30);
            panel(c, W, l.size() * 11 + 6);
            for (int i = 0; i < l.size(); i++) {
                Module m = l.get(i);
                float y = 3 + i * 11;
                if (dot.on()) Render2D.circle(c, 8, y + 4, 2, m.enabled ? 0xFF6EDC9A : 0xFF6B7184);
                Render2D.text(c, m.name, 15, y, m.enabled ? text() : dim());
                Render2D.textR(c, keyText(m), W - 6, y, ThemeManager.cur().accent, false);
            }
        }

        private String keyText(Module m) { return brackets.on() ? "[" + m.bind.display() + "]" : m.bind.display(); }
    }

    // =====================================================================================================
    public static final class CustomCrosshair extends Module {
        public final Setting.Mode style = add(new Setting.Mode("Style", "Cross", "Cross", "Plus Dot", "Dot", "Circle", "Square", "T-Shape", "Chevron"));
        final Setting.Num size = add(new Setting.Num("Size", 5, 1, 20, 0.5));
        final Setting.Num thick = add(new Setting.Num("Thickness", 1, 0.5, 4, 0.5));
        final Setting.Num gap = add(new Setting.Num("Gap", 2, 0, 12, 0.5));
        final Setting.Num offX = add(new Setting.Num("Offset X", 0, -30, 30, 1));
        final Setting.Num offY = add(new Setting.Num("Offset Y", 0, -30, 30, 1));
        final Setting.Bool outline = add(new Setting.Bool("Outline", true));
        final Setting.Num outlineW = add(new Setting.Num("Outline Width", 1, 0.5, 2, 0.5));
        final Setting.Color color = add(new Setting.Color("Color", 0xFFFFFF, 0x7C9CFF, 0xEE));
        final Setting.Color outCol = add(new Setting.Color("Outline Color", 0x000000, 0xB0));
        final Setting.Bool dynamic = add(new Setting.Bool("Dynamic Gap", true));
        final Setting.Num dynAmount = add(new Setting.Num("Dynamic Amount", 4, 1, 12, 0.5));
        final Setting.Bool attackRing = add(new Setting.Bool("Attack Cooldown Ring", false));
        final Setting.Bool hitMarker = add(new Setting.Bool("Hit Marker", true));
        final Setting.Bool targetColor = add(new Setting.Bool("Red On Entity", true));
        final Setting.Bool firstPersonOnly = add(new Setting.Bool("First Person Only", true));
        private float dyn, hitFade;
        private final Consumer<Entity> hitL = e -> hitFade = 1f;

        public CustomCrosshair() { super("CustomCrosshair", "Fully custom crosshair (replaces the vanilla one)", Category.HUD); }

        @Override public void onEnable() { Pulse.hitListeners.add(hitL); }
        @Override public void onDisable() { Pulse.hitListeners.remove(hitL); }

        private void r(DrawContext c, float x, float y, float w, float h, int col) {
            if (outline.on()) { float o = outlineW.f(); Render2D.rect(c, x - o, y - o, w + o * 2, h + o * 2, outCol.get()); }
            Render2D.rect(c, x, y, w, h, col);
        }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            if (m.player == null || m.currentScreen != null) return;
            if (firstPersonOnly.on() && !m.options.getPerspective().isFirstPerson()) return;
            float cx = m.getWindow().getScaledWidth() / 2f + offX.f(), cy = m.getWindow().getScaledHeight() / 2f + offY.f();
            boolean moving = Stats.speed > 0.5 || m.options.attackKey.isPressed();
            dyn = Anim.to(dyn, dynamic.on() && moving ? dynAmount.f() * (m.player.isSprinting() ? 1.4f : 1f) : 0f, 14f);
            hitFade = Anim.to(hitFade, 0f, 6f);
            int col = color.get();
            if (targetColor.on() && m.targetedEntity != null) col = ColorUtil.lerp(col, 0xFFFF5A5A, 0.8f);
            float S = size.f(), T = thick.f(), G = gap.f() + dyn;
            String st = style.get();
            float ax = Math.round(cx), ay = Math.round(cy);
            switch (st) {
                case "Dot" -> { r(c, ax - T, ay - T, T * 2, T * 2, col); }
                case "Circle" -> { if (outline.on()) Render2D.ring(c, ax, ay, S + G + outlineW.f(), T + outlineW.f() * 2, outCol.get()); Render2D.ring(c, ax, ay, S + G, T, col); }
                case "Square" -> { float s = S + G; Render2D.outline(c, ax - s, ay - s, s * 2, s * 2, 0, col); }
                case "Chevron" -> {
                    for (int i = 0; i < (int) S; i++) { r(c, ax - i - 1, ay + G + i, T, T, col); r(c, ax + i, ay + G + i, T, T, col); }
                }
                default -> {
                    if (!st.equals("T-Shape")) r(c, ax - T / 2f, ay - G - S, T, S, col);
                    r(c, ax - T / 2f, ay + G, T, S, col);
                    r(c, ax - G - S, ay - T / 2f, S, T, col);
                    r(c, ax + G, ay - T / 2f, S, T, col);
                    if (st.equals("Plus Dot")) r(c, ax - T / 2f, ay - T / 2f, T, T, col);
                }
            }
            if (attackRing.on()) {
                float pr = m.player.getAttackCooldownProgress(0f);
                if (pr < 1f) {
                    float bw = 14;
                    Render2D.rect(c, ax - bw / 2, ay + S + G + 6, bw, 2, 0x66000000);
                    Render2D.rect(c, ax - bw / 2, ay + S + G + 6, bw * pr, 2, col);
                }
            }
            if (hitMarker.on() && hitFade > 0.03f) {
                int hc = ColorUtil.alphaMul(0xFFFFFFFF, hitFade);
                float o = 5 + (1f - hitFade) * 3;
                for (int s = -1; s <= 1; s += 2) {
                    Render2D.line(c, ax + s * o, ay + o, ax + s * (o + 4), ay + o + 4, 1.2f, hc);
                    Render2D.line(c, ax + s * o, ay - o, ax + s * (o + 4), ay - o - 4, 1.2f, hc);
                }
            }
        }
    }

    // =====================================================================================================
    public static final class Notifications extends HudModule {
        public final Setting.Bool toggles = add(new Setting.Bool("Module Toggle Toasts", true));
        final Setting.Bool armorWarn = add(new Setting.Bool("Armor Durability Warning", true));
        final Setting.Num armorPct = add(new Setting.Num("Armor Warn Below %", 15, 5, 50, 1));
        final Setting.Bool pops = add(new Setting.Bool("Totem Pop Alerts", true));
        final Setting.Num duration = add(new Setting.Num("Duration (s)", 3.0, 1, 10, 0.5));
        final Setting.Mode dir = add(new Setting.Mode("Stack Direction", "Down", "Down", "Up"));
        final Setting.Num width = add(new Setting.Num("Width", 150, 100, 260, 2));
        private final long[] lastWarn = new long[4];
        private final Consumer<Entity> popL = e -> { if (pops.on() && Pulse.mc.player != null) Notifs.push("Totem popped", e.getName().getString(), 0xFFF0D070); };

        public Notifications() { super("Notifications", "Toast popups: module toggles, armor warnings, totem pops", 0.995f, 0.05f); stdStyle(); }

        @Override public float anchorX() { return -width.f(); }
        @Override public void onEnable() { Pulse.popListeners.add(popL); }
        @Override public void onDisable() { Pulse.popListeners.remove(popL); }

        @Override public void onTick() {
            var p = Pulse.mc.player;
            if (p == null || !armorWarn.on()) return;
            long now = System.currentTimeMillis();
            String[] n = {"Helmet", "Chestplate", "Leggings", "Boots"};
            for (int i = 0; i < 4; i++) {
                ItemStack st = p.getEquippedStack(HudModules.ARMOR[i]);
                if (!st.isEmpty() && st.isDamageable() && HudModules.durPercent(st) < armorPct.i() && now - lastWarn[i] > 30000) {
                    lastWarn[i] = now;
                    Notifs.push("Armor low", n[i] + " at " + HudModules.durPercent(st) + "%", 0xFFE5707A);
                }
            }
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            long now = System.currentTimeMillis();
            float W = width.f(), rh = 28, y = 0;
            List<Notifs.Toast> l = Notifs.LIST;
            if (editing && l.isEmpty()) Notifs.push("Notifications", "Example toast", 0xFF7C9CFF);
            for (Iterator<Notifs.Toast> it = l.iterator(); it.hasNext(); ) {
                Notifs.Toast t = it.next();
                boolean alive = now - t.born < duration.d() * 1000 || editing;
                t.anim = Anim.to(t.anim, alive ? 1f : 0f, 10f);
                if (!alive && t.anim < 0.03f) { it.remove(); continue; }
                float a = Anim.easeOutCubic(t.anim);
                float x = (1f - a) * 40f;
                if (shadow.on()) Render2D.glow(c, x, y, W, rh - 4, radius.f(), ColorUtil.alphaMul(0x70000000, a), 3);
                Render2D.rrect(c, x, y, W, rh - 4, radius.f(), ColorUtil.alphaMul(bgCol.get(), a));
                Render2D.rrect(c, x + 3, y + 4, 2, rh - 12, 1, ColorUtil.alphaMul(t.color, a));
                Render2D.text(c, t.title, x + 10, y + 3, ColorUtil.alphaMul(text(), a));
                Render2D.text(c, t.body, x + 10, y + 13, ColorUtil.alphaMul(dim(), a));
                Render2D.rect(c, x + 10, y + rh - 6, (W - 20) * (1f - Anim.clamp01((now - t.born) / (float) (duration.d() * 1000))), 1, ColorUtil.alphaMul(t.color, a * 0.7f));
                y += rh * a;
            }
            this.w = W; this.h = Math.max(10, y);
        }
    }

    // =====================================================================================================
    public static final class EventTimers extends HudModule {
        static final int N = 4;
        final Setting.Mode style = add(new Setting.Mode("Style", "Bars", "Bars", "Compact"));
        final Setting.Bool flashEnd = add(new Setting.Bool("Flash On Finish", true));
        final Setting.Bool notify = add(new Setting.Bool("Toast On Finish", true));
        final Setting.Num width = add(new Setting.Num("Width", 120, 80, 220, 2));
        final Setting.Text[] label = new Setting.Text[N], trigger = new Setting.Text[N];
        final Setting.Num[] secs = new Setting.Num[N];
        final Setting.Bind[] start = new Setting.Bind[N];
        private final boolean[] down = new boolean[N];

        private static final class Active { String name; long end, total; long doneAt; }
        private final List<Active> active = new ArrayList<>();

        public EventTimers() {
            super("EventTimers", "Custom on-screen timers (key, chat trigger or /pulse timer)", 0.012f, 0.2f);
            for (int i = 0; i < N; i++) {
                label[i] = add(new Setting.Text("Timer " + (i + 1) + " Label", i == 0 ? "Event" : "Timer " + (i + 1), 20));
                secs[i] = add(new Setting.Num("Timer " + (i + 1) + " Seconds", i == 0 ? 60 : 30, 1, 3600, 1));
                start[i] = add(new Setting.Bind("Timer " + (i + 1) + " Start Key", -1));
                trigger[i] = add(new Setting.Text("Timer " + (i + 1) + " Chat Trigger", "", 40));
            }
            stdStyle();
        }

        public void start(String name, double seconds) {
            active.removeIf(a -> a.name.equals(name) && a.doneAt == 0);
            Active a = new Active(); a.name = name; a.total = (long) (seconds * 1000); a.end = System.currentTimeMillis() + a.total;
            active.add(a);
        }

        public void onChat(String msg) {
            if (!enabled) return;
            String low = msg.toLowerCase(Locale.ROOT);
            for (int i = 0; i < N; i++) {
                String t = trigger[i].get().trim().toLowerCase(Locale.ROOT);
                if (!t.isEmpty() && low.contains(t)) start(label[i].get(), secs[i].d());
            }
        }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.currentScreen == null) {
                for (int i = 0; i < N; i++) {
                    if (!start[i].isSet()) { down[i] = false; continue; }
                    boolean d = GLFW.glfwGetKey(m.getWindow().getHandle(), start[i].get()) == GLFW.GLFW_PRESS;
                    if (d && !down[i]) start(label[i].get(), secs[i].d());
                    down[i] = d;
                }
            }
            long now = System.currentTimeMillis();
            for (Iterator<Active> it = active.iterator(); it.hasNext(); ) {
                Active a = it.next();
                if (a.doneAt == 0 && now >= a.end) { a.doneAt = now; if (notify.on()) Notifs.push(a.name, "Timer finished", 0xFF6EDC9A); }
                if (a.doneAt != 0 && now - a.doneAt > 2500) it.remove();
            }
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            long now = System.currentTimeMillis();
            List<Active> l = new ArrayList<>(active);
            if (l.isEmpty() && editing) { Active a = new Active(); a.name = "Example"; a.total = 60000; a.end = now + 38000; l.add(a); }
            if (l.isEmpty()) { w = 40; h = 10; return; }
            boolean comp = style.is("Compact");
            float W = width.f(), rh = comp ? 13 : 20;
            panel(c, W, l.size() * rh + 6);
            for (int i = 0; i < l.size(); i++) {
                Active a = l.get(i);
                float y = 3 + i * rh;
                boolean done = a.doneAt != 0;
                float frac = done ? 0 : Anim.clamp01((a.end - now) / (float) a.total);
                int col = done ? (flashEnd.on() && (now / 250) % 2 == 0 ? 0xFF6EDC9A : 0xFF3F9E6A) : ColorUtil.lerp(0xFFE5707A, accent.get(0f) | 0xFF000000, frac);
                Render2D.text(c, Render2D.trim(a.name, (int) W - 44), 6, y + 1, text());
                Render2D.textR(c, done ? "DONE" : HudModules.mmss((int) ((a.end - now) / 50)), W - 6, y + 1, col, false);
                if (!comp) { Render2D.rrect(c, 6, y + 12, W - 12, 3, 1, 0x55000000); Render2D.rrect(c, 6, y + 12, Math.max(1, (W - 12) * frac), 3, 1, col); }
            }
        }
    }
}
