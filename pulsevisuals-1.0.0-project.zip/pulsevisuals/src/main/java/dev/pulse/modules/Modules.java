package dev.pulse.modules;

import dev.pulse.module.HudModule;
import dev.pulse.module.Module;

import java.util.ArrayList;
import java.util.List;

/** Central module registry (also holds typed handles used by mixins). */
public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();

    // HUD
    public static HudModules.Watermark WATERMARK;
    public static HudModules.TargetHUD TARGET_HUD;
    public static HudModules2.Notifications NOTIFICATIONS;
    public static HudModules2.EventTimers EVENT_TIMERS;
    public static HudModules2.CustomScoreboard SCOREBOARD;
    public static HudModules2.CustomBossbar BOSSBAR;
    public static HudModules2.CustomCrosshair CROSSHAIR;
    // Visuals
    public static VisualModules.NameTags NAME_TAGS;
    public static VisualModules.ShulkerPreview SHULKER;
    // World
    public static WorldModules.CustomSky SKY;
    public static WorldModules.ClientTime TIME;
    public static WorldModules.ClientWeather WEATHER;
    public static WorldModules.Fullbright FULLBRIGHT;
    // View
    public static ViewModules.ViewModel VIEW_MODEL;
    public static ViewModules.SwingAnimations SWING;
    public static ViewModules.AspectRatio ASPECT;
    public static ViewModules.SmoothZoom ZOOM;
    public static ViewModules.FreeLook FREELOOK;
    public static ViewModules.NoRender NO_RENDER;
    public static ViewModules.SmoothHotbar HOTBAR;
    public static ViewModules.SmoothChat CHAT;
    public static ViewModules.TotemPop TOTEM;
    // Utilities
    public static UtilModules.FriendSystem FRIENDS;
    public static UtilModules.AutoReconnect RECONNECT;

    private static <T extends Module> T reg(T m) { ALL.add(m); return m; }

    public static void init() {
        if (!ALL.isEmpty()) return;
        // ---- Visuals
        reg(new VisualModules.TargetESP());
        reg(new VisualModules.HitColor());
        reg(new VisualModules.DamageParticles());
        reg(new VisualModules.HitParticles());
        reg(new VisualModules.ChinaHat());
        reg(new VisualModules.Halo());
        NAME_TAGS = reg(new VisualModules.NameTags());
        reg(new VisualModules.Tracers());
        reg(new VisualModules.Arrows());
        reg(new VisualModules.ItemESP());
        reg(new VisualModules.Hitboxes());
        SHULKER = reg(new VisualModules.ShulkerPreview());
        // ---- HUD
        WATERMARK = reg(new HudModules.Watermark());
        TARGET_HUD = reg(new HudModules.TargetHUD());
        reg(new HudModules.Keystrokes());
        reg(new HudModules.ArmorHUD());
        reg(new HudModules.PotionHUD());
        reg(new HudModules.CooldownsHUD());
        reg(new HudModules2.InfoHUD());
        reg(new HudModules2.Coordinates());
        reg(new HudModules2.InventoryViewer());
        reg(new HudModules2.ArrayListHud());
        SCOREBOARD = reg(new HudModules2.CustomScoreboard());
        BOSSBAR = reg(new HudModules2.CustomBossbar());
        reg(new HudModules2.SaturationHUD());
        reg(new HudModules2.HotkeysHUD());
        CROSSHAIR = reg(new HudModules2.CustomCrosshair());
        NOTIFICATIONS = reg(new HudModules2.Notifications());
        EVENT_TIMERS = reg(new HudModules2.EventTimers());
        // ---- View & animations
        VIEW_MODEL = reg(new ViewModules.ViewModel());
        SWING = reg(new ViewModules.SwingAnimations());
        ASPECT = reg(new ViewModules.AspectRatio());
        ZOOM = reg(new ViewModules.SmoothZoom());
        FREELOOK = reg(new ViewModules.FreeLook());
        NO_RENDER = reg(new ViewModules.NoRender());
        HOTBAR = reg(new ViewModules.SmoothHotbar());
        CHAT = reg(new ViewModules.SmoothChat());
        TOTEM = reg(new ViewModules.TotemPop());
        // ---- World
        reg(new WorldModules.BlockOverlay());
        reg(new WorldModules.JumpCircles());
        reg(new WorldModules.Trails());
        reg(new WorldModules.Trajectories());
        SKY = reg(new WorldModules.CustomSky());
        reg(new WorldModules.CustomFog());
        TIME = reg(new WorldModules.ClientTime());
        WEATHER = reg(new WorldModules.ClientWeather());
        FULLBRIGHT = reg(new WorldModules.Fullbright());
        reg(new WorldModules.ScreenFX());
        // ---- Utilities
        reg(new UtilModules.AutoSprint());
        reg(new UtilModules.ToggleSneak());
        RECONNECT = reg(new UtilModules.AutoReconnect());
        reg(new UtilModules.CommandBinds());
        FRIENDS = reg(new UtilModules.FriendSystem());

        // clean out-of-the-box setup
        for (Module m : ALL) if (isDefault(m)) m.setEnabled(true, true);
    }

    private static boolean isDefault(Module m) {
        return m == WATERMARK || m == TARGET_HUD || m == NOTIFICATIONS || m == NAME_TAGS || m == FRIENDS
                || m.name.equals("Info (FPS/Ping/TPS)") || m.name.equals("ArrayList") || m.name.equals("Keystrokes") || m.name.equals("ArmorHUD")
                || m.name.equals("PotionHUD") || m.name.equals("TargetESP") || m.name.equals("BlockOverlay") || m.name.equals("JumpCircles")
                || m.name.equals("HitColor") || m.name.equals("Coordinates") || m.name.equals("CooldownsHUD") || m.name.equals("DamageParticles");
    }

    public static Module byName(String n) {
        for (Module m : ALL) if (m.name.equalsIgnoreCase(n) || m.name.replace(" ", "").equalsIgnoreCase(n)) return m;
        return null;
    }

    public static List<HudModule> hud() {
        List<HudModule> l = new ArrayList<>();
        for (Module m : ALL) if (m instanceof HudModule h) l.add(h);
        return l;
    }

    private Modules() {}
}
