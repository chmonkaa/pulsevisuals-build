package dev.pulse.modules;

import dev.pulse.Pulse;
import dev.pulse.module.Category;
import dev.pulse.module.Module;
import dev.pulse.setting.Setting;
import dev.pulse.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;

/** Utilities & quality-of-life modules (all strictly client-side input helpers). */
public final class UtilModules {
    private UtilModules() {}

    static boolean keyDown(int key) {
        return key > 0 && GLFW.glfwGetKey(Pulse.mc.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
    }

    // =====================================================================================================
    public static final class AutoSprint extends Module {
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Legit (Key Press)", "Legit (Key Press)", "Only While Forward"));
        final Setting.Bool notUsing = add(new Setting.Bool("Pause While Using Item", true));
        final Setting.Bool notSneak = add(new Setting.Bool("Pause While Sneaking", true));
        final Setting.Bool inWater = add(new Setting.Bool("Allow In Water", true));

        public AutoSprint() { super("AutoSprint", "Holds the sprint key for you while moving forward (vanilla sprint rules still apply)", Category.UTILITIES); }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.player == null || m.currentScreen != null) return;
            var o = m.options;
            boolean ok = o.forwardKey.isPressed();
            if (notUsing.on() && m.player.isUsingItem()) ok = false;
            if (notSneak.on() && (o.sneakKey.isPressed() || m.player.isSneaking())) ok = false;
            if (!inWater.on() && m.player.isTouchingWater()) ok = false;
            if (ok) o.sprintKey.setPressed(true);
        }
    }

    // =====================================================================================================
    public static final class ToggleSneak extends Module {
        final Setting.Bind key = add(new Setting.Bind("Sneak Key (match your controls)", GLFW.GLFW_KEY_LEFT_SHIFT));
        final Setting.Bool releaseOnJump = add(new Setting.Bool("Release On Jump", false));
        final Setting.Bool notify = add(new Setting.Bool("Toast On Toggle", false));
        private boolean latched, wasDown;

        public ToggleSneak() { super("ToggleSneak", "Press the sneak key once to stay sneaking", Category.UTILITIES); }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.player == null) return;
            boolean down = m.currentScreen == null && keyDown(key.get());
            if (down && !wasDown) { latched = !latched; if (notify.on()) Notifs.push("ToggleSneak", latched ? "Sneak latched" : "Sneak released", 0xFF7C9CFF); }
            wasDown = down;
            if (releaseOnJump.on() && m.options.jumpKey.isPressed()) latched = false;
            if (m.currentScreen == null) m.options.sneakKey.setPressed(latched || down);
        }

        @Override public void onDisable() { latched = false; }
    }

    // =====================================================================================================
    public static final class AutoReconnect extends Module {
        final Setting.Num delay = add(new Setting.Num("Delay (s)", 5.0, 1, 60, 1));
        final Setting.Num attempts = add(new Setting.Num("Max Attempts", 5, 1, 30, 1));
        final Setting.Bool backoff = add(new Setting.Bool("Increase Delay Each Try", true));
        final Setting.Bool showCountdown = add(new Setting.Bool("Show Countdown", true));
        final Setting.Bind cancelKey = add(new Setting.Bind("Cancel Key", GLFW.GLFW_KEY_C));
        private ServerInfo last;
        private long fireAt = -1;
        private int tries;
        private boolean cancelled;

        public AutoReconnect() { super("AutoReconnect", "Reconnects to the last server after a disconnect", Category.UTILITIES); }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.world != null && m.getCurrentServerEntry() != null) { last = m.getCurrentServerEntry(); tries = 0; cancelled = false; fireAt = -1; }
            if (!(m.currentScreen instanceof DisconnectedScreen)) { fireAt = -1; return; }
            if (last == null || cancelled || tries >= attempts.i()) return;
            if (keyDown(cancelKey.get())) { cancelled = true; fireAt = -1; return; }
            long now = System.currentTimeMillis();
            if (fireAt < 0) fireAt = now + (long) ((delay.d() + (backoff.on() ? tries * 2.0 : 0)) * 1000);
            if (now >= fireAt) {
                fireAt = -1; tries++;
                ConnectScreen.connect(new TitleScreen(), m, ServerAddress.parse(last.address), last, false, null);
            }
        }

        public void render(DrawContext c, Screen scr) {
            if (!enabled || !showCountdown.on() || !(scr instanceof DisconnectedScreen) || last == null) return;
            int sw = scr.width, sh = scr.height;
            String s;
            if (cancelled) s = "Auto reconnect cancelled";
            else if (tries >= attempts.i()) s = "Auto reconnect: max attempts reached";
            else s = fireAt < 0 ? "Auto reconnect..." : String.format("Reconnecting in %.1fs  (%d/%d)  [%s to cancel]", Math.max(0, (fireAt - System.currentTimeMillis()) / 1000.0), tries + 1, attempts.i(), cancelKey.display());
            Render2D.rrect(c, sw / 2f - Render2D.tw(s) / 2f - 8, sh - 34, Render2D.tw(s) + 16, 18, 6, 0xB00E1118);
            Render2D.textC(c, s, sw / 2f, sh - 29, 0xFFE8EAF2, false);
        }
    }

    // =====================================================================================================
    public static final class CommandBinds extends Module {
        static final int N = 8;
        final Setting.Num cooldown = add(new Setting.Num("Cooldown (ms)", 800, 100, 5000, 50));
        final Setting.Bool toast = add(new Setting.Bool("Toast On Send", true));
        final Setting.Text[] cmd = new Setting.Text[N];
        final Setting.Bind[] key = new Setting.Bind[N];
        private final boolean[] down = new boolean[N];
        private long lastSend;

        public CommandBinds() {
            super("CommandBinds", "Bind chat commands / macros (e.g. /home, /spawn) to keys", Category.UTILITIES);
            String[] def = {"/home", "/spawn", "", "", "", "", "", ""};
            for (int i = 0; i < N; i++) {
                cmd[i] = add(new Setting.Text("Macro " + (i + 1) + " Command", def[i], 100));
                key[i] = add(new Setting.Bind("Macro " + (i + 1) + " Key", -1));
            }
        }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.player == null || m.currentScreen != null || m.getNetworkHandler() == null) { java.util.Arrays.fill(down, false); return; }
            long now = System.currentTimeMillis();
            for (int i = 0; i < N; i++) {
                if (!key[i].isSet()) { down[i] = false; continue; }
                boolean d = keyDown(key[i].get());
                if (d && !down[i] && now - lastSend >= cooldown.d() && !cmd[i].get().isBlank()) {
                    String s = cmd[i].get().trim();
                    if (s.startsWith("/")) m.getNetworkHandler().sendChatCommand(s.substring(1));
                    else m.getNetworkHandler().sendChatMessage(s);
                    lastSend = now;
                    if (toast.on()) Notifs.push("Macro " + (i + 1), s, 0xFF7C9CFF);
                }
                down[i] = d;
            }
        }
    }

    // =====================================================================================================
    public static final class FriendSystem extends Module {
        public final Setting.Bool highlight = add(new Setting.Bool("Highlight Friends In Visuals", true));
        public final Setting.Color color = add(new Setting.Color("Friend Colour", 0x6EDC9A, 0x7CE8E0, 0xFF).mode("Static"));
        final Setting.Bind toggleKey = add(new Setting.Bind("Add / Remove Key (aim at player)", -1));
        final Setting.Bool notify = add(new Setting.Bool("Toast On Change", true));
        final Setting.Bool nameColor = add(new Setting.Bool("Tint Friend Names In Tags", true));
        private boolean was;

        public FriendSystem() { super("FriendSystem", "Friend list with its own highlight colour in every visual", Category.UTILITIES); }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.player == null || m.currentScreen != null) { was = false; return; }
            boolean d = keyDown(toggleKey.get());
            if (d && !was && m.targetedEntity instanceof PlayerEntity p) toggle(p.getName().getString());
            was = d;
        }

        public void toggle(String name) {
            boolean added = !Friends.is(name) ? Friends.add(name) : !Friends.remove(name);
            if (notify.on()) Notifs.push("Friends", (added ? "Added " : "Removed ") + name, added ? 0xFF6EDC9A : 0xFFE5707A);
        }
    }
}
