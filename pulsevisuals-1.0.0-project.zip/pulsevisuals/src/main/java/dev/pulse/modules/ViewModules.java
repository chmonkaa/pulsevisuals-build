package dev.pulse.modules;

import dev.pulse.Pulse;
import dev.pulse.module.Category;
import dev.pulse.module.Module;
import dev.pulse.setting.Setting;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** Camera, hand and animation modules. */
public final class ViewModules {
    private ViewModules() {}

    static boolean keyDown(int key) {
        return key > 0 && GLFW.glfwGetKey(Pulse.mc.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
    }

    // =====================================================================================================
    public static final class ViewModel extends Module {
        final Setting.Mode preset = add(new Setting.Mode("Preset", "Custom", "Custom", "Low & Wide", "Centered", "Tucked In", "Classic 1.8"));
        final Setting.Bool separate = add(new Setting.Bool("Separate Hands", true));
        final Setting.Num mx = add(new Setting.Num("Main X", 0.0, -1.5, 1.5, 0.01));
        final Setting.Num my = add(new Setting.Num("Main Y", 0.0, -1.5, 1.5, 0.01));
        final Setting.Num mz = add(new Setting.Num("Main Z", 0.0, -1.5, 1.5, 0.01));
        final Setting.Num ms = add(new Setting.Num("Main Scale", 1.0, 0.2, 2.0, 0.01));
        final Setting.Num mrx = add(new Setting.Num("Main Rotate X", 0.0, -180, 180, 1));
        final Setting.Num mry = add(new Setting.Num("Main Rotate Y", 0.0, -180, 180, 1));
        final Setting.Num mrz = add(new Setting.Num("Main Rotate Z", 0.0, -180, 180, 1));
        final Setting.Num ox = add(new Setting.Num("Off X", 0.0, -1.5, 1.5, 0.01)).showIf(() -> separate.on());
        final Setting.Num oy = add(new Setting.Num("Off Y", 0.0, -1.5, 1.5, 0.01)).showIf(() -> separate.on());
        final Setting.Num oz = add(new Setting.Num("Off Z", 0.0, -1.5, 1.5, 0.01)).showIf(() -> separate.on());
        final Setting.Num os = add(new Setting.Num("Off Scale", 1.0, 0.2, 2.0, 0.01)).showIf(() -> separate.on());
        final Setting.Num orx = add(new Setting.Num("Off Rotate X", 0.0, -180, 180, 1)).showIf(() -> separate.on());
        final Setting.Num ory = add(new Setting.Num("Off Rotate Y", 0.0, -180, 180, 1)).showIf(() -> separate.on());
        final Setting.Num orz = add(new Setting.Num("Off Rotate Z", 0.0, -180, 180, 1)).showIf(() -> separate.on());

        public ViewModel() { super("ViewModel", "Position, scale and rotate both hands independently", Category.VIEW); }

        private double[] presetBase() {
            return switch (preset.get()) {
                case "Low & Wide" -> new double[]{0.12, -0.12, 0.0, 0.92, 0, 0, 0};
                case "Centered" -> new double[]{-0.25, 0.02, 0.05, 0.95, 0, 0, 0};
                case "Tucked In" -> new double[]{0.0, -0.1, 0.08, 0.8, -8, 0, 4};
                case "Classic 1.8" -> new double[]{0.04, -0.06, 0.02, 0.85, -6, 5, 0};
                default -> new double[]{0, 0, 0, 1, 0, 0, 0};
            };
        }

        /** Called before the vanilla equip transform. */
        public void apply(MatrixStack m, Arm arm, boolean mainHand) {
            double[] b = presetBase();
            boolean useOff = separate.on() && !mainHand;
            double x = (useOff ? ox.d() : mx.d()) + b[0], y = (useOff ? oy.d() : my.d()) + b[1], z = (useOff ? oz.d() : mz.d()) + b[2];
            double s = (useOff ? os.d() : ms.d()) * b[3];
            double rx = (useOff ? orx.d() : mrx.d()) + b[4], ry = (useOff ? ory.d() : mry.d()) + b[5], rz = (useOff ? orz.d() : mrz.d()) + b[6];
            float side = arm == Arm.RIGHT ? 1f : -1f;
            m.translate(x * side, y, z);
            if (s != 1.0) m.scale((float) s, (float) s, (float) s);
            if (rx != 0 || ry != 0 || rz != 0) {
                m.translate(0.56f * side, -0.52f, -0.72f);
                if (rx != 0) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) rx));
                if (ry != 0) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) ry * side));
                if (rz != 0) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) rz * side));
                m.translate(-0.56f * side, 0.52f, 0.72f);
            }
        }
    }

    // =====================================================================================================
    public static final class SwingAnimations extends Module {
        public final Setting.Mode mode = add(new Setting.Mode("Animation", "Smooth", "Vanilla", "Old 1.7", "Smooth", "Spin", "Chop", "Slash", "Punch", "Poke", "Slide", "Wave"));
        public final Setting.Num speed = add(new Setting.Num("Swing Speed", 1.0, 0.3, 3.0, 0.05));
        final Setting.Num strength = add(new Setting.Num("Strength", 1.0, 0.3, 2.0, 0.05));
        final Setting.Bool mirrorOff = add(new Setting.Bool("Mirror Off-Hand", true));
        final Setting.Bool easing = add(new Setting.Bool("Ease Curve", true));
        final Setting.Num spinTurns = add(new Setting.Num("Spin Turns", 1.0, 0.5, 4.0, 0.5)).showIf(() -> mode.is("Spin"));

        public SwingAnimations() { super("SwingAnimations", "Custom first-person swing styles and swing speed", Category.VIEW); }

        public boolean replaces() { return enabled && !mode.is("Vanilla"); }

        public int duration(int vanilla) { return Math.max(1, Math.round(vanilla / speed.f())); }

        /** Replaces the vanilla applySwingOffset (called at the hand pivot). */
        public void apply(MatrixStack m, Arm arm, float t) {
            float side = arm == Arm.RIGHT ? 1f : (mirrorOff.on() ? -1f : 1f);
            float k = strength.f();
            float u = easing.on() ? Anim.easeInOut(t) : t;
            float s = (float) Math.sin(t * Math.PI), s2 = (float) Math.sin(Math.sqrt(t) * Math.PI);
            switch (mode.get()) {
                case "Old 1.7" -> {
                    m.translate(-0.4f * s2 * side * k * 0.5f, 0.2f * (float) Math.sin(Math.sqrt(t) * Math.PI * 2) * k, -0.2f * s * k);
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (45f + s * -20f * k)));
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * s * -20f * k));
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(s2 * -80f * k));
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -45f));
                }
                case "Smooth" -> {
                    float e = (float) Math.sin(u * Math.PI);
                    m.translate(-0.05f * side * e * k, 0.05f * e * k, -0.35f * e * k);
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-65f * e * k));
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 15f * e * k));
                }
                case "Spin" -> {
                    m.translate(0, 0, -0.1f * s * k);
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(u * 360f * spinTurns.f()));
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-20f * s * k));
                }
                case "Chop" -> {
                    m.translate(0, 0.1f * s * k, -0.3f * s * k);
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-100f * s * k));
                }
                case "Slash" -> {
                    m.translate(0.15f * side * (0.5f - u) * k, 0, -0.15f * s * k);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (0.5f - u) * 120f * k));
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (0.5f - u) * 60f * k));
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30f * s * k));
                }
                case "Punch" -> m.translate(0, 0, -0.7f * s2 * k);
                case "Poke" -> { m.translate(0, 0.08f * s * k, -0.9f * s * k); m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-10f * s * k)); }
                case "Slide" -> { m.translate(-0.5f * side * s2 * k, 0, 0); m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 20f * s2 * k)); }
                case "Wave" -> {
                    m.translate(0, 0.05f * (float) Math.sin(t * Math.PI * 4) * k, -0.1f * s * k);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (float) Math.sin(t * Math.PI * 3) * 35f * k));
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-45f * s * k));
                }
                default -> {}
            }
        }
    }

    // =====================================================================================================
    public static final class AspectRatio extends Module {
        final Setting.Mode preset = add(new Setting.Mode("Preset", "4:3", "4:3", "5:4", "16:10", "21:9", "1:1", "Custom"));
        final Setting.Num custom = add(new Setting.Num("Custom Ratio", 1.78, 0.5, 3.5, 0.01)).showIf(() -> preset.is("Custom"));
        final Setting.Bool smooth = add(new Setting.Bool("Smooth Transition", true));
        private float cur = 0f;

        public AspectRatio() { super("AspectRatio", "Stretch / squash the 3D view (4:3, 16:10, custom)", Category.VIEW); }

        private float target() {
            return switch (preset.get()) {
                case "4:3" -> 4f / 3f; case "5:4" -> 1.25f; case "16:10" -> 1.6f; case "21:9" -> 21f / 9f; case "1:1" -> 1f;
                default -> custom.f();
            };
        }

        @Override public void onTick() {
            float t = target();
            cur = cur <= 0 ? (smooth.on() ? (float) Pulse.mc.getWindow().getFramebufferWidth() / Math.max(1, Pulse.mc.getWindow().getFramebufferHeight()) : t) : (smooth.on() ? cur + (t - cur) * 0.25f : t);
            Pulse.aspect = cur;
        }

        @Override public void onDisable() { Pulse.aspect = 0f; cur = 0f; }
    }

    // =====================================================================================================
    public static final class SmoothZoom extends Module {
        final Setting.Bind key = add(new Setting.Bind("Zoom Key", GLFW.GLFW_KEY_C));
        final Setting.Mode keyMode = add(new Setting.Mode("Key Mode", "Hold", "Hold", "Toggle"));
        final Setting.Num factor = add(new Setting.Num("Zoom Factor", 0.25, 0.04, 0.9, 0.01));
        final Setting.Num step = add(new Setting.Num("Scroll Step", 0.04, 0.01, 0.15, 0.01));
        final Setting.Num smoothness = add(new Setting.Num("Smoothness", 12, 3, 30, 1));
        final Setting.Bool scroll = add(new Setting.Bool("Scroll To Adjust", true));
        final Setting.Bool cinematic = add(new Setting.Bool("Cinematic Camera", false));
        final Setting.Bool lowerSens = add(new Setting.Bool("Scale Mouse Sensitivity", true));
        private boolean zooming, wasDown;
        private float target = 1f;
        private double savedSens = -1;

        public SmoothZoom() { super("SmoothZoom", "Smooth FOV zoom with scroll wheel adjustment", Category.VIEW); }

        public boolean isZooming() { return enabled && zooming; }

        public boolean onScroll(double dy) {
            if (!isZooming() || !scroll.on() || dy == 0) return false;
            float f = factor.f() - (float) Math.signum(dy) * step.f();
            factor.set((double) Math.max(factor.min, Math.min(factor.max, f)));
            return true;
        }

        @Override public void onTick() {
            var m = Pulse.mc;
            boolean down = m.currentScreen == null && keyDown(key.get());
            if (keyMode.is("Hold")) zooming = down;
            else if (down && !wasDown) zooming = !zooming;
            wasDown = down;
            if (m.currentScreen != null && keyMode.is("Hold")) zooming = false;
            target = zooming ? factor.f() : 1f;
            if (zooming && lowerSens.on()) {
                if (savedSens < 0) savedSens = m.options.getMouseSensitivity().getValue();
                m.options.getMouseSensitivity().setValue(Math.max(0.0, savedSens * Math.max(0.2, target)));
            } else restoreSens();
            if (cinematic.on()) m.options.smoothCameraEnabled = zooming;
        }

        private void restoreSens() {
            if (savedSens >= 0) { Pulse.mc.options.getMouseSensitivity().setValue(savedSens); savedSens = -1; }
        }

        /** Called every frame by GameRendererMixin. */
        public float frame() {
            Pulse.zoomMul = Anim.to(Pulse.zoomMul, target, smoothness.f());
            if (Math.abs(Pulse.zoomMul - target) < 0.001f) Pulse.zoomMul = target;
            return Pulse.zoomMul;
        }

        @Override public void onDisable() { zooming = false; target = 1f; Pulse.zoomMul = 1f; restoreSens(); if (Pulse.mc.options != null) Pulse.mc.options.smoothCameraEnabled = false; }
    }

    // =====================================================================================================
    public static final class FreeLook extends Module {
        final Setting.Bind key = add(new Setting.Bind("Activation Key", GLFW.GLFW_KEY_LEFT_ALT));
        final Setting.Mode keyMode = add(new Setting.Mode("Key Mode", "Hold", "Hold", "Toggle"));
        final Setting.Bool thirdPerson = add(new Setting.Bool("Auto Third Person", true));
        final Setting.Bool snapBack = add(new Setting.Bool("Snap Back On Release", true));
        final Setting.Num sens = add(new Setting.Num("Sensitivity", 1.0, 0.2, 3.0, 0.05));
        final Setting.Bool invertY = add(new Setting.Bool("Invert Pitch", false));
        private boolean active, wasDown;
        private Perspective savedPersp;

        public FreeLook() { super("FreeLook", "Look around 360 degrees without turning your player (client-only camera)", Category.VIEW); }

        public float mul() { return sens.f(); }
        public boolean invert() { return invertY.on(); }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.player == null) { stop(); return; }
            boolean down = m.currentScreen == null && keyDown(key.get());
            boolean want = keyMode.is("Hold") ? down : (down && !wasDown ? !active : active);
            wasDown = down;
            if (m.currentScreen != null && keyMode.is("Hold")) want = false;
            if (want && !active) start(); else if (!want && active) stop();
        }

        private void start() {
            var m = Pulse.mc;
            active = true; Pulse.freeLook = true; Pulse.freeYaw = m.player.getYaw(); Pulse.freePitch = m.player.getPitch();
            savedPersp = m.options.getPerspective();
            if (thirdPerson.on() && savedPersp.isFirstPerson()) m.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }

        private void stop() {
            if (!active) return;
            active = false; Pulse.freeLook = false;
            if (savedPersp != null && thirdPerson.on() && snapBack.on()) Pulse.mc.options.setPerspective(savedPersp);
            savedPersp = null;
        }

        @Override public void onDisable() { stop(); }
    }

    // =====================================================================================================
    public static final class NoRender extends Module {
        static final String[] OVERLAYS = {"Hurt Camera Shake", "View Bobbing", "Fire Overlay", "Pumpkin Overlay", "Water Overlay", "In-Wall Overlay", "Nausea / Portal Wobble", "FOV Effects", "Boss Bars", "Vanilla Crosshair", "Beacon Beams"};
        static final String[] PARTS = {"Explosions", "Smoke", "Rain Splashes", "Potion Swirls", "Falling Dust", "Block Break", "Campfire Smoke", "Sculk / Spore"};
        final Setting.Multi hide = add(new Setting.Multi("Hide", OVERLAYS, "Hurt Camera Shake", "Fire Overlay", "Pumpkin Overlay"));
        final Setting.Multi particles = add(new Setting.Multi("Hide Particles", PARTS));
        final Setting.Num fireHeight = add(new Setting.Num("Fire Overlay Lowering", 0.0, 0.0, 0.6, 0.05));
        private final Map<String, Object> saved = new HashMap<>();

        public NoRender() { super("NoRender", "Remove screen shake, overlays, nausea, beacon beams and noisy particles", Category.VIEW); }

        public boolean has(String s) { return enabled && hide.has(s); }

        public boolean particleBlocked(String id) {
            if (!enabled || particles.value.isEmpty()) return false;
            return switch (id) {
                case "explosion", "explosion_emitter", "poof", "gust_emitter_large", "gust_emitter_small" -> particles.has("Explosions");
                case "smoke", "large_smoke", "white_smoke" -> particles.has("Smoke");
                case "rain", "splash", "bubble_pop" -> particles.has("Rain Splashes");
                case "entity_effect", "ambient_entity_effect", "effect", "instant_effect", "witch" -> particles.has("Potion Swirls");
                case "falling_dust", "dust_pillar" -> particles.has("Falling Dust");
                case "block", "block_marker", "item" -> particles.has("Block Break");
                case "campfire_cosy_smoke", "campfire_signal_smoke" -> particles.has("Campfire Smoke");
                case "sculk_soul", "sculk_charge", "sculk_charge_pop", "spore_blossom_air", "falling_spore_blossom", "spore_blossom_air_ambient" -> particles.has("Sculk / Spore");
                default -> false;
            };
        }

        private void force(String key, Object current, Runnable setter, boolean want, Object original, Runnable restore) {
            if (want) { saved.putIfAbsent(key, original); setter.run(); }
            else if (saved.containsKey(key)) { restore.run(); saved.remove(key); }
        }

        @Override public void onTick() {
            var o = Pulse.mc.options;
            if (o == null) return;
            force("hurt", null, () -> o.getDamageTiltStrength().setValue(0.0), hide.has("Hurt Camera Shake"), o.getDamageTiltStrength().getValue(), () -> o.getDamageTiltStrength().setValue((Double) saved.get("hurt")));
            force("bob", null, () -> o.getBobView().setValue(false), hide.has("View Bobbing"), o.getBobView().getValue(), () -> o.getBobView().setValue((Boolean) saved.get("bob")));
            force("nausea", null, () -> o.getDistortionEffectScale().setValue(0.0), hide.has("Nausea / Portal Wobble"), o.getDistortionEffectScale().getValue(), () -> o.getDistortionEffectScale().setValue((Double) saved.get("nausea")));
            force("fov", null, () -> o.getFovEffectScale().setValue(0.0), hide.has("FOV Effects"), o.getFovEffectScale().getValue(), () -> o.getFovEffectScale().setValue((Double) saved.get("fov")));
        }

        @Override public void onDisable() {
            var o = Pulse.mc.options;
            if (o == null) return;
            if (saved.containsKey("hurt")) o.getDamageTiltStrength().setValue((Double) saved.get("hurt"));
            if (saved.containsKey("bob")) o.getBobView().setValue((Boolean) saved.get("bob"));
            if (saved.containsKey("nausea")) o.getDistortionEffectScale().setValue((Double) saved.get("nausea"));
            if (saved.containsKey("fov")) o.getFovEffectScale().setValue((Double) saved.get("fov"));
            saved.clear();
        }
    }

    // =====================================================================================================
    public static final class SmoothHotbar extends Module {
        final Setting.Mode style = add(new Setting.Mode("Style", "Glass Pill", "Glass Pill", "Flat", "Minimal", "Floating Slots"));
        final Setting.Mode selector = add(new Setting.Mode("Selector", "Rounded", "Rounded", "Underline", "Glow", "Lift"));
        final Setting.Num slot = add(new Setting.Num("Slot Size", 20, 16, 28, 1));
        final Setting.Num gap = add(new Setting.Num("Gap", 2, 0, 8, 1));
        final Setting.Num speed = add(new Setting.Num("Slide Speed", 16, 4, 40, 1));
        final Setting.Num bottom = add(new Setting.Num("Bottom Margin", 2, 0, 20, 1));
        final Setting.Num radius = add(new Setting.Num("Corner Radius", 8, 0, 14, 1));
        final Setting.Bool offhand = add(new Setting.Bool("Show Off-Hand", true));
        final Setting.Bool numbers = add(new Setting.Bool("Slot Numbers", false));
        final Setting.Color bgCol = add(new Setting.Color("Background", 0x0E1118, 0xB0));
        final Setting.Color selCol = add(new Setting.Color("Selector Colour", 0x7C9CFF, 0xB48CFF, 0xB0).mode("Theme"));
        private float pos = -1;

        public SmoothHotbar() { super("SmoothHotbar", "Animated glass hotbar with sliding selector (replaces vanilla hotbar)", Category.VIEW); }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            if (m.player == null || m.options.hudHidden || m.interactionManager != null && m.interactionManager.getCurrentGameMode().isSpectator()) return;
            int sel = m.player.getInventory().getSelectedSlot();
            float S = slot.f(), G = gap.f(), W = 9 * S + 8 * G + 8, H = S + 8;
            int sw = m.getWindow().getScaledWidth(), sh = m.getWindow().getScaledHeight();
            float x0 = (sw - W) / 2f, y0 = sh - H - bottom.f();
            if (pos < 0) pos = sel;
            // circular slide for wrap-around feels odd, so plain approach
            pos = Anim.to(pos, sel, speed.f());
            String st = style.get();
            if (!st.equals("Floating Slots") && !st.equals("Minimal")) {
                Render2D.glow(c, x0, y0, W, H, radius.f(), 0x70000000, 4);
                Render2D.rrect(c, x0, y0, W, H, st.equals("Flat") ? Math.min(3, radius.f()) : radius.f(), bgCol.get());
                Render2D.outline(c, x0, y0, W, H, st.equals("Flat") ? Math.min(3, radius.f()) : radius.f(), ThemeManager.cur().outline);
            } else if (st.equals("Minimal")) Render2D.rrect(c, x0, y0, W, H, radius.f(), ColorUtil.alphaMul(bgCol.get(), 0.4f));
            float sx = x0 + 4 + pos * (S + G);
            for (int i = 0; i < 9; i++) {
                float x = x0 + 4 + i * (S + G), y = y0 + 4;
                if (st.equals("Floating Slots")) Render2D.rrect(c, x, y, S, S, radius.f() * 0.5f, bgCol.get());
                float lift = selector.is("Lift") ? -3f * Math.max(0f, 1f - Math.abs(pos - i)) : 0f;
                ItemStack is = m.player.getInventory().getStack(i);
                if (!is.isEmpty()) {
                    float k = S / 20f;
                    var mx = c.getMatrices();
                    mx.pushMatrix(); mx.translate(x + (S - 16 * k) / 2f, y + (S - 16 * k) / 2f + lift); mx.scale(k, k);
                    c.drawItem(is, 0, 0); c.drawStackOverlay(Render2D.font(), is, 0, 0);
                    mx.popMatrix();
                }
                if (numbers.on()) Render2D.textScaled(c, String.valueOf(i + 1), x + 1, y, 0.6f, ThemeManager.cur().dim, false);
            }
            float sy = y0 + 4;
            switch (selector.get()) {
                case "Underline" -> Render2D.rrect(c, sx + 2, sy + S + 1, S - 4, 2, 1, selCol.get());
                case "Glow" -> { Render2D.glow(c, sx, sy, S, S, 5, selCol.get(), 5); Render2D.outline(c, sx, sy, S, S, 5, selCol.get(0.5f)); }
                case "Lift" -> Render2D.rrect(c, sx + S / 2f - 3, sy + S + 1, 6, 2, 1, selCol.get());
                default -> { Render2D.rrect(c, sx - 1, sy - 1, S + 2, S + 2, 5, ColorUtil.alphaMul(selCol.get(), 0.35f)); Render2D.outline(c, sx - 1, sy - 1, S + 2, S + 2, 5, selCol.get()); }
            }
            if (offhand.on()) {
                ItemStack off = m.player.getOffHandStack();
                if (!off.isEmpty()) {
                    float ox = x0 - S - 10, oy = y0 + 4;
                    Render2D.rrect(c, ox - 4, y0, S + 8, H, radius.f(), bgCol.get());
                    Render2D.item(c, off, ox + (S - 16) / 2f, oy + (S - 16) / 2f, 1f, true);
                }
            }
        }
    }

    // =====================================================================================================
    public static final class SmoothChat extends Module {
        final Setting.Num slide = add(new Setting.Num("Slide Distance", 14, 0, 50, 1));
        final Setting.Num speed = add(new Setting.Num("Speed", 14, 4, 40, 1));
        final Setting.Bool dim = add(new Setting.Bool("Dim Background", true));
        final Setting.Num dimAmount = add(new Setting.Num("Dim Opacity", 0.25, 0.0, 0.8, 0.05)).showIf(() -> dim.on());
        final Setting.Bool fadeBar = add(new Setting.Bool("Accent Line On Input", true));
        final Setting.Color line = add(new Setting.Color("Accent Colour", 0x7C9CFF, 0xB48CFF, 0xCC).mode("Theme"));
        private float open;

        public SmoothChat() { super("SmoothChat", "Animated chat input (slide-in, dim, accent line)", Category.VIEW); }

        public void reset() { open = 0f; }

        public void before(DrawContext c, boolean chatOpen, int sw, int sh) {
            open = Anim.to(open, chatOpen ? 1f : 0f, speed.f());
            if (dim.on() && open > 0.01f) c.fillGradient(0, sh / 2, sw, sh, 0, ColorUtil.alphaMul(0xFF000000, open * dimAmount.f()));
            var m = c.getMatrices();
            m.pushMatrix();
            m.translate(0, (1f - Anim.easeOutCubic(open)) * slide.f());
        }

        public void after(DrawContext c, int sw, int sh) {
            c.getMatrices().popMatrix();
            if (fadeBar.on() && open > 0.02f) Render2D.gradH(c, 2, sh - 14, (sw - 4) * Anim.easeOutCubic(open), 1, ColorUtil.alphaMul(line.get(0f), open), ColorUtil.alphaMul(line.get(0.5f), open));
        }
    }

    // =====================================================================================================
    public static final class TotemPop extends Module {
        public final Setting.Bool hideVanilla = add(new Setting.Bool("Hide Vanilla Animation", true));
        final Setting.Mode style = add(new Setting.Mode("Style", "Scale Pop", "Scale Pop", "Spin", "Slide Up", "Burst"));
        final Setting.Num size = add(new Setting.Num("Size", 7.0, 2.0, 16.0, 0.5));
        final Setting.Num duration = add(new Setting.Num("Duration (s)", 1.0, 0.3, 3.0, 0.1));
        final Setting.Num glowAlpha = add(new Setting.Num("Glow Opacity", 0.6, 0.0, 1.0, 0.05));
        final Setting.Num yOffset = add(new Setting.Num("Vertical Offset", 0, -100, 100, 1));
        final Setting.Bool particles = add(new Setting.Bool("Sparkles", true));
        final Setting.Color glow = add(new Setting.Color("Glow Colour", 0xF0D070, 0xFFA060, 255).mode("Gradient"));
        private final ItemStack totem = new ItemStack(Items.TOTEM_OF_UNDYING);
        private final Random rnd = new Random(7);

        public TotemPop() { super("TotemPop", "Custom totem-pop animation: size, speed, glow and style", Category.VIEW); }

        @Override public void onOverlay(DrawContext c, float td) {
            long t0 = Pulse.ownPopTime;
            if (t0 < 0) return;
            float f = (System.currentTimeMillis() - t0) / (duration.f() * 1000f);
            if (f >= 1f) return;
            var m = Pulse.mc;
            float sw = m.getWindow().getScaledWidth(), sh = m.getWindow().getScaledHeight();
            float cx = sw / 2f, cy = sh / 2f + yOffset.f();
            float fadeOut = f > 0.75f ? 1f - (f - 0.75f) / 0.25f : 1f;
            float sc, rot = 0f, dy = 0f;
            switch (style.get()) {
                case "Spin" -> { sc = size.f() * Anim.easeOutBack(Math.min(1f, f * 3f)) * fadeOut; rot = f * 360f * 1.5f; }
                case "Slide Up" -> { sc = size.f() * 0.8f * fadeOut; dy = (1f - Anim.easeOutCubic(Math.min(1f, f * 2f))) * 80f - f * 40f; }
                case "Burst" -> sc = size.f() * (f < 0.2f ? Anim.easeOutBack(f / 0.2f) : 1f + 0.15f * (float) Math.sin(f * 20)) * fadeOut;
                default -> sc = size.f() * Anim.easeOutBack(Math.min(1f, f * 4f)) * fadeOut;
            }
            float ga = glowAlpha.f() * fadeOut;
            if (ga > 0.01f) {
                float gr = sc * 11f;
                for (int i = 5; i >= 1; i--) Render2D.circle(c, cx, cy + dy, gr * (0.5f + i * 0.2f), ColorUtil.alphaMul(glow.get(i * 0.1f), ga * 0.12f));
            }
            var mx = c.getMatrices();
            mx.pushMatrix();
            mx.translate(cx, cy + dy);
            if (rot != 0f) mx.rotate((float) Math.toRadians(rot));
            mx.scale(sc, sc);
            c.drawItem(totem, -8, -8);
            mx.popMatrix();
            if (particles.on()) {
                for (int i = 0; i < 14; i++) {
                    float a = i * 0.449f + f * 2.5f, r = 20f + f * sc * 14f * (0.6f + (i % 5) * 0.15f);
                    Render2D.circle(c, cx + (float) Math.cos(a) * r, cy + dy + (float) Math.sin(a) * r, 1.6f, ColorUtil.alphaMul(glow.get(i * 0.07f), fadeOut * 0.9f));
                }
            }
        }
    }
}
