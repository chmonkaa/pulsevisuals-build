package dev.pulse.modules;

import dev.pulse.Pulse;
import dev.pulse.mixin.OverlayTextureAccessor;
import dev.pulse.module.Category;
import dev.pulse.module.Module;
import dev.pulse.setting.Setting;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.*;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.Consumer;

/** Entity-related visuals. */
public final class VisualModules {
    private VisualModules() {}

    static final String[] TYPES = {"Players", "Hostile", "Passive", "Other Living"};

    static boolean typeOk(Entity e, Setting.Multi m) {
        if (e instanceof PlayerEntity) return m.has("Players");
        if (e instanceof HostileEntity) return m.has("Hostile");
        if (e instanceof PassiveEntity) return m.has("Passive");
        return e instanceof LivingEntity && m.has("Other Living");
    }

    /** Friends get their own colour in every visual. */
    static int colorFor(Entity e, Setting.Color base, float phase) {
        var f = Modules.FRIENDS;
        if (f != null && f.enabled && f.highlight.on() && Friends.is(e)) return f.color.get(phase);
        return base.get(phase);
    }

    /** Friend colour override for an already computed colour (no allocation). */
    static int friendOr(Entity e, int col) {
        var f = Modules.FRIENDS;
        return f != null && f.enabled && f.highlight.on() && Friends.is(e) ? ColorUtil.withAlpha(f.color.value, col >>> 24) : col;
    }

    static boolean friendSkip(Entity e, Setting.Bool ignore) { return ignore.on() && Friends.is(e); }

    static LivingEntity currentTarget(double hold, String source) {
        var m = Pulse.mc;
        if (m.player == null) return null;
        if (!source.equals("Crosshair") && Pulse.target != null && Pulse.target.isAlive() && Pulse.target != m.player
                && System.currentTimeMillis() - Pulse.targetTime < hold * 1000) return Pulse.target;
        if (!source.equals("Last Hit") && m.targetedEntity instanceof LivingEntity le) return le;
        return null;
    }

    // =====================================================================================================
    public static final class TargetESP extends Module {
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Ring", "Ring", "Ghosts", "Orbs", "Projection", "Cube Pulse", "Helix"));
        final Setting.Mode source = add(new Setting.Mode("Target Source", "Both", "Last Hit", "Crosshair", "Both"));
        final Setting.Color color = add(new Setting.Color("Color", 0x7C9CFF, 0xB48CFF, 0xD0).mode("Theme"));
        final Setting.Color hurtCol = add(new Setting.Color("Hurt Color", 0xFF5A5A, 0xE0));
        final Setting.Num radius = add(new Setting.Num("Radius Offset", 0.2, -0.3, 1.5, 0.05));
        final Setting.Num speed = add(new Setting.Num("Speed", 1.6, 0.2, 6, 0.1));
        final Setting.Num size = add(new Setting.Num("Size", 1.0, 0.3, 3, 0.1));
        final Setting.Num thick = add(new Setting.Num("Thickness", 0.07, 0.01, 0.3, 0.01));
        final Setting.Num trailLen = add(new Setting.Num("Trail Length", 6, 0, 16, 1));
        final Setting.Num segments = add(new Setting.Num("Segments", 40, 12, 96, 2));
        final Setting.Num hold = add(new Setting.Num("Hold Time (s)", 4.0, 1, 15, 0.5));
        final Setting.Bool hurtFlash = add(new Setting.Bool("Flash When Hurt", true));
        final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore Friends", false));
        private float alpha;
        private LivingEntity last;

        public TargetESP() { super("TargetESP", "Rings, ghosts, orbs and projections around your target", Category.VISUALS); }

        @Override public void onWorld(float td) {
            LivingEntity t = currentTarget(hold.d(), source.get());
            if (t != null && friendSkip(t, ignoreFriends)) t = null;
            alpha = Anim.to(alpha, t != null ? 1f : 0f, 10f);
            if (t != null) last = t;
            if (last == null || alpha < 0.02f || !last.isAlive()) return;
            LivingEntity e = last;
            Vec3d p = e.getLerpedPos(td);
            double h = e.getHeight(), r = e.getWidth() * 0.5 + radius.d();
            float time = Anim.time() * speed.f();
            boolean hurt = hurtFlash.on() && e.hurtTime > 0;
            int segs = segments.i();
            float sz = size.f();
            final float al = alpha;
            java.util.function.IntUnaryOperator col = i -> {
                int c = hurt ? hurtCol.get() : colorFor(e, color, i / (float) segs);
                return ColorUtil.alphaMul(c, al);
            };
            switch (mode.get()) {
                case "Ring" -> {
                    double y = p.y + h * (0.5 + 0.5 * Math.sin(time));
                    int tl = trailLen.i();
                    for (int k = tl; k >= 0; k--) {
                        double yy = p.y + h * (0.5 + 0.5 * Math.sin(time - k * 0.07));
                        final float fade = k == 0 ? 1f : 0.35f * (1f - k / (float) (tl + 1));
                        WorldRender.ringH(p.x, yy, p.z, r, thick.d(), segs, i -> ColorUtil.alphaMul(col.applyAsInt(i), fade));
                    }
                }
                case "Ghosts", "Orbs" -> {
                    int n = mode.is("Ghosts") ? 3 : 5;
                    for (int i = 0; i < n; i++) {
                        for (int k = trailLen.i(); k >= 0; k--) {
                            double a = time * 1.5 + i * Math.PI * 2 / n - k * 0.09;
                            double y = p.y + h * (0.5 + 0.38 * Math.sin(time * (mode.is("Ghosts") ? 0.9 : 1.7) + i * 1.7 - k * 0.09));
                            float f = 1f - k / (float) (trailLen.i() + 1);
                            int c = ColorUtil.alphaMul(col.applyAsInt(i * segs / n), al * f * f);
                            WorldRender.orb(p.x + Math.cos(a) * r, y, p.z + Math.sin(a) * r, 0.16 * sz * (0.5 + 0.5 * f), c);
                        }
                    }
                }
                case "Projection" -> {
                    double a = time * 0.8;
                    for (int s = 0; s < 4; s++) {
                        double a1 = a + s * Math.PI / 2, a2 = a + (s + 1) * Math.PI / 2;
                        double ex = r * 1.2 * sz;
                        WorldRender.lineC(p.x + Math.cos(a1) * ex, p.y + 0.02, p.z + Math.sin(a1) * ex, col.applyAsInt(s * segs / 4),
                                p.x + Math.cos(a2) * ex, p.y + 0.02, p.z + Math.sin(a2) * ex, col.applyAsInt((s + 1) * segs / 4 % segs), thick.d() * 1.2);
                    }
                    WorldRender.ringH(p.x, p.y + 0.02, p.z, r * 0.85, thick.d() * 0.7, segs, i -> ColorUtil.alphaMul(col.applyAsInt(i), 0.55f));
                    for (int s = 0; s < 4; s++) {
                        double a1 = a + s * Math.PI / 2;
                        double ex = r * 1.2 * sz;
                        WorldRender.line(p.x + Math.cos(a1) * ex, p.y + 0.02, p.z + Math.sin(a1) * ex, p.x + Math.cos(a1) * ex, p.y + h * (0.5 + 0.5 * Math.sin(time + s)), p.z + Math.sin(a1) * ex, thick.d() * 0.6, ColorUtil.alphaMul(col.applyAsInt(0), 0.4f));
                    }
                }
                case "Cube Pulse" -> {
                    double k = 0.5 + 0.5 * Math.sin(time * 1.2);
                    double hw = e.getWidth() / 2 + radius.d() * 0.5 + k * 0.2 * sz;
                    Box b = new Box(p.x - hw, p.y - k * 0.1, p.z - hw, p.x + hw, p.y + h + k * 0.1, p.z + hw);
                    WorldRender.boxFill(b, ColorUtil.alphaMul(col.applyAsInt(0), 0.12f));
                    WorldRender.boxLines(b, thick.d() * 0.5, col.applyAsInt(segs / 2));
                }
                default -> { // Helix
                    for (int strand = 0; strand < 2; strand++) {
                        double px = 0, py = 0, pz = 0; boolean first = true;
                        for (int i = 0; i <= 32; i++) {
                            double f = i / 32.0, a = time * 1.5 + f * Math.PI * 4 + strand * Math.PI;
                            double x = p.x + Math.cos(a) * r, y = p.y + f * h, z = p.z + Math.sin(a) * r;
                            if (!first) WorldRender.line(px, py, pz, x, y, z, thick.d(), col.applyAsInt((int) (f * (segs - 1))));
                            px = x; py = y; pz = z; first = false;
                        }
                    }
                }
            }
        }
    }

    // =====================================================================================================
    public static final class HitColor extends Module {
        final Setting.Color color = add(new Setting.Color("Hit Color", 0xFF5A8A, 0xB48CFF, 0xB2).mode("Static"));
        final Setting.Num animSpeed = add(new Setting.Num("Colour Cycle Speed", 1.0, 0.1, 5, 0.1));
        private int applied = 0;

        public HitColor() { super("HitColor", "Custom damage tint on hurt entities (vanilla red -> your colour)", Category.VISUALS); color.speed = 1f; }

        private void apply(int argb) {
            try {
                OverlayTexture ot = Pulse.mc.gameRenderer.getOverlayTexture();
                NativeImageBackedTexture tex = ((OverlayTextureAccessor) ot).pulse$getTexture();
                NativeImage img = tex.getImage();
                if (img == null) return;
                for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) img.setColorArgb(x, y, argb);
                tex.upload();
                applied = argb;
            } catch (Throwable ignored) {}
        }

        @Override public void onTick() {
            color.speed = animSpeed.f();
            int c = color.get();
            if (c != applied) apply(c);
        }

        @Override public void onDisable() { apply(0xB2FF0000); }
    }

    // =====================================================================================================
    public static final class DamageParticles extends Module {
        final Setting.Mode style = add(new Setting.Mode("Style", "Float Up", "Float Up", "Arc", "Pop", "Drift"));
        final Setting.Mode targets = add(new Setting.Mode("Show For", "Everything Near", "Everything Near", "Only My Hits", "Players Only"));
        final Setting.Color dmgCol = add(new Setting.Color("Damage Color", 0xFF6B6B, 0xFFB86B, 255));
        final Setting.Color healCol = add(new Setting.Color("Heal Color", 0x6EDC9A, 255));
        final Setting.Color critCol = add(new Setting.Color("Big Hit Color", 0xFFD25A, 255));
        final Setting.Num size = add(new Setting.Num("Size", 1.0, 0.5, 3, 0.1));
        final Setting.Num life = add(new Setting.Num("Lifetime (s)", 1.2, 0.4, 4, 0.1));
        final Setting.Num rise = add(new Setting.Num("Rise Height", 1.0, 0.2, 3, 0.1));
        final Setting.Num bigAt = add(new Setting.Num("Big Hit Threshold", 6, 2, 20, 0.5));
        final Setting.Num range = add(new Setting.Num("Range", 24, 6, 64, 1));
        final Setting.Bool hearts = add(new Setting.Bool("Show Heal Numbers", true));
        final Setting.Bool shadow = add(new Setting.Bool("Text Shadow", true));
        final Setting.Bool scaleDist = add(new Setting.Bool("Scale With Distance", true));
        final Setting.Bool decimals = add(new Setting.Bool("Decimals", true));

        private static final class Pop { Vec3d pos; String text; int color; float age, life, big, drift; }
        private final List<Pop> pops = new ArrayList<>();
        private final Map<Integer, Float> hp = new HashMap<>();
        private int tick;
        private final Random rnd = new Random();

        public DamageParticles() { super("DamageParticles", "Floating damage / heal numbers over entities", Category.VISUALS); }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) { pops.clear(); hp.clear(); return; }
            Set<Integer> seen = new HashSet<>();
            for (Entity e : m.world.getEntities()) {
                if (!(e instanceof LivingEntity le) || le == m.player && false) continue;
                if (le.distanceTo(m.player) > range.d()) continue;
                if (targets.is("Players Only") && !(le instanceof PlayerEntity)) continue;
                if (targets.is("Only My Hits") && le != Pulse.target) continue;
                float cur = le.getHealth() + le.getAbsorptionAmount();
                Float prev = hp.put(le.getId(), cur);
                seen.add(le.getId());
                if (prev == null) continue;
                float d = prev - cur;
                if (Math.abs(d) < 0.05f || (d < 0 && !hearts.on())) continue;
                Pop p = new Pop();
                p.pos = new Vec3d(le.getX() + (rnd.nextDouble() - 0.5) * 0.5, le.getY() + le.getHeight() * 0.9, le.getZ() + (rnd.nextDouble() - 0.5) * 0.5);
                p.text = (d > 0 ? "-" : "+") + (decimals.on() ? String.format(Locale.ROOT, "%.1f", Math.abs(d)) : String.valueOf(Math.round(Math.abs(d))));
                p.color = d < 0 ? healCol.get() : (d >= bigAt.d() ? critCol.get() : dmgCol.get(tick * 0.01f));
                p.life = life.f(); p.big = d >= bigAt.d() ? 1.35f : 1f; p.drift = (rnd.nextFloat() - 0.5f) * 1.2f;
                pops.add(p);
            }
            hp.keySet().retainAll(seen);
            tick++;
        }

        @Override public void onOverlay(DrawContext c, float td) {
            if (pops.isEmpty()) return;
            float dt = Anim.dt;
            for (Iterator<Pop> it = pops.iterator(); it.hasNext(); ) {
                Pop p = it.next();
                p.age += dt;
                if (p.age >= p.life) { it.remove(); continue; }
                float f = p.age / p.life;
                double rz = rise.d() * Anim.easeOutCubic(f);
                double ox = 0, oy = rz;
                switch (style.get()) {
                    case "Arc" -> { ox = p.drift * f; oy = rise.d() * (Math.sin(f * Math.PI) * 0.8 + f * 0.2); }
                    case "Drift" -> ox = p.drift * f * 1.5;
                    default -> {}
                }
                float[] o = new float[3];
                if (!Proj.project(p.pos.x + ox, p.pos.y + oy, p.pos.z, o)) continue;
                float s = size.f() * p.big;
                if (style.is("Pop")) s *= f < 0.15f ? Anim.easeOutBack(f / 0.15f) : 1f;
                if (scaleDist.on()) s *= Math.max(0.6f, Math.min(2.2f, 7f / Math.max(2f, o[2])));
                float a = f < 0.7f ? 1f : 1f - (f - 0.7f) / 0.3f;
                var m = c.getMatrices();
                m.pushMatrix(); m.translate(o[0], o[1]); m.scale(s, s);
                int w = Render2D.tw(p.text);
                if (shadow.on()) Render2D.textS(c, p.text, -w / 2f, -4, ColorUtil.alphaMul(p.color | 0xFF000000, a));
                else Render2D.text(c, p.text, -w / 2f, -4, ColorUtil.alphaMul(p.color | 0xFF000000, a));
                m.popMatrix();
            }
        }

        @Override public void onDisable() { pops.clear(); hp.clear(); }
    }

    // =====================================================================================================
    public static final class HitParticles extends Module {
        static final String[] KINDS = {"Hearts", "Stars", "Sparks", "Lightning", "Crits", "Flames", "Souls", "Totem", "Colored Dust"};
        final Setting.Multi kinds = add(new Setting.Multi("Particles", KINDS, "Hearts", "Sparks"));
        final Setting.Num amount = add(new Setting.Num("Amount", 8, 1, 40, 1));
        final Setting.Num spread = add(new Setting.Num("Spread", 0.5, 0.1, 2, 0.05));
        final Setting.Num speed = add(new Setting.Num("Speed", 0.12, 0.0, 0.6, 0.01));
        final Setting.Num height = add(new Setting.Num("Height (of body)", 0.6, 0, 1, 0.05));
        final Setting.Color dust = add(new Setting.Color("Dust Colour", 0xB48CFF, 0x7C9CFF, 255).mode("Gradient"));
        final Setting.Num dustSize = add(new Setting.Num("Dust Size", 1.0, 0.4, 3, 0.1));
        final Setting.Bool onPop = add(new Setting.Bool("Also On Totem Pop", true));
        final Setting.Bool onlyPlayers = add(new Setting.Bool("Only Players", false));
        final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore Friends", true));
        private final List<LivingEntity> pending = new ArrayList<>();
        private final Random rnd = new Random();
        private final Consumer<Entity> hit = e -> { if (e instanceof LivingEntity le && !pending.contains(le)) pending.add(le); };
        private final Consumer<Entity> pop = e -> { if (onPop.on() && e instanceof LivingEntity le) burst(le, 3); };

        public HitParticles() { super("HitParticles", "Custom particles when you hit something (hearts, stars, sparks, lightning...)", Category.VISUALS); }

        @Override public void onEnable() { Pulse.hitListeners.add(hit); Pulse.popListeners.add(pop); }
        @Override public void onDisable() { Pulse.hitListeners.remove(hit); Pulse.popListeners.remove(pop); pending.clear(); }

        @Override public void onTick() {
            for (Iterator<LivingEntity> it = pending.iterator(); it.hasNext(); ) {
                LivingEntity e = it.next();
                if (e.hurtTime > 0) { it.remove(); burst(e, 1); }
                else if (e.age % 20 == 0 || !e.isAlive()) it.remove();
            }
        }

        private void put(ParticleEffect fx, double x, double y, double z, double vx, double vy, double vz) {
            Pulse.mc.particleManager.addParticle(fx, x, y, z, vx, vy, vz);
        }

        private void burst(LivingEntity e, int mult) {
            if (Pulse.mc.world == null || onlyPlayers.on() && !(e instanceof PlayerEntity) || friendSkip(e, ignoreFriends)) return;
            double cy = e.getY() + e.getHeight() * height.d();
            int n = amount.i() * mult;
            double sp = spread.d(), v = speed.d();
            for (String k : kinds.value) {
                for (int i = 0; i < n; i++) {
                    double x = e.getX() + (rnd.nextDouble() - 0.5) * sp, y = cy + (rnd.nextDouble() - 0.5) * sp * 0.8, z = e.getZ() + (rnd.nextDouble() - 0.5) * sp;
                    double vx = (rnd.nextDouble() - 0.5) * v * 2, vy = rnd.nextDouble() * v * 1.4, vz = (rnd.nextDouble() - 0.5) * v * 2;
                    switch (k) {
                        case "Hearts" -> { if (i < Math.max(2, n / 2)) put(ParticleTypes.HEART, x, y, z, 0, 0.05, 0); }
                        case "Stars" -> put(ParticleTypes.END_ROD, x, y, z, vx, vy, vz);
                        case "Sparks" -> put(ParticleTypes.ELECTRIC_SPARK, x, y, z, vx * 3, vy * 3, vz * 3);
                        case "Lightning" -> { if (i % 2 == 0) put(ParticleTypes.ELECTRIC_SPARK, e.getX() + (rnd.nextDouble() - 0.5) * 0.3, e.getY() + i * (e.getHeight() / n), e.getZ() + (rnd.nextDouble() - 0.5) * 0.3, 0, 0.02, 0); else put(ParticleTypes.FIREWORK, x, y, z, vx, vy, vz); }
                        case "Crits" -> put(ParticleTypes.CRIT, x, y, z, vx * 3, vy * 3, vz * 3);
                        case "Flames" -> put(ParticleTypes.FLAME, x, y, z, vx * 0.5, vy, vz * 0.5);
                        case "Souls" -> put(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, vx * 0.4, vy, vz * 0.4);
                        case "Totem" -> put(ParticleTypes.TOTEM_OF_UNDYING, x, y, z, vx * 4, vy * 4, vz * 4);
                        case "Colored Dust" -> put(new DustParticleEffect(dust.get(i / (float) n) & 0xFFFFFF, dustSize.f()), x, y, z, vx, vy, vz);
                        default -> {}
                    }
                }
            }
        }
    }

    // =====================================================================================================
    public static final class ChinaHat extends Module {
        final Setting.Multi who = add(new Setting.Multi("Render On", new String[]{"Self", "Friends", "Other Players"}, "Self"));
        final Setting.Bool firstPerson = add(new Setting.Bool("Show In First Person", false));
        final Setting.Num radius = add(new Setting.Num("Radius", 0.55, 0.2, 1.2, 0.01));
        final Setting.Num height = add(new Setting.Num("Height", 0.32, 0.1, 0.9, 0.01));
        final Setting.Num lift = add(new Setting.Num("Height Offset", 0.0, -0.4, 0.6, 0.01));
        final Setting.Num segments = add(new Setting.Num("Segments", 36, 8, 90, 2));
        final Setting.Num rim = add(new Setting.Num("Rim Thickness", 0.025, 0.0, 0.1, 0.005));
        final Setting.Color color = add(new Setting.Color("Colour", 0x7C9CFF, 0xB48CFF, 0xB0).mode("Theme"));
        final Setting.Color rimCol = add(new Setting.Color("Rim Colour", 0xFFFFFF, 0xE0));
        final Setting.Bool spin = add(new Setting.Bool("Rotate Gradient", true));
        final Setting.Num spinSpeed = add(new Setting.Num("Rotation Speed", 0.4, 0.05, 3, 0.05));

        public ChinaHat() { super("ChinaHat", "3D cone hat over player heads", Category.VISUALS); }

        @Override public void onWorld(float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) return;
            for (PlayerEntity p : m.world.getPlayers()) {
                boolean self = p == m.player, fr = Friends.is(p);
                if (self ? (!who.has("Self") || (m.options.getPerspective().isFirstPerson() && !firstPerson.on())) : fr ? !who.has("Friends") : !who.has("Other Players")) continue;
                if (p.isInvisible() || p.isSpectator()) continue;
                Vec3d pos = p.getLerpedPos(td);
                double y = pos.y + p.getHeight() + lift.d() - (p.isSneaking() ? 0.0 : 0.0);
                int segs = segments.i();
                float off = spin.on() ? Anim.time() * spinSpeed.f() : 0f;
                java.util.function.IntUnaryOperator ci = i -> fr && Modules.FRIENDS != null && Modules.FRIENDS.highlight.on() && Modules.FRIENDS.enabled ? Modules.FRIENDS.color.get(i / (float) segs + off) : color.get(i / (float) segs + off);
                WorldRender.cone(pos.x, y, pos.z, radius.d(), height.d(), segs, ci, ColorUtil.alphaMul(ci.applyAsInt(0), 0.85f));
                if (rim.d() > 0.001) WorldRender.ringH(pos.x, y, pos.z, radius.d(), rim.d(), segs, i -> rimCol.get(i / (float) segs + off));
            }
        }
    }

    // =====================================================================================================
    public static final class Halo extends Module {
        final Setting.Multi who = add(new Setting.Multi("Render On", new String[]{"Self", "Friends", "Other Players"}, "Self"));
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Ring", "Ring", "Double Ring", "Orbiting Orbs", "Crown"));
        final Setting.Bool firstPerson = add(new Setting.Bool("Show In First Person", false));
        final Setting.Num radius = add(new Setting.Num("Radius", 0.32, 0.15, 0.8, 0.01));
        final Setting.Num lift = add(new Setting.Num("Height Above Head", 0.28, 0.05, 0.9, 0.01));
        final Setting.Num thick = add(new Setting.Num("Thickness", 0.045, 0.01, 0.15, 0.005));
        final Setting.Num tilt = add(new Setting.Num("Float Amplitude", 0.03, 0, 0.15, 0.005));
        final Setting.Num spinSpeed = add(new Setting.Num("Rotation Speed", 0.6, 0.05, 4, 0.05));
        final Setting.Color color = add(new Setting.Color("Colour", 0xF0D890, 0xFFB86B, 0xE0).mode("Gradient"));
        final Setting.Bool glow = add(new Setting.Bool("Glow Layer", true));

        public Halo() { super("Halo", "Floating glowing halo above players", Category.VISUALS); }

        @Override public void onWorld(float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) return;
            float t = Anim.time() * spinSpeed.f();
            for (PlayerEntity p : m.world.getPlayers()) {
                boolean self = p == m.player, fr = Friends.is(p);
                if (self ? (!who.has("Self") || (m.options.getPerspective().isFirstPerson() && !firstPerson.on())) : fr ? !who.has("Friends") : !who.has("Other Players")) continue;
                if (p.isInvisible() || p.isSpectator()) continue;
                Vec3d pos = p.getLerpedPos(td);
                double y = pos.y + p.getHeight() + lift.d() + Math.sin(Anim.time() * 2) * tilt.d();
                double r = radius.d();
                final int segs = 40;
                java.util.function.IntUnaryOperator ci = i -> colorFor(p, color, i / (float) segs + t * 0.2f);
                switch (mode.get()) {
                    case "Orbiting Orbs" -> {
                        for (int i = 0; i < 6; i++) {
                            double a = t * 2 + i * Math.PI / 3;
                            WorldRender.orb(pos.x + Math.cos(a) * r, y + Math.sin(t * 3 + i) * 0.03, pos.z + Math.sin(a) * r, 0.1, ci.applyAsInt(i * 6));
                        }
                    }
                    case "Crown" -> {
                        for (int i = 0; i < 8; i++) {
                            double a = i * Math.PI / 4 + t * 0.5;
                            double x = pos.x + Math.cos(a) * r, z = pos.z + Math.sin(a) * r;
                            WorldRender.line(x, y, z, x, y + 0.16, z, thick.d(), ci.applyAsInt(i * 5));
                            WorldRender.orb(x, y + 0.18, z, 0.06, ci.applyAsInt(i * 5));
                        }
                        WorldRender.ringH(pos.x, y, pos.z, r, thick.d(), segs, ci);
                    }
                    default -> {
                        WorldRender.ringH(pos.x, y, pos.z, r, thick.d(), segs, ci);
                        if (glow.on()) WorldRender.ringH(pos.x, y, pos.z, r + thick.d() * 1.2, thick.d() * 3.2, segs, i -> ColorUtil.alphaMul(ci.applyAsInt(i), 0.22f));
                        if (mode.is("Double Ring")) WorldRender.ringH(pos.x, y + 0.07, pos.z, r * 0.75, thick.d() * 0.8, segs, i -> ColorUtil.alphaMul(ci.applyAsInt((i + 20) % segs), 0.8f));
                    }
                }
            }
        }
    }

    // =====================================================================================================
    public static final class NameTags extends Module {
        public final Setting.Mode style = add(new Setting.Mode("Style", "Rounded", "Rounded", "Flat", "Minimal", "Outline"));
        public final Setting.Bool hideVanilla = add(new Setting.Bool("Hide Vanilla Nametag", true));
        final Setting.Bool health = add(new Setting.Bool("Health", true));
        final Setting.Mode healthMode = add(new Setting.Mode("Health Format", "Hearts", "Hearts", "Number", "Percent"));
        final Setting.Bool healthBar = add(new Setting.Bool("Health Bar", true));
        final Setting.Bool armor = add(new Setting.Bool("Armor", true));
        final Setting.Bool durability = add(new Setting.Bool("Armor Durability", true));
        final Setting.Bool enchants = add(new Setting.Bool("Enchantments", true));
        final Setting.Bool hand = add(new Setting.Bool("Held Item", true));
        final Setting.Bool ping = add(new Setting.Bool("Ping", true));
        final Setting.Bool distance = add(new Setting.Bool("Distance", false));
        final Setting.Bool friendTag = add(new Setting.Bool("Friend Badge", true));
        final Setting.Bool self = add(new Setting.Bool("Show Self (3rd person)", false));
        final Setting.Bool scaleDist = add(new Setting.Bool("Scale With Distance", true));
        final Setting.Num scale = add(new Setting.Num("Scale", 1.0, 0.5, 2.5, 0.05));
        final Setting.Num range = add(new Setting.Num("Range", 64, 8, 160, 4));
        final Setting.Num yOff = add(new Setting.Num("Vertical Offset", 0.35, 0, 1.5, 0.05));
        final Setting.Color bg = add(new Setting.Color("Background", 0x0A0C12, 0xA8));
        final Setting.Color nameCol = add(new Setting.Color("Name Colour", 0xE8EAF2, 255));

        public NameTags() { super("NameTags", "Rich player tags: HP, armor, enchants, ping, friend status", Category.VISUALS); }

        private static String abbr(RegistryEntry<Enchantment> en, int lvl) {
            String id = en.getKey().map(k -> k.getValue().getPath()).orElse("??");
            String a = switch (id) {
                case "protection" -> "Pr"; case "sharpness" -> "Sh"; case "unbreaking" -> "Un"; case "mending" -> "Me";
                case "fire_protection" -> "FP"; case "blast_protection" -> "BP"; case "projectile_protection" -> "PP";
                case "thorns" -> "Th"; case "feather_falling" -> "FF"; case "efficiency" -> "Ef"; case "power" -> "Pw";
                case "knockback" -> "Kb"; case "fire_aspect" -> "FA"; case "looting" -> "Lo"; case "density" -> "De";
                case "breach" -> "Br"; case "wind_burst" -> "WB"; case "swift_sneak" -> "SS"; default -> id.length() > 1 ? id.substring(0, 2) : id;
            };
            return a + lvl;
        }

        private static String enchText(ItemStack st) {
            ItemEnchantmentsComponent ench = st.getOrDefault(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
            if (ench.isEmpty()) return "";
            StringBuilder sb = new StringBuilder();
            int n = 0;
            for (Object2IntMap.Entry<RegistryEntry<Enchantment>> en : ench.getEnchantmentEntries()) {
                if (n++ >= 3) break;
                if (sb.length() > 0) sb.append(' ');
                sb.append(abbr(en.getKey(), en.getIntValue()));
            }
            return sb.toString();
        }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) return;
            List<PlayerEntity> list = new ArrayList<>();
            for (PlayerEntity p : m.world.getPlayers()) {
                if (p == m.player && (!self.on() || m.options.getPerspective().isFirstPerson())) continue;
                if (p.isInvisible() && !p.isSneaking() && false) continue;
                if (m.player.distanceTo(p) > range.d()) continue;
                list.add(p);
            }
            list.sort((a, b) -> Float.compare(m.player.distanceTo(b), m.player.distanceTo(a)));
            float[] o = new float[3];
            for (PlayerEntity p : list) {
                Vec3d pos = p.getLerpedPos(td);
                if (!Proj.project(pos.x, pos.y + p.getHeight() + yOff.d(), pos.z, o)) continue;
                float dist = m.player.distanceTo(p);
                float s = scale.f() * (scaleDist.on() ? Math.max(0.55f, Math.min(1.6f, 9f / Math.max(3f, dist))) : 1f);
                drawTag(c, p, o[0], o[1], s, dist);
            }
        }

        private void drawTag(DrawContext c, PlayerEntity p, float x, float y, float s, float dist) {
            var m = Pulse.mc;
            boolean fr = Friends.is(p);
            String name = p.getName().getString();
            List<String> parts = new ArrayList<>();
            if (friendTag.on() && fr) name = "\u2605 " + name;
            String hp = "";
            float max = Math.max(1f, p.getMaxHealth()), cur = p.getHealth() + p.getAbsorptionAmount();
            if (health.on()) hp = switch (healthMode.get()) {
                case "Number" -> String.format(Locale.ROOT, "%.1f", cur);
                case "Percent" -> Math.round(cur / max * 100) + "%";
                default -> String.format(Locale.ROOT, "%.1f\u2764", cur / 2f);
            };
            String extra = "";
            if (ping.on() && m.getNetworkHandler() != null) { PlayerListEntry e = m.getNetworkHandler().getPlayerListEntry(p.getUuid()); if (e != null) extra += e.getLatency() + "ms "; }
            if (distance.on()) extra += String.format(Locale.ROOT, "%.0fm", dist);
            extra = extra.trim();
            var mx = c.getMatrices();
            mx.pushMatrix(); mx.translate(x, y); mx.scale(s, s);
            int nc = fr ? (Modules.FRIENDS != null ? Modules.FRIENDS.color.get() : 0xFF6EDC9A) : nameCol.get();
            float line = name.length() > 0 ? Render2D.tw(name) : 0;
            float W = line + (hp.isEmpty() ? 0 : Render2D.tw(hp) + 6) + (extra.isEmpty() ? 0 : Render2D.tw(extra) + 6) + 10;
            float H = 13;
            float bx = -W / 2f, by = -H - (armor.on() ? 22 : 2);
            // armor row above the tag
            if (armor.on()) {
                List<ItemStack> items = new ArrayList<>();
                if (hand.on()) items.add(p.getMainHandStack());
                for (EquipmentSlot sl : HudModules.ARMOR) items.add(p.getEquippedStack(sl));
                if (hand.on()) items.add(p.getOffHandStack());
                items.removeIf(ItemStack::isEmpty);
                float iw = 17, start = -items.size() * iw / 2f;
                for (int i = 0; i < items.size(); i++) {
                    ItemStack st = items.get(i);
                    float ix = start + i * iw, iy = by - 17;
                    Render2D.item(c, st, ix, iy, 0.85f, false);
                    if (durability.on() && st.isDamageable()) Render2D.textC(c, HudModules.durPercent(st) + "", ix + 7, iy + 12, ColorUtil.health(HudModules.durPercent(st) / 100f), true);
                    if (enchants.on()) { String et = enchText(st); if (!et.isEmpty()) Render2D.textScaled(c, et, ix + 7 - Render2D.tw(et) * 0.25f, iy - 6, 0.5f, 0xFFB8F0FF, true); }
                    if (st.getCount() > 1) Render2D.textScaled(c, "" + st.getCount(), ix + 9, iy + 9, 0.6f, 0xFFFFFFFF, true);
                }
                by += 0;
            }
            String st = style.get();
            if (!st.equals("Minimal")) {
                if (st.equals("Flat")) Render2D.rect(c, bx, by, W, H, bg.get());
                else Render2D.rrect(c, bx, by, W, H, 4, bg.get());
                if (st.equals("Outline")) Render2D.outline(c, bx, by, W, H, 4, ColorUtil.alphaMul(nc, 0.8f));
            }
            Render2D.textS(c, name, bx + 5, by + 3, nc);
            float tx = bx + 5 + line + 6;
            if (!hp.isEmpty()) { Render2D.textS(c, hp, tx, by + 3, ColorUtil.health(cur / max)); tx += Render2D.tw(hp) + 6; }
            if (!extra.isEmpty()) Render2D.textS(c, extra, tx, by + 3, ThemeManager.cur().dim);
            if (healthBar.on() && !st.equals("Minimal")) {
                Render2D.rect(c, bx + 2, by + H - 1, W - 4, 1, 0x66000000);
                Render2D.rect(c, bx + 2, by + H - 1, (W - 4) * Anim.clamp01(cur / max), 1, ColorUtil.health(cur / max));
            }
            mx.popMatrix();
        }
    }

    // =====================================================================================================
    public static final class Tracers extends Module {
        final Setting.Mode origin = add(new Setting.Mode("Origin", "Bottom Center", "Crosshair", "Bottom Center", "Top Center"));
        final Setting.Mode point = add(new Setting.Mode("Target Point", "Body", "Feet", "Body", "Head"));
        final Setting.Mode colorMode = add(new Setting.Mode("Colour By", "Distance", "Static", "Distance", "Health"));
        final Setting.Multi types = add(new Setting.Multi("Targets", TYPES, "Players"));
        final Setting.Color color = add(new Setting.Color("Colour", 0x7C9CFF, 0xB48CFF, 0xCC).mode("Theme"));
        final Setting.Num thick = add(new Setting.Num("Thickness", 1.0, 0.5, 4, 0.25));
        final Setting.Num range = add(new Setting.Num("Max Distance", 80, 10, 200, 5));
        final Setting.Bool fade = add(new Setting.Bool("Fade With Distance", true));
        final Setting.Bool dot = add(new Setting.Bool("End Dot", true));
        final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore Friends", false));

        public Tracers() { super("Tracers", "Screen-space lines to nearby entities", Category.VISUALS); }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null || m.currentScreen != null) return;
            int sw = m.getWindow().getScaledWidth(), sh = m.getWindow().getScaledHeight();
            float ox = sw / 2f, oy = switch (origin.get()) { case "Crosshair" -> sh / 2f; case "Top Center" -> 0f; default -> (float) sh; };
            float[] o = new float[3];
            for (Entity e : m.world.getEntities()) {
                if (e == m.player || !typeOk(e, types) || friendSkip(e, ignoreFriends)) continue;
                float d = m.player.distanceTo(e);
                if (d > range.d()) continue;
                Vec3d p = e.getLerpedPos(td);
                double py = switch (point.get()) { case "Feet" -> p.y; case "Head" -> p.y + e.getHeight(); default -> p.y + e.getHeight() / 2; };
                if (!Proj.project(p.x, py, p.z, o)) continue;
                int col;
                float frac = e instanceof LivingEntity le ? le.getHealth() / Math.max(1f, le.getMaxHealth()) : 1f;
                switch (colorMode.get()) {
                    case "Distance" -> col = ColorUtil.withAlpha(ColorUtil.lerp(0xFFE5707A, 0xFF6EDC9A, Anim.clamp01(d / 40f)), color.alpha);
                    case "Health" -> col = ColorUtil.withAlpha(ColorUtil.health(frac), color.alpha);
                    default -> col = color.get(d * 0.02f);
                }
                col = friendOr(e, col);
                if (fade.on()) col = ColorUtil.alphaMul(col, 1f - 0.65f * Anim.clamp01(d / (float) range.d()));
                Render2D.line(c, ox, oy, o[0], o[1], thick.f(), col);
                if (dot.on()) Render2D.circle(c, o[0], o[1], 2.2f, col);
            }
        }
    }

    // =====================================================================================================
    public static final class Arrows extends Module {
        final Setting.Mode style = add(new Setting.Mode("Style", "Triangle", "Triangle", "Chevron", "Dot"));
        final Setting.Mode colorMode = add(new Setting.Mode("Colour By", "Distance", "Static", "Distance", "Health"));
        final Setting.Multi types = add(new Setting.Multi("Targets", TYPES, "Players"));
        final Setting.Num radius = add(new Setting.Num("Radius", 70, 30, 200, 2));
        final Setting.Num size = add(new Setting.Num("Size", 9, 4, 20, 1));
        final Setting.Num range = add(new Setting.Num("Max Distance", 60, 10, 200, 5));
        final Setting.Color color = add(new Setting.Color("Colour", 0x7C9CFF, 0xB48CFF, 0xDD).mode("Theme"));
        final Setting.Bool onlyOff = add(new Setting.Bool("Only Off-Screen", true));
        final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
        final Setting.Bool pulse = add(new Setting.Bool("Pulse When Close", true));
        final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore Friends", false));

        public Arrows() { super("Arrows", "Edge arrows pointing to players outside your view", Category.VISUALS); }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null || m.currentScreen != null) return;
            float cx = m.getWindow().getScaledWidth() / 2f, cy = m.getWindow().getScaledHeight() / 2f;
            float[] o = new float[3];
            for (Entity e : m.world.getEntities()) {
                if (e == m.player || !typeOk(e, types) || friendSkip(e, ignoreFriends)) continue;
                float d = m.player.distanceTo(e);
                if (d > range.d()) continue;
                Vec3d p = e.getLerpedPos(td);
                boolean vis = Proj.project(p.x, p.y + e.getHeight() / 2, p.z, o) && Proj.onScreen(o[0], o[1], 0);
                if (onlyOff.on() && vis) continue;
                float ang = Proj.dirAngle(p.x, p.y + e.getHeight() / 2, p.z);
                float sa = -ang; // screen space: y is down
                float frac = e instanceof LivingEntity le ? le.getHealth() / Math.max(1f, le.getMaxHealth()) : 1f;
                int col = switch (colorMode.get()) {
                    case "Distance" -> ColorUtil.withAlpha(ColorUtil.lerp(0xFFE5707A, 0xFF6EDC9A, Anim.clamp01(d / 30f)), color.alpha);
                    case "Health" -> ColorUtil.withAlpha(ColorUtil.health(frac), color.alpha);
                    default -> color.get(d * 0.02f);
                };
                col = friendOr(e, col);
                float R = radius.f() + (pulse.on() && d < 12 ? (float) Math.sin(Anim.time() * 8) * 3f : 0f);
                float x = cx + (float) Math.cos(sa) * R, y = cy + (float) Math.sin(sa) * R;
                float S = size.f();
                switch (style.get()) {
                    case "Dot" -> Render2D.circle(c, x, y, S * 0.5f, col);
                    case "Chevron" -> { Render2D.line(c, x - (float) Math.cos(sa) * S * 0.4f + (float) Math.sin(sa) * S * 0.5f, y - (float) Math.sin(sa) * S * 0.4f - (float) Math.cos(sa) * S * 0.5f, x + (float) Math.cos(sa) * S * 0.5f, y + (float) Math.sin(sa) * S * 0.5f, 1.6f, col);
                        Render2D.line(c, x - (float) Math.cos(sa) * S * 0.4f - (float) Math.sin(sa) * S * 0.5f, y - (float) Math.sin(sa) * S * 0.4f + (float) Math.cos(sa) * S * 0.5f, x + (float) Math.cos(sa) * S * 0.5f, y + (float) Math.sin(sa) * S * 0.5f, 1.6f, col); }
                    default -> Render2D.triangle(c, x - (float) Math.cos(sa) * S * 0.5f, y - (float) Math.sin(sa) * S * 0.5f, sa, S, S * 0.55f, col);
                }
                if (showDist.on()) Render2D.textC(c, Math.round(d) + "m", x - (float) Math.cos(sa) * (S + 7), y - (float) Math.sin(sa) * (S + 7) - 4, ColorUtil.alphaMul(0xFFFFFFFF, (col >>> 24) / 255f), true);
            }
        }
    }

    // =====================================================================================================
    public static final class ItemESP extends Module {
        static final String[] FILTERS = {"All Items", "Diamond / Netherite", "Enchanted", "Totems", "Shulker Boxes", "Golden Apples", "Pearls"};
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Corners", "Box", "Corners", "Marker", "Filled Box"));
        final Setting.Multi filter = add(new Setting.Multi("Highlight", FILTERS, "All Items"));
        final Setting.Bool label = add(new Setting.Bool("Name Label", true));
        final Setting.Bool count = add(new Setting.Bool("Count", true));
        final Setting.Bool distance = add(new Setting.Bool("Distance", true));
        final Setting.Bool rarity = add(new Setting.Bool("Colour By Rarity", false));
        final Setting.Num range = add(new Setting.Num("Range", 40, 5, 128, 1));
        final Setting.Num thick = add(new Setting.Num("Line Width", 1.0, 0.5, 3, 0.5));
        final Setting.Color color = add(new Setting.Color("Colour", 0xF0D070, 0xFFB86B, 0xE0).mode("Gradient"));

        public ItemESP() { super("ItemESP", "Highlight dropped items (corners / boxes / markers, filters, labels)", Category.VISUALS); }

        private boolean pass(ItemStack st) {
            if (filter.has("All Items")) return true;
            String id = Registries.ITEM.getId(st.getItem()).getPath();
            if (filter.has("Diamond / Netherite") && (id.contains("diamond") || id.contains("netherite"))) return true;
            if (filter.has("Enchanted") && st.hasEnchantments()) return true;
            if (filter.has("Totems") && id.equals("totem_of_undying")) return true;
            if (filter.has("Shulker Boxes") && id.endsWith("shulker_box")) return true;
            if (filter.has("Golden Apples") && id.contains("golden_apple")) return true;
            return filter.has("Pearls") && id.equals("ender_pearl");
        }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null || m.currentScreen != null) return;
            float[] o = new float[3];
            int idx = 0;
            for (Entity e : m.world.getEntities()) {
                if (!(e instanceof ItemEntity ie)) continue;
                if (m.player.distanceTo(e) > range.d() || !pass(ie.getStack())) continue;
                Vec3d p = e.getLerpedPos(td);
                Box b = e.getBoundingBox().offset(p.subtract(e.getX(), e.getY(), e.getZ())).expand(0.05);
                float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f; boolean ok = true;
                for (int i = 0; i < 8 && ok; i++) {
                    if (!Proj.project((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ, o)) { ok = false; break; }
                    minX = Math.min(minX, o[0]); maxX = Math.max(maxX, o[0]); minY = Math.min(minY, o[1]); maxY = Math.max(maxY, o[1]);
                }
                if (!ok) continue;
                int col = color.get(idx++ * 0.1f);
                if (rarity.on()) col = switch (ie.getStack().getRarity()) { case UNCOMMON -> 0xFFF0E070; case RARE -> 0xFF70C8F0; case EPIC -> 0xFFD090F0; default -> col; };
                float w = Math.max(6, maxX - minX), h = Math.max(6, maxY - minY), cx = (minX + maxX) / 2f, cy = (minY + maxY) / 2f;
                float x1 = cx - w / 2f, y1 = cy - h / 2f, t = thick.f();
                switch (mode.get()) {
                    case "Box", "Filled Box" -> {
                        if (mode.is("Filled Box")) Render2D.rect(c, x1, y1, w, h, ColorUtil.alphaMul(col, 0.18f));
                        Render2D.rect(c, x1, y1, w, t, col); Render2D.rect(c, x1, y1 + h - t, w, t, col);
                        Render2D.rect(c, x1, y1, t, h, col); Render2D.rect(c, x1 + w - t, y1, t, h, col);
                    }
                    case "Marker" -> Render2D.triangle(c, cx, y1 - 10, (float) Math.PI / 2, 7, 4, col);
                    default -> {
                        float l = Math.min(w, h) / 3f + 1;
                        Render2D.rect(c, x1, y1, l, t, col); Render2D.rect(c, x1, y1, t, l, col);
                        Render2D.rect(c, x1 + w - l, y1, l, t, col); Render2D.rect(c, x1 + w - t, y1, t, l, col);
                        Render2D.rect(c, x1, y1 + h - t, l, t, col); Render2D.rect(c, x1, y1 + h - l, t, l, col);
                        Render2D.rect(c, x1 + w - l, y1 + h - t, l, t, col); Render2D.rect(c, x1 + w - t, y1 + h - l, t, l, col);
                    }
                }
                if (label.on()) {
                    String s = ie.getStack().getName().getString() + (count.on() && ie.getStack().getCount() > 1 ? " x" + ie.getStack().getCount() : "") + (distance.on() ? String.format(Locale.ROOT, " %.0fm", m.player.distanceTo(e)) : "");
                    Render2D.textC(c, s, cx, y1 + h + 3, 0xFFFFFFFF, true);
                }
            }
        }
    }

    // =====================================================================================================
    public static final class Hitboxes extends Module {
        final Setting.Multi types = add(new Setting.Multi("Targets", new String[]{"Players", "Hostile", "Passive", "Other Living"}, "Players", "Hostile"));
        final Setting.Mode colorMode = add(new Setting.Mode("Colour By", "Static", "Static", "Health", "Distance"));
        final Setting.Color color = add(new Setting.Color("Outline Colour", 0x7C9CFF, 0xB48CFF, 0xE0).mode("Theme"));
        final Setting.Color fill = add(new Setting.Color("Fill Colour", 0x7C9CFF, 0x30).mode("Static"));
        final Setting.Bool fillOn = add(new Setting.Bool("Fill", true));
        final Setting.Bool eyeLine = add(new Setting.Bool("Look Direction Line", true));
        final Setting.Bool onlyTarget = add(new Setting.Bool("Only Current Target", false));
        final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore Friends", false));
        final Setting.Num width = add(new Setting.Num("Line Width", 0.02, 0.005, 0.08, 0.005));
        final Setting.Num expand = add(new Setting.Num("Expand", 0.0, -0.1, 0.5, 0.01));
        final Setting.Num range = add(new Setting.Num("Range", 40, 5, 128, 1));

        public Hitboxes() { super("Hitboxes", "Custom hitbox rendering (outline, fill, look line)", Category.VISUALS); }

        @Override public void onWorld(float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) return;
            int idx = 0;
            for (Entity e : m.world.getEntities()) {
                if (e == m.player || !typeOk(e, types) || friendSkip(e, ignoreFriends)) continue;
                if (onlyTarget.on() && e != Pulse.target && e != m.targetedEntity) continue;
                float d = m.player.distanceTo(e);
                if (d > range.d()) continue;
                Vec3d p = e.getLerpedPos(td);
                Box b = e.getBoundingBox().offset(p.subtract(e.getX(), e.getY(), e.getZ())).expand(expand.d());
                int oc, fc;
                float frac = e instanceof LivingEntity le ? le.getHealth() / Math.max(1f, le.getMaxHealth()) : 1f;
                switch (colorMode.get()) {
                    case "Health" -> { oc = ColorUtil.withAlpha(ColorUtil.health(frac), color.alpha); fc = ColorUtil.withAlpha(ColorUtil.health(frac), fill.alpha); }
                    case "Distance" -> { int cc = ColorUtil.lerp(0xFFE5707A, 0xFF6EDC9A, Anim.clamp01(d / 30f)); oc = ColorUtil.withAlpha(cc, color.alpha); fc = ColorUtil.withAlpha(cc, fill.alpha); }
                    default -> { oc = color.get(idx * 0.07f); fc = fill.get(); }
                }
                if (Friends.is(e) && Modules.FRIENDS != null && Modules.FRIENDS.enabled && Modules.FRIENDS.highlight.on()) { oc = Modules.FRIENDS.color.get(); fc = ColorUtil.withAlpha(oc, fill.alpha); }
                if (fillOn.on()) WorldRender.boxFill(b, fc);
                WorldRender.boxLines(b, width.d(), oc);
                if (eyeLine.on() && e instanceof LivingEntity le) {
                    Vec3d eye = new Vec3d(p.x, p.y + le.getStandingEyeHeight(), p.z), look = le.getRotationVec(td);
                    WorldRender.line(eye.x, eye.y, eye.z, eye.x + look.x * 2, eye.y + look.y * 2, eye.z + look.z * 2, width.d(), ColorUtil.withAlpha(0xFF5A5A, 0xE0));
                }
                idx++;
            }
        }
    }

    // =====================================================================================================
    public static final class ShulkerPreview extends Module {
        final Setting.Bind holdKey = add(new Setting.Bind("Hold Key (None = always)", GLFW.GLFW_KEY_LEFT_SHIFT));
        final Setting.Bool tinted = add(new Setting.Bool("Tint By Box Colour", true));
        final Setting.Bool counts = add(new Setting.Bool("Stack Counts", true));
        final Setting.Bool title = add(new Setting.Bool("Title", true));
        final Setting.Num slot = add(new Setting.Num("Slot Size", 18, 14, 24, 1));
        final Setting.Color bg = add(new Setting.Color("Background", 0x0E1118, 0xE0));

        public ShulkerPreview() { super("ShulkerPreview", "Peek inside shulker boxes by hovering them in any inventory", Category.VISUALS); }

        public void render(DrawContext c, HandledScreen<?> scr, ItemStack st, int mx, int my) {
            if (!enabled || st == null || st.isEmpty()) return;
            String id = Registries.ITEM.getId(st.getItem()).getPath();
            if (!id.endsWith("shulker_box")) return;
            if (holdKey.isSet() && GLFW.glfwGetKey(Pulse.mc.getWindow().getHandle(), holdKey.get()) != GLFW.GLFW_PRESS) return;
            ContainerComponent cc = st.get(DataComponentTypes.CONTAINER);
            if (cc == null) return;
            List<ItemStack> items = cc.stream().toList();
            float S = slot.f();
            float W = 9 * S + 8, H = 3 * S + 8 + (title.on() ? 12 : 0);
            int sw = Pulse.mc.getWindow().getScaledWidth(), sh = Pulse.mc.getWindow().getScaledHeight();
            float x = Math.min(sw - W - 2, mx + 12), y = Math.min(sh - H - 2, Math.max(2, my - H - 6));
            var m = c.getMatrices();
            m.pushMatrix(); m.translate(0, 0);
            int tint = 0x7C9CFF;
            if (tinted.on()) { int h = id.hashCode(); tint = 0x606060 | (h & 0x9F9F9F); }
            Render2D.glow(c, x, y, W, H, 6, 0x80000000, 4);
            Render2D.rrect(c, x, y, W, H, 6, bg.get());
            Render2D.rrect(c, x, y, W, 2, 1, ColorUtil.withAlpha(tint, 255));
            if (title.on()) Render2D.text(c, st.getName().getString(), x + 5, y + 5, ThemeManager.cur().dim);
            float top = y + 4 + (title.on() ? 12 : 0);
            for (int i = 0; i < 27; i++) {
                float sx = x + 4 + (i % 9) * S, sy = top + (i / 9) * S;
                Render2D.rrect(c, sx + 1, sy + 1, S - 2, S - 2, 2, 0x18FFFFFF);
                if (i < items.size() && !items.get(i).isEmpty()) {
                    float k = S / 18f;
                    m.pushMatrix(); m.translate(sx + (S - 16 * k) / 2f, sy + (S - 16 * k) / 2f); m.scale(k, k);
                    c.drawItem(items.get(i), 0, 0);
                    if (counts.on()) c.drawStackOverlay(Render2D.font(), items.get(i), 0, 0);
                    m.popMatrix();
                }
            }
            m.popMatrix();
        }
    }
}
