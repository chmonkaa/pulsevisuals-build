package dev.pulse.modules;

import dev.pulse.Pulse;
import dev.pulse.mixin.SimpleOptionAccessor;
import dev.pulse.module.Category;
import dev.pulse.module.Module;
import dev.pulse.setting.Setting;
import dev.pulse.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.time.LocalTime;
import java.util.*;

/** World & environment modules. */
public final class WorldModules {
    private WorldModules() {}

    // =====================================================================================================
    public static final class BlockOverlay extends Module {
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Outline + Fill", "Outline", "Fill", "Outline + Fill", "Face Only", "Corners"));
        final Setting.Color outline = add(new Setting.Color("Outline Colour", 0x7C9CFF, 0xB48CFF, 0xFF).mode("Theme"));
        final Setting.Color fill = add(new Setting.Color("Fill Colour", 0x7C9CFF, 0xB48CFF, 0x40).mode("Theme"));
        final Setting.Num width = add(new Setting.Num("Line Width", 0.02, 0.005, 0.08, 0.005));
        final Setting.Num expand = add(new Setting.Num("Expand", 0.003, 0.0, 0.1, 0.001));
        final Setting.Bool pulse = add(new Setting.Bool("Pulse", true));
        final Setting.Num pulseSpeed = add(new Setting.Num("Pulse Speed", 2.0, 0.3, 8, 0.1));
        final Setting.Bool gradient = add(new Setting.Bool("Vertical Gradient Fill", true));
        final Setting.Bool smooth = add(new Setting.Bool("Smooth Follow", true));
        final Setting.Num smoothSpeed = add(new Setting.Num("Follow Speed", 18, 4, 40, 1));
        private final double[] cur = new double[6];
        private boolean has;
        private float vis;

        public BlockOverlay() { super("BlockOverlay", "Custom block outline: fill, pulse, gradient, smooth follow", Category.WORLD); }

        @Override public void onWorld(float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) return;
            Box tgt = null; Direction face = Direction.UP;
            if (m.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
                var pos = bhr.getBlockPos();
                var shape = m.world.getBlockState(pos).getOutlineShape(m.world, pos);
                if (!shape.isEmpty()) { tgt = shape.getBoundingBox().offset(pos.getX(), pos.getY(), pos.getZ()); face = bhr.getSide(); }
            }
            vis = Anim.to(vis, tgt != null ? 1f : 0f, 20f);
            if (tgt != null) {
                double[] t = {tgt.minX, tgt.minY, tgt.minZ, tgt.maxX, tgt.maxY, tgt.maxZ};
                if (!has || !smooth.on()) { System.arraycopy(t, 0, cur, 0, 6); has = true; }
                else for (int i = 0; i < 6; i++) cur[i] = Anim.to((float) cur[i], (float) t[i], smoothSpeed.f());
            }
            if (!has || vis < 0.02f) return;
            double e = expand.d();
            double x1 = cur[0] - e, y1 = cur[1] - e, z1 = cur[2] - e, x2 = cur[3] + e, y2 = cur[4] + e, z2 = cur[5] + e;
            float pm = pulse.on() ? 0.65f + 0.35f * (float) Math.sin(Anim.time() * pulseSpeed.f()) : 1f;
            int oc = ColorUtil.alphaMul(outline.get(), vis), fc = ColorUtil.alphaMul(fill.get(0.25f), vis * pm);
            String md = mode.get();
            if (md.equals("Fill") || md.equals("Outline + Fill")) {
                if (gradient.on()) {
                    int top = fc, bot = ColorUtil.alphaMul(fill.get(0.75f), vis * pm * 0.25f);
                    WorldRender.quadC(x1, y1, z1, bot, x2, y1, z1, bot, x2, y2, z1, top, x1, y2, z1, top);
                    WorldRender.quadC(x1, y1, z2, bot, x1, y2, z2, top, x2, y2, z2, top, x2, y1, z2, bot);
                    WorldRender.quadC(x1, y1, z1, bot, x1, y2, z1, top, x1, y2, z2, top, x1, y1, z2, bot);
                    WorldRender.quadC(x2, y1, z1, bot, x2, y1, z2, bot, x2, y2, z2, top, x2, y2, z1, top);
                    WorldRender.quad(x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, top);
                    WorldRender.quad(x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, bot);
                } else WorldRender.boxFill(x1, y1, z1, x2, y2, z2, fc);
            }
            if (md.equals("Face Only")) {
                switch (face) {
                    case UP -> WorldRender.quad(x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, fc);
                    case DOWN -> WorldRender.quad(x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, fc);
                    case NORTH -> WorldRender.quad(x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, fc);
                    case SOUTH -> WorldRender.quad(x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, fc);
                    case WEST -> WorldRender.quad(x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, fc);
                    default -> WorldRender.quad(x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, fc);
                }
            }
            if (md.equals("Corners")) {
                double lx = (x2 - x1) * 0.3, ly = (y2 - y1) * 0.3, lz = (z2 - z1) * 0.3, w = width.d();
                for (int i = 0; i < 8; i++) {
                    double cx = (i & 1) == 0 ? x1 : x2, cy = (i & 2) == 0 ? y1 : y2, cz = (i & 4) == 0 ? z1 : z2;
                    int sx = (i & 1) == 0 ? 1 : -1, sy = (i & 2) == 0 ? 1 : -1, sz = (i & 4) == 0 ? 1 : -1;
                    WorldRender.line(cx, cy, cz, cx + sx * lx, cy, cz, w, oc);
                    WorldRender.line(cx, cy, cz, cx, cy + sy * ly, cz, w, oc);
                    WorldRender.line(cx, cy, cz, cx, cy, cz + sz * lz, w, oc);
                }
            } else if (md.startsWith("Outline")) WorldRender.boxLines(x1, y1, z1, x2, y2, z2, width.d(), oc);
        }
    }

    // =====================================================================================================
    public static final class JumpCircles extends Module {
        final Setting.Mode style = add(new Setting.Mode("Style", "Ring", "Ring", "Double Ring", "Filled Disc", "Pulse Waves"));
        final Setting.Multi who = add(new Setting.Multi("Players", new String[]{"Self", "Friends", "Others"}, "Self"));
        final Setting.Multi when = add(new Setting.Multi("Trigger", new String[]{"Jump", "Landing"}, "Jump"));
        final Setting.Num maxRadius = add(new Setting.Num("Max Radius", 1.6, 0.5, 5, 0.1));
        final Setting.Num life = add(new Setting.Num("Lifetime (s)", 1.1, 0.3, 4, 0.1));
        final Setting.Num thick = add(new Setting.Num("Thickness", 0.12, 0.02, 0.5, 0.01));
        final Setting.Num segments = add(new Setting.Num("Segments", 48, 16, 96, 4));
        final Setting.Color color = add(new Setting.Color("Colour", 0x7C9CFF, 0xB48CFF, 0xC0).mode("Theme"));
        final Setting.Bool fadeIn = add(new Setting.Bool("Ease-Out Expansion", true));
        final Setting.Num max = add(new Setting.Num("Max Circles", 24, 4, 80, 1));

        private static final class Circle { double x, y, z; long born; boolean friend; }
        private final List<Circle> list = new ArrayList<>();
        private final Map<Integer, Boolean> ground = new HashMap<>();

        public JumpCircles() { super("JumpCircles", "Expanding circles under your feet on jump / landing", Category.WORLD); }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) { list.clear(); ground.clear(); return; }
            Set<Integer> seen = new HashSet<>();
            for (PlayerEntity p : m.world.getPlayers()) {
                boolean self = p == m.player, fr = Friends.is(p);
                seen.add(p.getId());
                Boolean was = ground.put(p.getId(), p.isOnGround());
                if (was == null) continue;
                if (!(self ? who.has("Self") : fr ? who.has("Friends") : who.has("Others"))) continue;
                boolean jump = was && !p.isOnGround() && when.has("Jump"), land = !was && p.isOnGround() && when.has("Landing");
                if (jump || land) {
                    Circle c = new Circle(); c.x = p.getX(); c.y = p.getY() + 0.02; c.z = p.getZ(); c.born = System.currentTimeMillis(); c.friend = fr;
                    list.add(c);
                    while (list.size() > max.i()) list.remove(0);
                }
            }
            ground.keySet().retainAll(seen);
        }

        @Override public void onWorld(float td) {
            if (list.isEmpty()) return;
            long now = System.currentTimeMillis();
            int segs = segments.i();
            for (Iterator<Circle> it = list.iterator(); it.hasNext(); ) {
                Circle c = it.next();
                float f = (now - c.born) / (life.f() * 1000f);
                if (f >= 1f) { it.remove(); continue; }
                float k = fadeIn.on() ? Anim.easeOutCubic(f) : f;
                double r = 0.25 + (maxRadius.d() - 0.25) * k;
                float a = 1f - f;
                java.util.function.IntUnaryOperator col = i -> ColorUtil.alphaMul(c.friend && Modules.FRIENDS != null && Modules.FRIENDS.enabled && Modules.FRIENDS.highlight.on() ? Modules.FRIENDS.color.get(i / (float) segs) : color.get(i / (float) segs), a);
                switch (style.get()) {
                    case "Filled Disc" -> { WorldRender.discH(c.x, c.y, c.z, r, segs, ColorUtil.alphaMul(color.get(), a * 0.35f)); WorldRender.ringH(c.x, c.y + 0.003, c.z, r, thick.d() * 0.5, segs, col); }
                    case "Double Ring" -> { WorldRender.ringH(c.x, c.y, c.z, r, thick.d(), segs, col); WorldRender.ringH(c.x, c.y + 0.003, c.z, r * 0.6, thick.d() * 0.7, segs, i -> ColorUtil.alphaMul(col.applyAsInt(i), 0.7f)); }
                    case "Pulse Waves" -> { for (int w = 0; w < 3; w++) { float ff = Math.max(0, f - w * 0.12f); if (ff <= 0) continue; double rr = 0.25 + (maxRadius.d() - 0.25) * Anim.easeOutCubic(ff); final float fa = 1f - ff; WorldRender.ringH(c.x, c.y + 0.002 * w, c.z, rr, thick.d() * 0.6, segs, i -> ColorUtil.alphaMul(col.applyAsInt(i), fa)); } }
                    default -> WorldRender.ringH(c.x, c.y, c.z, r, thick.d(), segs, col);
                }
            }
        }

        @Override public void onDisable() { list.clear(); ground.clear(); }
    }

    // =====================================================================================================
    public static final class Trails extends Module {
        final Setting.Multi sources = add(new Setting.Multi("Sources", new String[]{"Self", "Other Players", "Arrows", "Pearls", "Other Projectiles"}, "Self", "Arrows", "Pearls"));
        final Setting.Mode style = add(new Setting.Mode("Style", "Ribbon", "Ribbon", "Dots", "Glow Orbs"));
        final Setting.Num length = add(new Setting.Num("Length (ticks)", 30, 4, 140, 1));
        final Setting.Num width = add(new Setting.Num("Width", 0.06, 0.01, 0.4, 0.01));
        final Setting.Num height = add(new Setting.Num("Player Height", 0.1, 0.0, 1.8, 0.05));
        final Setting.Color color = add(new Setting.Color("Colour", 0x7C9CFF, 0xB48CFF, 0xD0).mode("Theme"));
        final Setting.Bool taper = add(new Setting.Bool("Taper Width", true));
        final Setting.Bool onlyMoving = add(new Setting.Bool("Only While Moving", true));
        final Setting.Bool hideFirstPerson = add(new Setting.Bool("Skip Self In First Person", true));
        private final Map<Integer, ArrayDeque<double[]>> paths = new HashMap<>();

        public Trails() { super("Trails", "Fading trails behind players, arrows and ender pearls", Category.WORLD); }

        private boolean wants(Entity e) {
            var m = Pulse.mc;
            if (e == m.player) return sources.has("Self");
            if (e instanceof PlayerEntity) return sources.has("Other Players");
            if (e instanceof PersistentProjectileEntity) return sources.has("Arrows");
            if (e instanceof EnderPearlEntity) return sources.has("Pearls");
            return e instanceof ProjectileEntity && sources.has("Other Projectiles");
        }

        @Override public void onTick() {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) { paths.clear(); return; }
            Set<Integer> seen = new HashSet<>();
            for (Entity e : m.world.getEntities()) {
                if (!wants(e)) continue;
                seen.add(e.getId());
                ArrayDeque<double[]> q = paths.computeIfAbsent(e.getId(), k -> new ArrayDeque<>());
                double yy = e.getY() + (e instanceof PlayerEntity ? height.d() : e.getHeight() / 2);
                double[] last = q.peekLast();
                boolean moved = last == null || Math.abs(last[0] - e.getX()) + Math.abs(last[1] - yy) + Math.abs(last[2] - e.getZ()) > 0.01;
                if (moved) q.addLast(new double[]{e.getX(), yy, e.getZ()});
                else if (onlyMoving.on() || !(e instanceof PlayerEntity)) { if (!q.isEmpty()) q.pollFirst(); }
                while (q.size() > length.i()) q.pollFirst();
            }
            paths.keySet().retainAll(seen);
        }

        @Override public void onWorld(float td) {
            var m = Pulse.mc;
            if (m.world == null || paths.isEmpty()) return;
            for (var en : paths.entrySet()) {
                ArrayDeque<double[]> q = en.getValue();
                if (q.size() < 2) continue;
                Entity e = m.world.getEntityById(en.getKey());
                if (e == null || (e == m.player && hideFirstPerson.on() && m.options.getPerspective().isFirstPerson())) continue;
                int n = q.size(), i = 0;
                double[] prev = null;
                for (double[] p : q) {
                    if (prev != null) {
                        float f = i / (float) n;
                        int c = ColorUtil.alphaMul(color.get(f), f);
                        double w = width.d() * (taper.on() ? f : 1.0);
                        switch (style.get()) {
                            case "Dots" -> WorldRender.sprite(p[0], p[1], p[2], w * 1.8, c);
                            case "Glow Orbs" -> WorldRender.orb(p[0], p[1], p[2], w * 2.2, c);
                            default -> WorldRender.lineC(prev[0], prev[1], prev[2], ColorUtil.alphaMul(color.get((i - 1) / (float) n), (i - 1) / (float) n), p[0], p[1], p[2], c, Math.max(0.004, w));
                        }
                    }
                    prev = p; i++;
                }
            }
        }

        @Override public void onDisable() { paths.clear(); }
    }

    // =====================================================================================================
    public static final class Trajectories extends Module {
        final Setting.Multi items = add(new Setting.Multi("Items", new String[]{"Bow", "Crossbow", "Pearl", "Potions", "Trident", "Throwables", "XP Bottle"}, "Bow", "Crossbow", "Pearl", "Potions", "Trident", "Throwables", "XP Bottle"));
        final Setting.Mode marker = add(new Setting.Mode("Landing Marker", "Ring", "Ring", "Box", "Cross", "None"));
        final Setting.Color color = add(new Setting.Color("Line Colour", 0x7C9CFF, 0xB48CFF, 0xE0).mode("Gradient"));
        final Setting.Color hitCol = add(new Setting.Color("Entity Hit Colour", 0xFF5A5A, 0xF0));
        final Setting.Num width = add(new Setting.Num("Line Width", 0.03, 0.01, 0.1, 0.005));
        final Setting.Num maxTicks = add(new Setting.Num("Max Simulation Ticks", 120, 20, 300, 10));
        final Setting.Bool fadeEnd = add(new Setting.Bool("Fade Towards End", true));
        final Setting.Bool info = add(new Setting.Bool("Show Distance / Time", true));
        final Setting.Bool entities = add(new Setting.Bool("Detect Entity Hits", true));
        private boolean show; private double lx, ly, lz; private int ticks; private boolean hitEntity; private float dist;

        public Trajectories() { super("Trajectories", "Predicts the path of bows, crossbows, pearls, potions and tridents", Category.WORLD); }

        /** returns {speed, gravity, pitchOffset, drag} or null */
        private double[] params(ItemStack st) {
            var p = Pulse.mc.player;
            Item it = st.getItem();
            if (it == Items.BOW && items.has("Bow")) { if (!p.isUsingItem() || p.getActiveItem() != st) return null; float pull = BowItem.getPullProgress(p.getItemUseTime()); if (pull < 0.1f) return null; return new double[]{pull * 3.0, 0.05, 0, 0.99}; }
            if (it == Items.CROSSBOW && items.has("Crossbow")) { if (!CrossbowItem.isCharged(st)) return null; return new double[]{3.15, 0.05, 0, 0.99}; }
            if (it == Items.TRIDENT && items.has("Trident")) { if (!p.isUsingItem() || p.getActiveItem() != st) return null; return new double[]{2.5, 0.05, 0, 0.99}; }
            if (it == Items.ENDER_PEARL && items.has("Pearl")) return new double[]{1.5, 0.03, 0, 0.99};
            if ((it == Items.SNOWBALL || it == Items.EGG) && items.has("Throwables")) return new double[]{1.5, 0.03, 0, 0.99};
            if ((it == Items.SPLASH_POTION || it == Items.LINGERING_POTION) && items.has("Potions")) return new double[]{0.5, 0.05, -20, 0.99};
            if (it == Items.EXPERIENCE_BOTTLE && items.has("XP Bottle")) return new double[]{0.7, 0.07, -20, 0.99};
            return null;
        }

        @Override public void onWorld(float td) {
            show = false;
            var m = Pulse.mc;
            if (m.world == null || m.player == null) return;
            var p = m.player;
            double[] pr = params(p.getMainHandStack());
            if (pr == null) pr = params(p.getOffHandStack());
            if (pr == null) return;
            float yaw = p.getYaw(td), pitch = p.getPitch(td);
            double yr = Math.toRadians(yaw), prd = Math.toRadians(pitch + pr[2]), pr2 = Math.toRadians(pitch);
            Vec3d eye = p.getLerpedPos(td).add(0, p.getStandingEyeHeight(), 0);
            Vec3d pos = eye.add(-Math.cos(yr) * 0.16, -0.1, -Math.sin(yr) * 0.16);
            Vec3d vel = new Vec3d(-Math.sin(yr) * Math.cos(prd), -Math.sin(prd), Math.cos(yr) * Math.cos(prd)).multiply(pr[0]);
            Vec3d pv = p.getVelocity();
            vel = vel.add(pv.x, p.isOnGround() ? 0 : pv.y, pv.z);
            int steps = maxTicks.i();
            Vec3d prev = pos;
            hitEntity = false;
            for (int i = 0; i < steps; i++) {
                Vec3d next = prev.add(vel);
                BlockHitResult br = m.world.raycast(new RaycastContext(prev, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
                Vec3d end = next; boolean stop = false;
                if (br.getType() != HitResult.Type.MISS) { end = br.getPos(); stop = true; }
                if (entities.on()) {
                    double best = Double.MAX_VALUE;
                    for (Entity e : m.world.getEntities()) {
                        if (e == p || !(e instanceof LivingEntity) || e.isSpectator()) continue;
                        if (e.squaredDistanceTo(prev.x, prev.y, prev.z) > 36) continue;
                        Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(prev, end);
                        if (hit.isPresent()) { double d = prev.squaredDistanceTo(hit.get()); if (d < best) { best = d; end = hit.get(); stop = true; hitEntity = true; } }
                    }
                }
                float f = i / (float) steps;
                int c1 = ColorUtil.alphaMul(color.get(f), fadeEnd.on() ? 1f - f * 0.6f : 1f);
                int c2 = ColorUtil.alphaMul(color.get((i + 1) / (float) steps), fadeEnd.on() ? 1f - (f + 1f / steps) * 0.6f : 1f);
                WorldRender.lineC(prev.x, prev.y, prev.z, c1, end.x, end.y, end.z, c2, width.d());
                if (stop) { show = true; lx = end.x; ly = end.y; lz = end.z; ticks = i + 1; dist = (float) eye.distanceTo(end); drawMarker(br, end); break; }
                double drag = m.world.getFluidState(net.minecraft.util.math.BlockPos.ofFloored(next)).isEmpty() ? pr[3] : 0.8;
                vel = vel.multiply(drag).subtract(0, pr[1], 0);
                prev = next;
                if (next.y < m.world.getBottomY() - 8) break;
            }
        }

        private void drawMarker(BlockHitResult br, Vec3d at) {
            int c = hitEntity ? hitCol.get() : color.get(1f);
            switch (marker.get()) {
                case "Ring" -> { WorldRender.ringH(at.x, at.y + 0.02, at.z, 0.35, 0.06, 28, i -> c); WorldRender.discH(at.x, at.y + 0.015, at.z, 0.35, 28, ColorUtil.alphaMul(c, 0.25f)); }
                case "Box" -> { Box b = new Box(at.x - 0.2, at.y - 0.2, at.z - 0.2, at.x + 0.2, at.y + 0.2, at.z + 0.2); WorldRender.boxFill(b, ColorUtil.alphaMul(c, 0.3f)); WorldRender.boxLines(b, 0.02, c); }
                case "Cross" -> { WorldRender.line(at.x - 0.3, at.y + 0.02, at.z, at.x + 0.3, at.y + 0.02, at.z, 0.04, c); WorldRender.line(at.x, at.y + 0.02, at.z - 0.3, at.x, at.y + 0.02, at.z + 0.3, 0.04, c); }
                default -> {}
            }
        }

        @Override public void onOverlay(DrawContext c, float td) {
            if (!show || !info.on()) return;
            float[] o = new float[3];
            if (!Proj.project(lx, ly + 0.4, lz, o)) return;
            String s = String.format(Locale.ROOT, "%.1fm  %.1fs", dist, ticks / 20f);
            Render2D.textC(c, s, o[0], o[1] - 4, hitEntity ? hitCol.get() : 0xFFFFFFFF, true);
        }
    }

    // =====================================================================================================
    public static final class CustomSky extends Module {
        public final Setting.Color sky = add(new Setting.Color("Sky Colour", 0x7C9CFF, 0xB48CFF, 255).mode("Gradient"));
        public final Setting.Num strength = add(new Setting.Num("Override Strength", 0.85, 0.0, 1.0, 0.01));
        public final Setting.Bool clouds = add(new Setting.Bool("Tint Clouds", true));
        public final Setting.Color cloudCol = add(new Setting.Color("Cloud Colour", 0xF0E0FF, 255));
        public final Setting.Num cycle = add(new Setting.Num("Colour Cycle Speed", 0.15, 0.0, 2, 0.01));

        public CustomSky() { super("CustomSky", "Custom sky / cloud colour (gradient, chroma or theme driven)", Category.WORLD); }

        public int skyColor(int vanilla) {
            sky.speed = cycle.f();
            return ColorUtil.lerp(vanilla | 0xFF000000, sky.get() | 0xFF000000, strength.f()) & 0xFFFFFF;
        }
        public int cloudColor(int vanilla) { return clouds.on() ? ColorUtil.lerp(vanilla | 0xFF000000, cloudCol.get() | 0xFF000000, strength.f()) & 0xFFFFFF : vanilla; }
    }

    // =====================================================================================================
    public static final class CustomFog extends Module {
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Horizon Haze", "Horizon Haze", "Full Tint", "Top Gradient", "Edge Mist"));
        final Setting.Color color = add(new Setting.Color("Colour", 0xA8B8E8, 0xD0B0F0, 0x50).mode("Gradient"));
        final Setting.Num density = add(new Setting.Num("Density", 0.5, 0.05, 1.0, 0.05));
        final Setting.Num height = add(new Setting.Num("Height", 0.45, 0.1, 1.0, 0.05));
        final Setting.Bool breathe = add(new Setting.Bool("Breathing Animation", true));
        final Setting.Bool onlyOutdoors = add(new Setting.Bool("Hide Underground", true));

        public CustomFog() { super("CustomFog", "Screen-space atmospheric haze / fog tint (shader-pack safe)", Category.WORLD); }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            if (m.world == null || m.player == null) return;
            if (onlyOutdoors.on() && !m.world.isSkyVisible(m.player.getBlockPos()) && m.player.getY() < 60) return;
            int sw = m.getWindow().getScaledWidth(), sh = m.getWindow().getScaledHeight();
            float k = density.f() * (breathe.on() ? 0.85f + 0.15f * (float) Math.sin(Anim.time() * 0.6) : 1f);
            int col = ColorUtil.alphaMul(color.get(), k);
            int clear = ColorUtil.withAlpha(col, 0);
            switch (mode.get()) {
                case "Full Tint" -> c.fill(0, 0, sw, sh, ColorUtil.alphaMul(col, 0.55f));
                case "Top Gradient" -> c.fillGradient(0, 0, sw, (int) (sh * height.f()), col, clear);
                case "Edge Mist" -> {
                    int e = (int) (sh * 0.25f * height.f() * 2);
                    c.fillGradient(0, 0, sw, e, col, clear); c.fillGradient(0, sh - e, sw, sh, clear, col);
                    Render2D.gradH(c, 0, 0, e, sh, col, clear); Render2D.gradH(c, sw - e, 0, e, sh, clear, col);
                }
                default -> { int y0 = (int) (sh * (1f - height.f())); c.fillGradient(0, y0, sw, sh / 2 + sh / 8, clear, col); c.fillGradient(0, sh / 2 + sh / 8, sw, sh, col, ColorUtil.alphaMul(col, 0.6f)); }
            }
        }
    }

    // =====================================================================================================
    public static final class ClientTime extends Module {
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Fixed", "Fixed", "Cycle", "Real Time"));
        final Setting.Num time = add(new Setting.Num("Fixed Time (ticks)", 6000, 0, 24000, 100));
        final Setting.Num speed = add(new Setting.Num("Cycle Speed", 40, 1, 400, 1));
        final Setting.Num offset = add(new Setting.Num("Real Time Offset (h)", 0, -12, 12, 0.5));
        private double cyc;

        public ClientTime() { super("ClientTime", "Client-side time of day (fixed, cycling or synced to your clock)", Category.WORLD); }

        @Override public void onTick() { if (mode.is("Cycle")) cyc = (cyc + speed.d()) % 24000; }

        /** World time to render with (never sent to the server). */
        public long custom() {
            switch (mode.get()) {
                case "Cycle": return (long) cyc;
                case "Real Time": {
                    LocalTime t = LocalTime.now().plusMinutes((long) (offset.d() * 60));
                    double h = t.getHour() + t.getMinute() / 60.0 + t.getSecond() / 3600.0;
                    return (long) (((h - 6.0 + 24.0) % 24.0) * 1000.0);
                }
                default: return time.i();
            }
        }
    }

    // =====================================================================================================
    public static final class ClientWeather extends Module {
        public final Setting.Mode mode = add(new Setting.Mode("Weather", "Clear", "Clear", "Rain", "Thunder"));
        public final Setting.Num rain = add(new Setting.Num("Rain Strength", 1.0, 0.1, 1.0, 0.05)).showIf(() -> !mode.is("Clear"));
        private float rg, tg;

        public ClientWeather() { super("ClientWeather", "Client-side weather override (no server change)", Category.WORLD); }

        public float rain(float vanilla) { return mode.is("Clear") ? 0f : rain.f(); }
        public float thunder(float vanilla) { return mode.is("Thunder") ? rain.f() : 0f; }
    }

    // =====================================================================================================
    public static final class Fullbright extends Module {
        final Setting.Mode mode = add(new Setting.Mode("Mode", "Gamma", "Gamma", "Night Vision", "Both"));
        final Setting.Num gamma = add(new Setting.Num("Gamma", 12.0, 1.0, 16.0, 0.5));
        private Object saved;

        public Fullbright() { super("Fullbright", "Maximum brightness without potions or packets", Category.WORLD); }

        public boolean nightVision() { return enabled && (mode.is("Night Vision") || mode.is("Both")); }

        @Override public void onEnable() { saved = Pulse.mc.options.getGamma().getValue(); }

        @Override public void onTick() {
            if (mode.is("Gamma") || mode.is("Both")) ((SimpleOptionAccessor) (Object) Pulse.mc.options.getGamma()).pulse$setValue(gamma.d());
            else if (saved != null) ((SimpleOptionAccessor) (Object) Pulse.mc.options.getGamma()).pulse$setValue(saved);
        }

        @Override public void onDisable() { if (saved != null) ((SimpleOptionAccessor) (Object) Pulse.mc.options.getGamma()).pulse$setValue(saved); }
    }

    // =====================================================================================================
    public static final class ScreenFX extends Module {
        final Setting.Multi fx = add(new Setting.Multi("Effects", new String[]{"Vignette", "Colour Tint", "Letterbox", "Scanlines", "Low-HP Glow", "Soft Edge Frost"}, "Vignette"));
        final Setting.Color vigCol = add(new Setting.Color("Vignette Colour", 0x000000, 0xB0));
        final Setting.Num vigSize = add(new Setting.Num("Vignette Size", 0.28, 0.05, 0.6, 0.01));
        final Setting.Color tint = add(new Setting.Color("Tint Colour", 0x7C9CFF, 0x18));
        final Setting.Num bars = add(new Setting.Num("Letterbox Height", 0.1, 0.02, 0.25, 0.01));
        final Setting.Num scan = add(new Setting.Num("Scanline Gap", 3, 2, 8, 1));
        final Setting.Num scanAlpha = add(new Setting.Num("Scanline Opacity", 0.12, 0.02, 0.4, 0.01));
        final Setting.Num hpThreshold = add(new Setting.Num("Low-HP Threshold", 6, 2, 12, 0.5));
        final Setting.Color frost = add(new Setting.Color("Frost Colour", 0xFFFFFF, 0x30));
        private float lowHp;

        public ScreenFX() { super("ScreenFX", "Soft vignette, tint, letterbox, scanlines and low-HP glow (no shaders)", Category.WORLD); }

        private void edges(DrawContext c, int sw, int sh, float size, int col) {
            int t = (int) (Math.min(sw, sh) * size);
            int clear = ColorUtil.withAlpha(col, 0);
            c.fillGradient(0, 0, sw, t, col, clear);
            c.fillGradient(0, sh - t, sw, sh, clear, col);
            Render2D.gradH(c, 0, 0, t, sh, col, clear);
            Render2D.gradH(c, sw - t, 0, t, sh, clear, col);
        }

        @Override public void onOverlay(DrawContext c, float td) {
            var m = Pulse.mc;
            int sw = m.getWindow().getScaledWidth(), sh = m.getWindow().getScaledHeight();
            if (fx.has("Colour Tint")) c.fill(0, 0, sw, sh, tint.get());
            if (fx.has("Vignette")) edges(c, sw, sh, vigSize.f(), vigCol.get());
            if (fx.has("Soft Edge Frost")) edges(c, sw, sh, 0.08f, frost.get());
            if (fx.has("Low-HP Glow") && m.player != null) {
                float hp = m.player.getHealth();
                lowHp = Anim.to(lowHp, hp <= hpThreshold.f() && hp > 0 ? 1f : 0f, 5f);
                if (lowHp > 0.02f) edges(c, sw, sh, 0.22f, ColorUtil.alphaMul(0xFFE02020, lowHp * (0.55f + 0.25f * (float) Math.sin(Anim.time() * 5))));
            }
            if (fx.has("Scanlines")) {
                int gap = scan.i(), col = (int) (scanAlpha.d() * 255) << 24;
                for (int y = 0; y < sh; y += gap) c.fill(0, y, sw, y + 1, col);
            }
            if (fx.has("Letterbox")) {
                int h = (int) (sh * bars.f());
                c.fill(0, 0, sw, h, 0xFF000000); c.fill(0, sh - h, sw, sh, 0xFF000000);
            }
        }
    }
}
