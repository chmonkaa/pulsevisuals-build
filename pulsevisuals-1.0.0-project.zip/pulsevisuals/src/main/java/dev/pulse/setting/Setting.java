package dev.pulse.setting;

import com.google.gson.*;
import dev.pulse.theme.ThemeManager;
import dev.pulse.util.ColorUtil;
import dev.pulse.util.KeyNames;

import java.util.*;
import java.util.function.BooleanSupplier;

/** Base class for every configurable value. Nested subclasses are the concrete setting types. */
public abstract class Setting<T> {
    public final String name;
    public T value;
    public final T def;
    public BooleanSupplier visible = () -> true;

    protected Setting(String name, T def) { this.name = name; this.value = def; this.def = def; }

    public void set(T v) { value = v; }
    public void reset() { value = def; }
    public boolean isVisible() { return visible.getAsBoolean(); }

    @SuppressWarnings("unchecked")
    public <S extends Setting<?>> S showIf(BooleanSupplier b) { visible = b; return (S) this; }

    public abstract JsonElement save();
    public abstract void load(JsonElement e);

    // ------------------------------------------------------------------ Boolean
    public static class Bool extends Setting<Boolean> {
        public Bool(String n, boolean d) { super(n, d); }
        public Boolean get() { return value; }
        public boolean on() { return value; }
        public void toggle() { value = !value; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { if (e != null && e.isJsonPrimitive()) value = e.getAsBoolean(); }
    }

    // ------------------------------------------------------------------ Number (int / float with step)
    public static class Num extends Setting<Double> {
        public final double min, max, step;
        public Num(String n, double d, double min, double max, double step) { super(n, d); this.min = min; this.max = max; this.step = step; }
        @Override public void set(Double v) {
            double x = Math.max(min, Math.min(max, v));
            if (step > 0) x = min + Math.round((x - min) / step) * step;
            x = Math.round(x * 10000.0) / 10000.0;
            value = Math.max(min, Math.min(max, x));
        }
        public Double get() { return value; }
        public double d() { return value; }
        public float f() { return value.floatValue(); }
        public int i() { return (int) Math.round(value); }
        public double norm() { return max == min ? 0 : (value - min) / (max - min); }
        public boolean isInt() { return step >= 1 && step == Math.floor(step); }
        public String display() { return isInt() ? String.valueOf(i()) : String.format(Locale.ROOT, step < 0.1 ? "%.2f" : "%.1f", value); }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { if (e != null && e.isJsonPrimitive()) set(e.getAsDouble()); }
    }

    // ------------------------------------------------------------------ Mode (single choice)
    public static class Mode extends Setting<String> {
        public final String[] modes;
        public Mode(String n, String d, String... modes) { super(n, d); this.modes = modes; }
        public String get() { return value; }
        public boolean is(String m) { return value.equals(m); }
        public int idx() { for (int i = 0; i < modes.length; i++) if (modes[i].equals(value)) return i; return 0; }
        public void cycle(int dir) { value = modes[(idx() + dir + modes.length) % modes.length]; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) {
            if (e == null || !e.isJsonPrimitive()) return;
            String s = e.getAsString();
            for (String m : modes) if (m.equals(s)) { value = s; return; }
        }
    }

    // ------------------------------------------------------------------ MultiSelect
    public static class Multi extends Setting<Set<String>> {
        public final String[] options;
        public Multi(String n, String[] options, String... defaults) {
            super(n, new LinkedHashSet<>(Arrays.asList(defaults)));
            this.options = options;
        }
        public Set<String> get() { return value; }
        public boolean has(String s) { return value.contains(s); }
        public void toggle(String s) { if (!value.remove(s)) value.add(s); }
        @Override public void reset() { value = new LinkedHashSet<>(def); }
        @Override public JsonElement save() { JsonArray a = new JsonArray(); for (String s : value) a.add(s); return a; }
        @Override public void load(JsonElement e) {
            if (e == null || !e.isJsonArray()) return;
            value = new LinkedHashSet<>();
            for (JsonElement x : e.getAsJsonArray()) value.add(x.getAsString());
        }
    }

    // ------------------------------------------------------------------ Color (alpha, chroma, gradient, theme sync)
    public static class Color extends Setting<Integer> {
        public static final String[] MODES = {"Static", "Gradient", "Chroma", "Theme", "Pulse"};
        public int second;
        public int alpha;
        public String mode = "Static";
        public float speed = 1f;
        private final int defSecond, defAlpha;

        public Color(String n, int rgb, int alpha) { this(n, rgb, rgb, alpha); }
        public Color(String n, int rgb, int rgb2, int alpha) { super(n, rgb & 0xFFFFFF); second = rgb2 & 0xFFFFFF; this.alpha = alpha; defSecond = second; defAlpha = alpha; }
        public Color mode(String m) { mode = m; return this; }

        public int get() { return get(0f); }

        /** ARGB color. {@code phase} (0..1) offsets animated modes so lists/rings get a moving gradient. */
        public int get(float phase) {
            double t = System.currentTimeMillis() / 1000.0 * speed;
            int c;
            switch (mode) {
                case "Gradient" -> c = ColorUtil.lerp(0xFF000000 | value, 0xFF000000 | second, (float) (0.5 + 0.5 * Math.sin((t + phase) * Math.PI * 2)));
                case "Chroma" -> c = ColorUtil.hsb((float) ((t * 0.2 + phase) % 1.0), 0.6f, 1f);
                case "Theme" -> c = ColorUtil.lerp(ThemeManager.cur().accent, ThemeManager.cur().accent2, (float) (0.5 + 0.5 * Math.sin((t + phase) * Math.PI * 2)));
                default -> c = 0xFF000000 | value;
            }
            int a = alpha;
            if (mode.equals("Pulse")) a = (int) (alpha * (0.55 + 0.45 * Math.sin(t * Math.PI * 2)));
            return ColorUtil.withAlpha(c, a);
        }
        /** Static (non-animated) base colour as ARGB. */
        public int base() { return ColorUtil.withAlpha(value, alpha); }
        public boolean animated() { return !mode.equals("Static"); }

        @Override public void reset() { value = def; second = defSecond; alpha = defAlpha; mode = "Static"; speed = 1f; }
        @Override public JsonElement save() {
            JsonObject o = new JsonObject();
            o.addProperty("rgb", value); o.addProperty("rgb2", second); o.addProperty("alpha", alpha);
            o.addProperty("mode", mode); o.addProperty("speed", speed);
            return o;
        }
        @Override public void load(JsonElement e) {
            if (e == null || !e.isJsonObject()) return;
            JsonObject o = e.getAsJsonObject();
            if (o.has("rgb")) value = o.get("rgb").getAsInt() & 0xFFFFFF;
            if (o.has("rgb2")) second = o.get("rgb2").getAsInt() & 0xFFFFFF;
            if (o.has("alpha")) alpha = Math.max(0, Math.min(255, o.get("alpha").getAsInt()));
            if (o.has("mode")) { String m = o.get("mode").getAsString(); for (String s : MODES) if (s.equals(m)) mode = m; }
            if (o.has("speed")) speed = o.get("speed").getAsFloat();
        }
    }

    // ------------------------------------------------------------------ Key bind
    public static class Bind extends Setting<Integer> {
        public Bind(String n, int key) { super(n, key); }
        public Integer get() { return value; }
        public boolean isSet() { return value > 0; }
        public String display() { return isSet() ? KeyNames.name(value) : "None"; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { if (e != null && e.isJsonPrimitive()) value = e.getAsInt(); }
    }

    // ------------------------------------------------------------------ Free text (macro commands etc.)
    public static class Text extends Setting<String> {
        public final int maxLen;
        public String get() { return value; }
        public Text(String n, String d, int maxLen) { super(n, d); this.maxLen = maxLen; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { if (e != null && e.isJsonPrimitive()) value = e.getAsString(); }
    }
}
