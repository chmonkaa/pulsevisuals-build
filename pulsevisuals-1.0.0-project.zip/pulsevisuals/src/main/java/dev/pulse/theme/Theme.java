package dev.pulse.theme;

public class Theme {
    public String name;
    /** window background, panel, raised card, accent 1, accent 2, text, dim text, outline (all ARGB) */
    public int bg, panel, card, accent, accent2, text, dim, outline;

    public Theme() {}
    public Theme(String name, int bg, int panel, int card, int accent, int accent2, int text, int dim, int outline) {
        this.name = name; this.bg = bg; this.panel = panel; this.card = card;
        this.accent = accent; this.accent2 = accent2; this.text = text; this.dim = dim; this.outline = outline;
    }
    public Theme copy(String n) { return new Theme(n, bg, panel, card, accent, accent2, text, dim, outline); }
}
