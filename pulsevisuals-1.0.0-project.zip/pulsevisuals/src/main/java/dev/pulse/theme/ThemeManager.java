package dev.pulse.theme;

import com.google.gson.*;
import dev.pulse.config.Config;
import dev.pulse.setting.Setting;

import java.nio.file.*;
import java.util.*;

/** Built-in presets, user themes (themes.json) and the live "Custom" constructor. */
public final class ThemeManager {
    public static final List<Theme> PRESETS = new ArrayList<>();
    public static final List<Theme> USER = new ArrayList<>();
    private static String currentName = "Midnight";
    private static Theme current;

    // Theme constructor (rendered by the GUI as ordinary settings)
    public static final Setting.Color cBg = new Setting.Color("Window", 0x10131A, 0xE8);
    public static final Setting.Color cPanel = new Setting.Color("Panel", 0x171B25, 0xD6);
    public static final Setting.Color cCard = new Setting.Color("Card", 0x212736, 0xD0);
    public static final Setting.Color cAccent = new Setting.Color("Accent", 0x7C9CFF, 0xFF);
    public static final Setting.Color cAccent2 = new Setting.Color("Accent 2", 0xB48CFF, 0xFF);
    public static final Setting.Color cText = new Setting.Color("Text", 0xE8EAF2, 0xFF);
    public static final List<Setting<?>> CUSTOM = List.of(cBg, cPanel, cCard, cAccent, cAccent2, cText);

    static {
        add("Midnight", 0xE80F1218, 0xD6161A24, 0xD01F2433, 0xFF7C9CFF, 0xFFB48CFF, 0xFFE8EAF2, 0xFF8A91A8, 0x22FFFFFF);
        add("Pastel", 0xE81E1B26, 0xD626222F, 0xD0302B3C, 0xFFF2A9C6, 0xFFA9D6F2, 0xFFF3EEF7, 0xFF9E96AD, 0x26FFFFFF);
        add("Cyberpunk", 0xE80E0B16, 0xD6161122, 0xD01F1830, 0xFFE070CC, 0xFF5ED2E6, 0xFFEDE8F7, 0xFF8C84A8, 0x2AFFFFFF);
        add("Monochrome", 0xE80E0E10, 0xD6171719, 0xD0222225, 0xFFD6D6D8, 0xFF8E8E94, 0xFFF0F0F2, 0xFF84848A, 0x22FFFFFF);
        add("Lavender", 0xE8171525, 0xD61E1B30, 0xD0292540, 0xFFB69CFF, 0xFFE2A8F2, 0xFFEFEAFA, 0xFF9690B4, 0x24FFFFFF);
        add("Ocean", 0xE80C1319, 0xD6111C25, 0xD01A2935, 0xFF5BBAD8, 0xFF6C8EFF, 0xFFE6F0F5, 0xFF7F9AA8, 0x22FFFFFF);
        add("Rose", 0xE8191217, 0xD6221820, 0xD02E212B, 0xFFE88AA2, 0xFFF2B47E, 0xFFF6ECEF, 0xFFA8939B, 0x24FFFFFF);
        add("Forest", 0xE80E1511, 0xD6141D18, 0xD01D2A22, 0xFF7CC79C, 0xFFB6DB8A, 0xFFE9F2EC, 0xFF8AA595, 0x22FFFFFF);
        add("Sunset", 0xE8171116, 0xD61F161D, 0xD02B1E27, 0xFFF29E7A, 0xFFE882A6, 0xFFF7EDEA, 0xFFAD9690, 0x24FFFFFF);
        current = PRESETS.get(0);
    }

    private static void add(String n, int... v) { PRESETS.add(new Theme(n, v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7])); }

    public static Theme cur() {
        if ("Custom".equals(currentName)) {
            current = new Theme("Custom", cBg.base(), cPanel.base(), cCard.base(), cAccent.base() | 0xFF000000, cAccent2.base() | 0xFF000000,
                    cText.base() | 0xFF000000, 0xFF000000 | dimOf(cText.value), 0x22FFFFFF);
        }
        return current;
    }

    private static int dimOf(int rgb) {
        int r = (rgb >> 16 & 255) * 2 / 3, g = (rgb >> 8 & 255) * 2 / 3, b = (rgb & 255) * 2 / 3;
        return r << 16 | g << 8 | b;
    }

    public static String currentName() { return currentName; }

    public static void select(String name) {
        currentName = name;
        if (name.equals("Custom")) { cur(); return; }
        for (Theme t : PRESETS) if (t.name.equals(name)) { current = t; return; }
        for (Theme t : USER) if (t.name.equals(name)) { current = t; return; }
        currentName = "Midnight"; current = PRESETS.get(0);
    }

    public static List<Theme> all() { List<Theme> l = new ArrayList<>(PRESETS); l.addAll(USER); return l; }

    /** Saves the live custom theme as a named user theme. */
    public static void saveCustomAs(String name) {
        Theme t = cur().copy(name);
        USER.removeIf(x -> x.name.equals(name));
        USER.add(t);
        saveUser();
    }

    public static void deleteUser(String name) { USER.removeIf(x -> x.name.equals(name)); saveUser(); }

    public static void loadUser() {
        Path p = Config.dir().resolve("themes.json");
        USER.clear();
        if (!Files.exists(p)) return;
        try {
            JsonArray a = JsonParser.parseString(Files.readString(p)).getAsJsonArray();
            Gson g = new Gson();
            for (JsonElement e : a) USER.add(g.fromJson(e, Theme.class));
        } catch (Exception ignored) {}
    }

    public static void saveUser() {
        try {
            Files.createDirectories(Config.dir());
            Files.writeString(Config.dir().resolve("themes.json"), new GsonBuilder().setPrettyPrinting().create().toJson(USER));
        } catch (Exception ignored) {}
    }

    public static JsonObject saveState() {
        JsonObject o = new JsonObject();
        o.addProperty("selected", currentName);
        JsonObject c = new JsonObject();
        for (Setting<?> s : CUSTOM) c.add(s.name, s.save());
        o.add("custom", c);
        return o;
    }

    public static void loadState(JsonObject o) {
        if (o == null) return;
        if (o.has("custom")) { JsonObject c = o.getAsJsonObject("custom"); for (Setting<?> s : CUSTOM) s.load(c.get(s.name)); }
        if (o.has("selected")) select(o.get("selected").getAsString());
    }

    private ThemeManager() {}
}
