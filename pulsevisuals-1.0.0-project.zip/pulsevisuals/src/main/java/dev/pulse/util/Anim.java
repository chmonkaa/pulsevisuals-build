package dev.pulse.util;

/** Frame-time based interpolation helpers. */
public final class Anim {
    private static long last = System.nanoTime();
    private static final long START = System.nanoTime();
    public static float dt = 0.016f;

    /** Call once per rendered frame (HUD pass, or the GUI when the HUD is hidden). */
    public static void frame() {
        long now = System.nanoTime();
        dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;
    }

    public static float time() { return (System.nanoTime() - START) / 1_000_000_000f; }

    /** Frame-rate independent exponential approach. */
    public static float to(float cur, float target, float speed) {
        return cur + (target - cur) * (1f - (float) Math.exp(-speed * dt));
    }

    public static float clamp01(float v) { return v < 0 ? 0 : Math.min(v, 1f); }
    public static float easeOutCubic(float t) { t = clamp01(t); float u = 1 - t; return 1 - u * u * u; }
    public static float easeInOut(float t) { t = clamp01(t); return t * t * (3 - 2 * t); }
    public static float easeOutBack(float t) { t = clamp01(t); float c1 = 1.70158f, c3 = c1 + 1; float u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    private Anim() {}
}
