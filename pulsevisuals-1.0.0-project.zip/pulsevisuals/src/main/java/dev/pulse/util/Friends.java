package dev.pulse.util;

import net.minecraft.entity.Entity;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

public final class Friends {
    public static final Set<String> NAMES = new LinkedHashSet<>();

    public static boolean is(String name) { return name != null && NAMES.contains(name.toLowerCase(Locale.ROOT)); }
    public static boolean is(Entity e) { return e != null && is(e.getName().getString()); }
    public static boolean add(String n) { return NAMES.add(n.toLowerCase(Locale.ROOT)); }
    public static boolean remove(String n) { return NAMES.remove(n.toLowerCase(Locale.ROOT)); }

    private Friends() {}
}
