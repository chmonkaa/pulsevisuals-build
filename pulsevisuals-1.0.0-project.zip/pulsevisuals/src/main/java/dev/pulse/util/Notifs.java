package dev.pulse.util;

import dev.pulse.module.Module;
import dev.pulse.modules.Modules;

import java.util.ArrayList;
import java.util.List;

/** Toast queue rendered by the Notifications HUD module. */
public final class Notifs {
    public static final class Toast {
        public final String title, body;
        public final int color;
        public final long born = System.currentTimeMillis();
        public float anim;
        Toast(String t, String b, int c) { title = t; body = b; color = c; }
    }

    public static final List<Toast> LIST = new ArrayList<>();

    public static void push(String title, String body, int color) {
        if (Modules.NOTIFICATIONS == null || !Modules.NOTIFICATIONS.enabled) return;
        LIST.add(new Toast(title, body, color));
        while (LIST.size() > 8) LIST.remove(0);
    }

    public static void moduleToggled(Module m) {
        if (Modules.NOTIFICATIONS == null || !Modules.NOTIFICATIONS.enabled || !Modules.NOTIFICATIONS.toggles.on()) return;
        push(m.name, m.enabled ? "Enabled" : "Disabled", m.enabled ? 0xFF6EDC9A : 0xFFE5707A);
    }

    private Notifs() {}
}
