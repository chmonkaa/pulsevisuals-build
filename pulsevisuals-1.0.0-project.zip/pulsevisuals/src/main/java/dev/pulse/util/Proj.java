package dev.pulse.util;

import dev.pulse.Pulse;
import dev.pulse.mixin.CameraAccessor;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * World -> screen projection computed from the live camera (independent of the render pipeline, so it
 * keeps working with Sodium / Iris / any renderer replacement).
 */
public final class Proj {
    public static double cx, cy, cz;
    public static float fx, fy, fz, rx, ry, rz, ux, uy, uz;
    private static float tanHalf = 1f, aspect = 1f;
    private static int sw = 1, sh = 1;
    private static final Vector3f tmp = new Vector3f();
    private static final Quaternionf q = new Quaternionf();

    /** Refresh the camera snapshot. Cheap; called at the start of each HUD / world pass. */
    public static void update() {
        var mc = Pulse.mc;
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return;
        Vec3d p = ((CameraAccessor) cam).pulse$getPos();
        cx = p.x; cy = p.y; cz = p.z;
        q.set(cam.getRotation());
        tmp.set(0, 0, -1).rotate(q); fx = tmp.x; fy = tmp.y; fz = tmp.z;
        tmp.set(1, 0, 0).rotate(q); rx = tmp.x; ry = tmp.y; rz = tmp.z;
        tmp.set(0, 1, 0).rotate(q); ux = tmp.x; uy = tmp.y; uz = tmp.z;
        sw = mc.getWindow().getScaledWidth();
        sh = mc.getWindow().getScaledHeight();
        aspect = Pulse.aspect > 0 ? Pulse.aspect : (float) mc.getWindow().getFramebufferWidth() / Math.max(1, mc.getWindow().getFramebufferHeight());
        tanHalf = (float) Math.tan(Math.toRadians(MathHelper.clamp(Pulse.fov, 1f, 170f)) / 2.0);
    }

    /** Projects a world point. out = {screenX, screenY, depth}. Returns false when behind the camera. */
    public static boolean project(double x, double y, double z, float[] out) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        float depth = (float) (dx * fx + dy * fy + dz * fz);
        if (depth < 0.05f) { out[2] = depth; return false; }
        float px = (float) (dx * rx + dy * ry + dz * rz) / (depth * tanHalf * aspect);
        float py = (float) (dx * ux + dy * uy + dz * uz) / (depth * tanHalf);
        out[0] = sw * 0.5f * (1f + px);
        out[1] = sh * 0.5f * (1f - py);
        out[2] = depth;
        return true;
    }

    /** Screen-space direction angle (radians, 0 = right, PI/2 = up) from the camera towards a point. */
    public static float dirAngle(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        float sx = (float) (dx * rx + dy * ry + dz * rz), sy = (float) (dx * ux + dy * uy + dz * uz);
        float depth = (float) (dx * fx + dy * fy + dz * fz);
        if (depth < 0 && Math.abs(sx) < 0.001f && Math.abs(sy) < 0.001f) sy = -1f;
        return (float) Math.atan2(sy, sx);
    }

    public static Vec3d lerpPos(Entity e, float td) {
        return e.getLerpedPos(td);
    }

    public static boolean onScreen(float x, float y, float margin) { return x > -margin && y > -margin && x < sw + margin && y < sh + margin; }

    private Proj() {}
}
