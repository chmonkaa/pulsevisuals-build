package dev.pulse.util;

import dev.pulse.Pulse;
import dev.pulse.setting.Setting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

/** Cheap 2D primitives on top of DrawContext (rounded rects, glows, circles, lines, scaled text). */
public final class Render2D {
    private static final int[][] INS = new int[40][];

    private static int[] ins(int r) {
        int[] a = INS[r];
        if (a == null) {
            a = new int[r];
            for (int i = 0; i < r; i++) {
                double dy = r - i - 0.5, dx = Math.sqrt(Math.max(0, (double) r * r - dy * dy));
                a[i] = (int) Math.round(r - dx);
            }
            INS[r] = a;
        }
        return a;
    }

    public static TextRenderer font() { return Pulse.mc.textRenderer; }

    public static void rect(DrawContext c, float x, float y, float w, float h, int col) {
        if ((col >>> 24) == 0) return;
        c.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), col);
    }

    public static void rrect(DrawContext c, float xf, float yf, float wf, float hf, float rf, int col) {
        if ((col >>> 24) == 0) return;
        int x = Math.round(xf), y = Math.round(yf), w = Math.round(wf), h = Math.round(hf);
        if (w <= 0 || h <= 0) return;
        int r = Math.min(Math.min(39, (int) rf), Math.min(w, h) / 2);
        if (r <= 0) { c.fill(x, y, x + w, y + h, col); return; }
        int[] in = ins(r);
        for (int i = 0; i < r; i++) {
            c.fill(x + in[i], y + i, x + w - in[i], y + i + 1, col);
            c.fill(x + in[i], y + h - 1 - i, x + w - in[i], y + h - i, col);
        }
        if (h > 2 * r) c.fill(x, y + r, x + w, y + h - r, col);
    }

    /** 1px rounded outline. */
    public static void outline(DrawContext c, float xf, float yf, float wf, float hf, float rf, int col) {
        if ((col >>> 24) == 0) return;
        int x = Math.round(xf), y = Math.round(yf), w = Math.round(wf), h = Math.round(hf);
        if (w <= 2 || h <= 2) return;
        int r = Math.min(Math.min(39, (int) rf), Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + 1, col); c.fill(x, y + h - 1, x + w, y + h, col);
            c.fill(x, y + 1, x + 1, y + h - 1, col); c.fill(x + w - 1, y + 1, x + w, y + h - 1, col);
            return;
        }
        int[] in = ins(r);
        for (int i = 0; i < r; i++) {
            int prev = i == 0 ? r : in[i - 1];
            int seg = Math.max(1, prev - in[i]);
            c.fill(x + in[i], y + i, x + in[i] + seg, y + i + 1, col);
            c.fill(x + w - in[i] - seg, y + i, x + w - in[i], y + i + 1, col);
            c.fill(x + in[i], y + h - 1 - i, x + in[i] + seg, y + h - i, col);
            c.fill(x + w - in[i] - seg, y + h - 1 - i, x + w - in[i], y + h - i, col);
        }
        c.fill(x + r, y, x + w - r, y + 1, col);
        c.fill(x + r, y + h - 1, x + w - r, y + h, col);
        c.fill(x, y + r, x + 1, y + h - r, col);
        c.fill(x + w - 1, y + r, x + w, y + h - r, col);
    }

    /** Rounded rect with a vertical colour gradient (row by row, for small shapes). */
    public static void rrectGradV(DrawContext c, float xf, float yf, float wf, float hf, float rf, int top, int bottom) {
        int x = Math.round(xf), y = Math.round(yf), w = Math.round(wf), h = Math.round(hf);
        if (w <= 0 || h <= 0) return;
        int r = Math.min(Math.min(39, (int) rf), Math.min(w, h) / 2);
        int[] in = r > 0 ? ins(r) : null;
        for (int i = 0; i < h; i++) {
            int inset = 0;
            if (r > 0) { if (i < r) inset = in[i]; else if (i >= h - r) inset = in[h - 1 - i]; }
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, ColorUtil.lerp(top, bottom, h <= 1 ? 0 : i / (float) (h - 1)));
        }
    }

    /** Horizontal gradient bar (stripes). */
    public static void gradH(DrawContext c, float xf, float yf, float wf, float hf, int c1, int c2) {
        int x = Math.round(xf), y = Math.round(yf), w = Math.round(wf), h = Math.round(hf);
        if (w <= 0 || h <= 0) return;
        int n = Math.min(w, 48);
        for (int i = 0; i < n; i++) {
            int xa = x + i * w / n, xb = x + (i + 1) * w / n;
            c.fill(xa, y, xb, y + h, ColorUtil.lerp(c1, c2, n == 1 ? 0 : i / (float) (n - 1)));
        }
    }

    public static void gradV(DrawContext c, float x, float y, float w, float h, int top, int bottom) {
        c.fillGradient(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), top, bottom);
    }

    /** Soft shadow / glow below a rounded rect. */
    public static void glow(DrawContext c, float x, float y, float w, float h, float r, int col, int layers) {
        int a = col >>> 24;
        for (int k = layers; k >= 1; k--) {
            float t = 1f - (k - 1f) / layers;
            rrect(c, x - k, y - k, w + k * 2, h + k * 2, r + k, (int) (a * t * t / layers * 1.6f) << 24 | (col & 0xFFFFFF));
        }
    }

    public static void circle(DrawContext c, float cx, float cy, float r, int col) {
        if ((col >>> 24) == 0 || r <= 0) return;
        int ir = (int) Math.ceil(r);
        int icx = Math.round(cx), icy = Math.round(cy);
        for (int dy = -ir; dy <= ir; dy++) {
            double dx = Math.sqrt(Math.max(0, r * r - (dy + 0.5) * (dy + 0.5)));
            if (dx <= 0) continue;
            c.fill((int) Math.round(icx - dx), icy + dy, (int) Math.round(icx + dx), icy + dy + 1, col);
        }
    }

    public static void ring(DrawContext c, float cx, float cy, float r, float thick, int col) {
        if ((col >>> 24) == 0 || r <= 0) return;
        float ri = Math.max(0, r - thick);
        int ir = (int) Math.ceil(r);
        int icx = Math.round(cx), icy = Math.round(cy);
        for (int dy = -ir; dy <= ir; dy++) {
            double yy = (dy + 0.5) * (dy + 0.5);
            double dxo = Math.sqrt(Math.max(0, r * r - yy)), dxi = Math.sqrt(Math.max(0, ri * ri - yy));
            if (dxo <= 0) continue;
            if (dxi <= 0) { c.fill((int) Math.round(icx - dxo), icy + dy, (int) Math.round(icx + dxo), icy + dy + 1, col); continue; }
            c.fill((int) Math.round(icx - dxo), icy + dy, (int) Math.round(icx - dxi), icy + dy + 1, col);
            c.fill((int) Math.round(icx + dxi), icy + dy, (int) Math.round(icx + dxo), icy + dy + 1, col);
        }
    }

    /** Arbitrary line (rotated 1px-thick rect scaled to {@code thick}). */
    public static void line(DrawContext c, float x1, float y1, float x2, float y2, float thick, int col) {
        if ((col >>> 24) == 0) return;
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5f) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x1, y1);
        m.rotate((float) Math.atan2(dy, dx));
        m.translate(0, -thick / 2f);
        m.scale(1f, thick);
        c.fill(0, 0, Math.max(1, Math.round(len)), 1, col);
        m.popMatrix();
    }

    // ---- text ---------------------------------------------------------------------------------------------
    public static int tw(String s) { return font().getWidth(s); }
    public static int th() { return font().fontHeight; }

    public static void text(DrawContext c, String s, float x, float y, int col) {
        if ((col >>> 24) < 8) return;
        c.drawText(font(), s, Math.round(x), Math.round(y), col, false);
    }

    public static void textS(DrawContext c, String s, float x, float y, int col) {
        if ((col >>> 24) < 8) return;
        c.drawText(font(), s, Math.round(x), Math.round(y), col, true);
    }

    public static void textC(DrawContext c, String s, float cx, float y, int col, boolean shadow) {
        if ((col >>> 24) < 8) return;
        c.drawText(font(), s, Math.round(cx - tw(s) / 2f), Math.round(y), col, shadow);
    }

    public static void textR(DrawContext c, String s, float rx, float y, int col, boolean shadow) {
        if ((col >>> 24) < 8) return;
        c.drawText(font(), s, Math.round(rx - tw(s)), Math.round(y), col, shadow);
    }

    public static void textScaled(DrawContext c, String s, float x, float y, float scale, int col, boolean shadow) {
        if ((col >>> 24) < 8) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        c.drawText(font(), s, 0, 0, col, shadow);
        m.popMatrix();
    }

    // ---- items ------------------------------------------------------------------------------------------------
    public static void item(DrawContext c, ItemStack st, float x, float y, float scale, boolean overlay) {
        if (st == null || st.isEmpty()) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        c.drawItem(st, 0, 0);
        if (overlay) c.drawStackOverlay(font(), st, 0, 0);
        m.popMatrix();
    }

    public static String trim(String s, int maxW) {
        if (tw(s) <= maxW) return s;
        while (s.length() > 1 && tw(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }


    /** Per-character gradient / chroma text driven by a Color setting. */
    public static int gradText(DrawContext c, String s, float x, float y, Setting.Color col, boolean shadow, float alphaMul) {
        float cx = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            int color = ColorUtil.alphaMul(col.get(i * 0.06f), alphaMul);
            if ((color >>> 24) >= 8) c.drawText(font(), ch, Math.round(cx), Math.round(y), color, shadow);
            cx += font().getWidth(ch);
        }
        return Math.round(cx - x);
    }


    /** Filled triangle pointing along {@code angle} (radians, screen space, y down), tip at (x,y) + dir*len. */
    public static void triangle(DrawContext c, float x, float y, float angle, float len, float halfW, int col) {
        if ((col >>> 24) == 0) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.rotate(angle);
        int L = Math.max(1, Math.round(len));
        for (int i = 0; i < L; i++) {
            float hh = halfW * (1f - i / (float) L);
            int h = Math.max(1, Math.round(hh));
            c.fill(i, -h, i + 1, h, col);
        }
        m.popMatrix();
    }

    private Render2D() {}
}
