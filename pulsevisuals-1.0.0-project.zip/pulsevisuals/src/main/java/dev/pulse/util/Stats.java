package dev.pulse.util;

import dev.pulse.Pulse;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** Runtime statistics: server TPS estimate, CPS counters, player speed. */
public final class Stats {
    public static float tps = -1f;
    private static long lastPacketNs = 0;
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>(), RIGHT = new ArrayDeque<>();
    private static boolean lDown, rDown;
    public static double speed;          // blocks / second
    private static double px, pz;
    private static boolean hasPos;

    /** Called for every world-time packet (they arrive every 20 server ticks). */
    public static void onTimePacket() {
        long now = System.nanoTime();
        if (lastPacketNs != 0) {
            double sec = (now - lastPacketNs) / 1e9;
            if (sec > 0.2 && sec < 15) {
                float t = (float) Math.min(20.0, 20.0 / sec);
                tps = tps < 0 ? t : tps * 0.7f + t * 0.3f;
            }
        }
        lastPacketNs = now;
    }

    public static void resetWorld() { tps = -1f; lastPacketNs = 0; hasPos = false; }

    public static void tick() {
        var p = Pulse.mc.player;
        if (p == null) return;
        if (hasPos) speed = Math.hypot(p.getX() - px, p.getZ() - pz) * 20.0;
        px = p.getX(); pz = p.getZ(); hasPos = true;
    }

    /** Per-frame click polling (only while no screen is open). */
    public static void pollClicks() {
        var mc = Pulse.mc;
        long now = System.currentTimeMillis();
        boolean l = false, r = false;
        if (mc.currentScreen == null) {
            long w = mc.getWindow().getHandle();
            l = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            r = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        }
        if (l && !lDown) LEFT.addLast(now);
        if (r && !rDown) RIGHT.addLast(now);
        lDown = l; rDown = r;
        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.pollFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.pollFirst();
    }

    public static int cpsLeft() { return LEFT.size(); }
    public static int cpsRight() { return RIGHT.size(); }

    private Stats() {}
}
