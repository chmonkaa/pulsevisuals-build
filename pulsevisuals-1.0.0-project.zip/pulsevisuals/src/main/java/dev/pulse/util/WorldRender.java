package dev.pulse.util;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

import java.util.function.IntUnaryOperator;

/**
 * Immediate world-space geometry built only from translucent quads (billboard lines, rings, boxes, sprites)
 * on the vanilla "debug quads" layer. No custom shaders / pipelines => works with Sodium and Iris.
 */
public final class WorldRender {
    private static VertexConsumer vc;
    private static Matrix4f mat;
    private static boolean active;

    public static boolean begin(WorldRenderContext ctx) {
        active = false;
        try {
            MatrixStack ms = ctx.matrices();
            VertexConsumerProvider vp = ctx.consumers();
            if (ms == null || vp == null) return false;
            mat = ms.peek().getPositionMatrix();
            vc = vp.getBuffer(RenderLayer.getDebugQuads());
            Proj.update();
            active = true;
        } catch (Throwable t) { active = false; }
        return active;
    }

    public static void end() { active = false; vc = null; }

    private static void v(double x, double y, double z, int c) {
        vc.vertex(mat, (float) (x - Proj.cx), (float) (y - Proj.cy), (float) (z - Proj.cz)).color(c);
    }

    public static void quad(double x1, double y1, double z1, double x2, double y2, double z2,
                            double x3, double y3, double z3, double x4, double y4, double z4, int c) {
        if (!active || (c >>> 24) == 0) return;
        v(x1, y1, z1, c); v(x2, y2, z2, c); v(x3, y3, z3, c); v(x4, y4, z4, c);
    }

    /** Quad with per-vertex colours (c1..c4 match the points). */
    public static void quadC(double x1, double y1, double z1, int c1, double x2, double y2, double z2, int c2,
                             double x3, double y3, double z3, int c3, double x4, double y4, double z4, int c4) {
        if (!active) return;
        v(x1, y1, z1, c1); v(x2, y2, z2, c2); v(x3, y3, z3, c3); v(x4, y4, z4, c4);
    }

    /** Camera-facing line segment with a width in blocks. */
    public static void line(double x1, double y1, double z1, double x2, double y2, double z2, double width, int c) {
        if (!active || (c >>> 24) == 0) return;
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        double mx = (x1 + x2) / 2 - Proj.cx, my = (y1 + y2) / 2 - Proj.cy, mz = (z1 + z2) / 2 - Proj.cz;
        double sx = dy * mz - dz * my, sy = dz * mx - dx * mz, sz = dx * my - dy * mx;
        double l = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (l < 1e-9) return;
        double k = width / 2 / l;
        sx *= k; sy *= k; sz *= k;
        quad(x1 - sx, y1 - sy, z1 - sz, x1 + sx, y1 + sy, z1 + sz, x2 + sx, y2 + sy, z2 + sz, x2 - sx, y2 - sy, z2 - sz, c);
    }

    public static void lineC(double x1, double y1, double z1, int c1, double x2, double y2, double z2, int c2, double width) {
        if (!active) return;
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        double mx = (x1 + x2) / 2 - Proj.cx, my = (y1 + y2) / 2 - Proj.cy, mz = (z1 + z2) / 2 - Proj.cz;
        double sx = dy * mz - dz * my, sy = dz * mx - dx * mz, sz = dx * my - dy * mx;
        double l = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (l < 1e-9) return;
        double k = width / 2 / l;
        sx *= k; sy *= k; sz *= k;
        quadC(x1 - sx, y1 - sy, z1 - sz, c1, x1 + sx, y1 + sy, z1 + sz, c1, x2 + sx, y2 + sy, z2 + sz, c2, x2 - sx, y2 - sy, z2 - sz, c2);
    }

    /** Horizontal flat ring (annulus) lying in the XZ plane. colour(i) is queried per segment. */
    public static void ringH(double x, double y, double z, double radius, double thick, int segs, IntUnaryOperator colour) {
        if (!active) return;
        double ro = radius, ri = Math.max(0.001, radius - thick);
        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs, a2 = Math.PI * 2 * (i + 1) / segs;
            double c1 = Math.cos(a1), s1 = Math.sin(a1), c2 = Math.cos(a2), s2 = Math.sin(a2);
            int col = colour.applyAsInt(i);
            quad(x + c1 * ri, y, z + s1 * ri, x + c1 * ro, y, z + s1 * ro, x + c2 * ro, y, z + s2 * ro, x + c2 * ri, y, z + s2 * ri, col);
        }
    }

    public static void discH(double x, double y, double z, double radius, int segs, int col) {
        if (!active) return;
        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs, a2 = Math.PI * 2 * (i + 1) / segs;
            quad(x, y, z, x + Math.cos(a1) * radius, y, z + Math.sin(a1) * radius, x + Math.cos(a2) * radius, y, z + Math.sin(a2) * radius, x, y, z, col);
        }
    }

    /** Cone with the apex above the base ring (China hat), colour(i) per segment. */
    public static void cone(double x, double y, double z, double radius, double height, int segs, IntUnaryOperator colour, int apexColour) {
        if (!active) return;
        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs, a2 = Math.PI * 2 * (i + 1) / segs;
            int col = colour.applyAsInt(i);
            quadC(x, y + height, z, apexColour, x, y + height, z, apexColour,
                    x + Math.cos(a2) * radius, y, z + Math.sin(a2) * radius, col, x + Math.cos(a1) * radius, y, z + Math.sin(a1) * radius, col);
        }
    }

    /** Camera facing square sprite. */
    public static void sprite(double x, double y, double z, double size, int c) {
        if (!active || (c >>> 24) == 0) return;
        double h = size / 2;
        double rx = Proj.rx * h, ry = Proj.ry * h, rz = Proj.rz * h, ux = Proj.ux * h, uy = Proj.uy * h, uz = Proj.uz * h;
        quad(x - rx - ux, y - ry - uy, z - rz - uz, x + rx - ux, y + ry - uy, z + rz - uz,
                x + rx + ux, y + ry + uy, z + rz + uz, x - rx + ux, y - ry + uy, z - rz + uz, c);
    }

    /** Soft glowing orb made from stacked sprites. */
    public static void orb(double x, double y, double z, double size, int c) {
        sprite(x, y, z, size * 2.4, ColorUtil.alphaMul(c, 0.10f));
        sprite(x, y, z, size * 1.6, ColorUtil.alphaMul(c, 0.22f));
        sprite(x, y, z, size, ColorUtil.alphaMul(c, 0.85f));
        sprite(x, y, z, size * 0.45, ColorUtil.alphaMul(0xFFFFFFFF, 0.9f * ((c >>> 24) / 255f)));
    }

    public static void boxFill(Box b, int c) { boxFill(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, c); }

    public static void boxFill(double x1, double y1, double z1, double x2, double y2, double z2, int c) {
        if (!active || (c >>> 24) == 0) return;
        quad(x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, c);
        quad(x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, c);
        quad(x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, c);
        quad(x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, c);
        quad(x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, c);
        quad(x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, c);
    }

    public static void boxLines(Box b, double w, int c) { boxLines(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, w, c); }

    public static void boxLines(double x1, double y1, double z1, double x2, double y2, double z2, double w, int c) {
        if (!active || (c >>> 24) == 0) return;
        line(x1, y1, z1, x2, y1, z1, w, c); line(x1, y1, z2, x2, y1, z2, w, c);
        line(x1, y2, z1, x2, y2, z1, w, c); line(x1, y2, z2, x2, y2, z2, w, c);
        line(x1, y1, z1, x1, y1, z2, w, c); line(x2, y1, z1, x2, y1, z2, w, c);
        line(x1, y2, z1, x1, y2, z2, w, c); line(x2, y2, z1, x2, y2, z2, w, c);
        line(x1, y1, z1, x1, y2, z1, w, c); line(x2, y1, z1, x2, y2, z1, w, c);
        line(x1, y1, z2, x1, y2, z2, w, c); line(x2, y1, z2, x2, y2, z2, w, c);
    }

    private WorldRender() {}
}
